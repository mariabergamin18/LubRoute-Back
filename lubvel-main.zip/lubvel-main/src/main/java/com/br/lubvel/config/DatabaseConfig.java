package com.br.lubvel.config;


import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;

import java.net.URI;
import java.net.URISyntaxException;

@Configuration
public class DatabaseConfig {

    @PostConstruct
    public void configureDatabase() throws URISyntaxException {
        String databaseUrl = System.getenv("DATABASE_URL");
        if (databaseUrl != null) {
            URI dbUri = new URI(databaseUrl);
            String username = dbUri.getUserInfo().split(":")[0];
            String password = dbUri.getUserInfo().split(":")[1];
            String dbUrl = "jdbc:postgresql://" + dbUri.getHost() + ':' + dbUri.getPort() + dbUri.getPath();

            System.setProperty("JDBC_DATABASE_URL", dbUrl);
            System.setProperty("JDBC_DATABASE_USERNAME", username);
            System.setProperty("JDBC_DATABASE_PASSWORD", password);
        }
    }
}

