package com.br.lubvel.controllers;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.ClienteAtlCredentialsDTO;
import com.br.lubvel.dto.ClienteCredentialsDTO;
import com.br.lubvel.dto.ClienteEsqueciSenhaDTO;
import com.br.lubvel.dto.ClienteRedefinirSenhaDTO;
import com.br.lubvel.dto.JwtResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.AccessService;

import jakarta.validation.Valid;

@RestController
public class AccessController {

	private AccessService accessService;

	private static final String SUCCES_OPERATION = "SUCCES OPERATION";

	public AccessController(AccessService accessService) {
		this.accessService = accessService;
	}

	@PostMapping("/login")
	public ResponseEntity<ResponseBase<JwtResponseDTO>> login(@RequestBody  @Valid ClienteCredentialsDTO credentials) {
			JwtResponseDTO jwtResponseDTO = accessService.authenticateAndGetJWT(credentials);
			var response = new ResponseBase<JwtResponseDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
					.setStatus(HttpStatus.CREATED.value()).setData(jwtResponseDTO);
			return ResponseEntity.ok(response);		
	}

	@PostMapping("alterar-senha")
	public ResponseEntity<ResponseBase<JwtResponseDTO>> alterarSenha(@RequestBody @Valid ClienteAtlCredentialsDTO credentials, @RequestHeader HttpHeaders headers) {
		JwtResponseDTO jwtResponseDTO = accessService.alterarSenhaOrquestrador(credentials, headers);
		var response = new ResponseBase<JwtResponseDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.CREATED.value()).setData(jwtResponseDTO);
		return ResponseEntity.ok(response);
	}

	@PostMapping("esqueci-senha")
	public ResponseEntity<ResponseBase<Object>> esqueciSenha(@RequestBody @Valid ClienteEsqueciSenhaDTO clienteEsqueciSenhaDTO) {		
		accessService.esqueciSenha(clienteEsqueciSenhaDTO);
		
		var response = new ResponseBase<Object>().setSuccess(true).setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.CREATED.value());
		return ResponseEntity.ok(response);		
		
	}

	@PostMapping("redefinir-senha")
	public ResponseEntity<ResponseBase<Object>> redefinirSenha(@RequestBody @Valid ClienteRedefinirSenhaDTO clienteRedefinirSenhaDTO) {
		
		accessService.redefinirSenha(clienteRedefinirSenhaDTO);

		var response = new ResponseBase<Object>().setSuccess(true).setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.CREATED.value());
		return ResponseEntity.ok(response);
		
		
	}
	
	
}
