package com.br.lubvel.controllers;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.ClienteDTO;
import com.br.lubvel.dto.ClienteParamDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.AccessService;
import com.br.lubvel.services.ClienteService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/cliente")
public class ClienteController {

	@Autowired
	private ClienteService service;

	@Autowired
	private AccessService accessService;

	private static final String SUCCES_OPERATION = "SUCCES OPERATION";

	@PostMapping()
	public ResponseEntity<ResponseBase<ClienteParamDTO>> store(@Valid @RequestBody ClienteParamDTO clienteDto,
			@RequestHeader HttpHeaders headers) {

		accessService.isAdmin(headers);
		service.store(clienteDto);

		var response = new ResponseBase<ClienteParamDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.CREATED.value());
		return ResponseEntity.ok(response);
	}

	@PutMapping("/{publicId}")
	public ResponseEntity<ResponseBase<ClienteParamDTO>> update(@PathVariable("publicId") String publicId,
			@Valid @RequestBody ClienteParamDTO clienteDto, @RequestHeader HttpHeaders headers) {

		accessService.isAdmin(headers);
		service.update(publicId, clienteDto);

		var response = new ResponseBase<ClienteParamDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.CREATED.value());
		return ResponseEntity.ok(response);
	}

	@GetMapping()
	public ResponseEntity<ResponseBase<List<ClienteDTO>>> getAll(@RequestHeader HttpHeaders headers) {
		accessService.isAdmin(headers);
		List<ClienteDTO> clientes = service.showAll();

		var response = new ResponseBase<List<ClienteDTO>>()
				.setData(clientes)
				.setSuccess(true)
				.setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.OK.value());

		return ResponseEntity.ok(response);
	}

	@GetMapping("/{publicId}")
	public ResponseEntity<ResponseBase<ClienteDTO>> getByPublicId(
			@RequestHeader HttpHeaders headers,
			@PathVariable String publicId) {
		
		accessService.isAdmin(headers);		
		ClienteDTO cliente = service.getByPublicId(publicId);
		
		var response = new ResponseBase<ClienteDTO>()
					.setData(cliente)
					.setSuccess(true)
					.setMessage(SUCCES_OPERATION)
					.setStatus(HttpStatus.OK.value());
		
		return ResponseEntity.ok(response);
	}


	@DeleteMapping("/{publicId}")
	public ResponseEntity<ResponseBase<ClienteParamDTO>> delete(@PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
		accessService.isAdmin(headers);
		service.delete(publicId);

		var response = new ResponseBase<ClienteParamDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
				.setStatus(HttpStatus.CREATED.value());
		return ResponseEntity.ok(response);
	}

}
