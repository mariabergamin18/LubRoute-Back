package com.br.lubvel.controllers;

import com.br.lubvel.dto.EquipamentoParamDTO;
import com.br.lubvel.dto.EquipamentoResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.EquipamentoService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/equipamentos")
public class EquipamentoController {

    private final EquipamentoService equipamentoService;

    private static final String SUCCES_OPERATION = "SUCCES OPERATION";

    public EquipamentoController(EquipamentoService equipamentoService) {
        this.equipamentoService = equipamentoService;
    }

    @GetMapping()
    public ResponseEntity<ResponseBase<List<EquipamentoResponseDTO>>> getAll(@RequestHeader HttpHeaders headers) {
        List<EquipamentoResponseDTO> equipamentosDTO = equipamentoService.getAllEquipamentos(headers);
        var response = new ResponseBase<List<EquipamentoResponseDTO>>()
                .setData(equipamentosDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{publicId}")
    public ResponseEntity<ResponseBase<EquipamentoResponseDTO>> getById(@PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
        EquipamentoResponseDTO equipamentoDTO = equipamentoService.getEquipamentoById(publicId, headers);
        ResponseBase<EquipamentoResponseDTO> response = new ResponseBase<EquipamentoResponseDTO>()
                .setData(equipamentoDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/setor/{setorPublicId}")
    public ResponseEntity<ResponseBase<List<EquipamentoResponseDTO>>> getEquipamentosBySetor(@PathVariable("setorPublicId") String setorTag, @RequestHeader HttpHeaders headers) {
        List<EquipamentoResponseDTO> equipamentosDTO = equipamentoService.getEquipamentosBySetor(setorTag, headers);
        ResponseBase<List<EquipamentoResponseDTO>> response = new ResponseBase<List<EquipamentoResponseDTO>>()
                .setData(equipamentosDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<ResponseBase<EquipamentoResponseDTO>> store(@RequestBody @Validated EquipamentoParamDTO equipamentoParamDTO, @RequestHeader HttpHeaders headers) {
        EquipamentoResponseDTO equipamentoDTO = equipamentoService.createEquipamento(equipamentoParamDTO, headers);
        ResponseBase<EquipamentoResponseDTO> response = new ResponseBase<EquipamentoResponseDTO>()
                .setData(equipamentoDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setCreated(true)
                .setStatus(HttpStatus.CREATED.value());
        return ResponseEntity.created(null).body(response);
    }

    @PutMapping("/{publicId}")
    public ResponseEntity<ResponseBase<EquipamentoResponseDTO>> update(@PathVariable("publicId") String publicId, @RequestBody @Validated EquipamentoParamDTO equipamentoParamDTO, @RequestHeader HttpHeaders headers) {
        EquipamentoResponseDTO equipamentoDTO = equipamentoService.updateEquipamento(publicId, equipamentoParamDTO, headers);
        ResponseBase<EquipamentoResponseDTO> response = new ResponseBase<EquipamentoResponseDTO>()
                .setData(equipamentoDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/{publicId}", method = RequestMethod.OPTIONS)
    public ResponseEntity<Void> options(@PathVariable("publicId") String id) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin", "*");
        headers.add("Access-Control-Allow-Methods", "DELETE");
        headers.add("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
        return new ResponseEntity<>(headers, HttpStatus.OK);
    }

    @DeleteMapping("/{publicId}")
    public ResponseEntity<?> deleteEquipamento(@PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
        equipamentoService.deleteEquipamento(publicId, headers);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
