package com.br.lubvel.controllers;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;

import com.br.lubvel.dto.ConsultaEstoqueParamDTO;
import com.br.lubvel.dto.ConsultaEstoqueResponseDTO;
import com.br.lubvel.dto.EstoqueParamDTO;
import com.br.lubvel.dto.EstoqueResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.EstoqueService;

@RestController
@RequestMapping("/estoque")
public class EstoqueController {

    private static final String SUCCES_OPERATION = "SUCCES OPERATION";

    private EstoqueService estoqueService;

    public EstoqueController(EstoqueService estoqueService) {
        this.estoqueService = estoqueService;
    }

    @GetMapping
    public ResponseEntity<ResponseBase<List<EstoqueResponseDTO>>> getAll(@RequestHeader HttpHeaders headers) {
        List<EstoqueResponseDTO> estoqueResponseDTO = estoqueService.getEstoque(headers);

        return ResponseEntity.ok(new ResponseBase<List<EstoqueResponseDTO>>()
                .setData(estoqueResponseDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(200));
    }

    @PostMapping
    public ResponseEntity<ResponseBase<EstoqueResponseDTO>> store(
            @RequestBody @Validated EstoqueParamDTO estoqueParamDTO, @RequestHeader HttpHeaders headers) {
        EstoqueResponseDTO estoqueResponseDTO = estoqueService.save(estoqueParamDTO, headers);

        return ResponseEntity.ok(new ResponseBase<EstoqueResponseDTO>()
                .setData(estoqueResponseDTO)
                .setSuccess(true)
                .setCreated(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(201));
    }

    @PostMapping("/lista-estoque")
    public ResponseEntity<ResponseBase<List<EstoqueResponseDTO>>> storeList(
            @RequestBody @Validated List<EstoqueParamDTO> estoqueParamDTO, @RequestHeader HttpHeaders headers) {
        List<EstoqueResponseDTO> estoqueResponseDTO = estoqueService.saveList(estoqueParamDTO, headers);

        return ResponseEntity.ok(new ResponseBase<List<EstoqueResponseDTO>>()
                .setData(estoqueResponseDTO)
                .setSuccess(true)
                .setCreated(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(201));
    }

    @GetMapping("/baixo-estoque")
    public ResponseEntity<ResponseBase<List<EstoqueResponseDTO>>> getBaixoEstoque(@RequestHeader HttpHeaders headers) {
        List<EstoqueResponseDTO> estoqueResponseDTO = estoqueService.getBaixoEstoque(headers);

        return ResponseEntity.ok(new ResponseBase<List<EstoqueResponseDTO>>()
                .setData(estoqueResponseDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(200));
    }

    @PostMapping("/conferir-estoque")
    public ResponseEntity<ResponseBase<List<ConsultaEstoqueResponseDTO>>> conferirEstoque(
            @RequestHeader HttpHeaders headers,
            @RequestBody List<ConsultaEstoqueParamDTO> consultaEstoqueParamDTO) {

        Collection<ConsultaEstoqueResponseDTO> estoqueResponseDTO = estoqueService.conferirEstoque(headers,
                consultaEstoqueParamDTO);

        return ResponseEntity.ok(new ResponseBase<List<ConsultaEstoqueResponseDTO>>()
                .setData((List<ConsultaEstoqueResponseDTO>) estoqueResponseDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(200));
    }

}
