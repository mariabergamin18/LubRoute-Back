package com.br.lubvel.controllers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.MarcosResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.services.AccessService;
import com.br.lubvel.services.MarcosService;

@RestController
@RequestMapping("/marcos")
public class MarcosController {

   private static final String SUCCES_OPERATION = "SUCCES OPERATION";

   @Autowired
   private MarcosService marcosService;

   @Autowired
   private AccessService accessService;

   @GetMapping()
   public ResponseEntity<ResponseBase<List<MarcosResponseDTO>>> getAllMarcos(
         @RequestHeader HttpHeaders headers,
         @RequestParam("startDate") String startDate,
         @RequestParam("endDate") String endDate) {

      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      LocalDate dataInicio = LocalDate.parse(startDate, formatter);
      LocalDate dataFim = LocalDate.parse(endDate, formatter);

      Cliente cliente = accessService.getClienteLogado(headers);
      List<MarcosResponseDTO> marcosList = marcosService.getAllMarcos(cliente, dataInicio, dataFim);
      ResponseBase<List<MarcosResponseDTO>> response = new ResponseBase<List<MarcosResponseDTO>>()
            .setData(marcosList)
            .setSuccess(true)
            .setMessage(SUCCES_OPERATION)
            .setStatus(HttpStatus.OK.value());
      return ResponseEntity.ok(response);
   }
}
