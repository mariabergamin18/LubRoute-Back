package com.br.lubvel.controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.MetricasResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.MetricasService;

@RestController
@RequestMapping("/metricas")
public class MetricasController {
    private static final String SUCCES_OPERATION = "SUCCES OPERATION";

    @Autowired
    private MetricasService metricasService;

    @GetMapping
    public ResponseEntity<ResponseBase<List<MetricasResponseDTO>>> getAll(
            @RequestHeader HttpHeaders headers,
            @RequestParam("dataInicio") LocalDate dataInicio,
            @RequestParam("dataFim") LocalDate dataFim) {
        List<MetricasResponseDTO> metricasResponseDTO = metricasService.getMetricas(headers, dataInicio, dataFim);

        return ResponseEntity.ok(new ResponseBase<List<MetricasResponseDTO>>()
                .setData(metricasResponseDTO)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(200));
    }
}
