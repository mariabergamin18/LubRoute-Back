package com.br.lubvel.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import com.br.lubvel.dto.NotificacaoDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.services.AccessService;
import java.util.List;

import com.br.lubvel.services.NotificacaoService;

@RestController
@RequestMapping("/notificacao")
public class NotificacaoController {
    private static final String SUCCESS_OPERATION = "SUCCES OPERATION";

    @Autowired
    private NotificacaoService notificacaoService;

    @Autowired
    private AccessService accessService;

    @GetMapping
    public ResponseEntity<ResponseBase<List<NotificacaoDTO>>> listarNotificacoesCliente(
            @RequestHeader HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<NotificacaoDTO> notificacoes = notificacaoService.listarNotificacoesCliente(cliente);
        return ResponseEntity.ok(new ResponseBase<List<NotificacaoDTO>>()
                .setData(notificacoes)
                .setSuccess(true)
                .setMessage(SUCCESS_OPERATION)
                .setStatus(200));
    }

    // endpoint para marcar notificação como lida
    @PostMapping("/marcar-lida")
    public ResponseEntity<ResponseBase<NotificacaoDTO>> marcarNotificacaoComoLida(
            @RequestHeader HttpHeaders headers,
            @RequestParam String publicId) {
        Cliente cliente = accessService.getClienteLogado(headers);
        NotificacaoDTO notificacao = notificacaoService.marcarNotificacaoComoLida(cliente, publicId);
        return ResponseEntity.ok(new ResponseBase<NotificacaoDTO>()
                .setData(notificacao)
                .setSuccess(true)
                .setMessage(SUCCESS_OPERATION)
                .setStatus(200));
    }

    // endpoint para admin criar notificação, recebe NotificaoDTO como body, e
    // clientePublicId como parametro
    @PostMapping("/criar")
    public ResponseEntity<ResponseBase<NotificacaoDTO>> criarNotificacao(
            @RequestHeader HttpHeaders headers,
            @RequestParam String clientePublicId,
            @RequestBody NotificacaoDTO notificacaoDTO) {
        // verifica se o cliente logado é admin
        accessService.isAdmin(headers);
        Cliente cliente = accessService.getClienteByPublicId(clientePublicId);
        NotificacaoDTO notificacao = notificacaoService.criarNotificacao(cliente, clientePublicId, notificacaoDTO);
        return ResponseEntity.ok(new ResponseBase<NotificacaoDTO>()
                .setData(notificacao)
                .setSuccess(true)
                .setMessage(SUCCESS_OPERATION)
                .setStatus(200));
    }

}
