package com.br.lubvel.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.br.lubvel.dto.OperacaoDashBoardAdminDTO;
import com.br.lubvel.dto.OperacaoDashBoardDTO;
import com.br.lubvel.dto.OperacaoParamDTO;
import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.OperacaoResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.OperacaoPausa;
import com.br.lubvel.services.AccessService;
import com.br.lubvel.services.OperacaoExecutadaService;
import com.br.lubvel.services.OperacaoPausaService;
import com.br.lubvel.services.OperacaoService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;


@RestController
@RequestMapping("/operacoes")
public class OperacaoController {

    private static final String SUCCES_OPERATION = "SUCCES OPERATION";    

    @Autowired
    private OperacaoService operacaoService;

    @Autowired
    private OperacaoExecutadaService operacaoExecutadaService;

    @Autowired
    private AccessService accessService;

    @Autowired
    private OperacaoPausaService operacaoPausaService;

    @PostMapping
    public ResponseEntity<OperacaoResponseDTO> create(@RequestBody OperacaoParamDTO operacaoRequest, @RequestHeader HttpHeaders headers) {
        accessService.getClienteLogado(headers);
        OperacaoResponseDTO createdOperacao = operacaoService.save(operacaoRequest);
        return ResponseEntity.ok(createdOperacao);
    }

    @PutMapping("/{publicId}")
    public ResponseEntity<OperacaoResponseDTO> update(@PathVariable("publicId") String publicId, @RequestBody OperacaoParamDTO operacaoRequest, @RequestHeader HttpHeaders headers) {        
        OperacaoResponseDTO updatedOperacao = operacaoService.update(operacaoRequest, publicId, headers);
        return ResponseEntity.ok(updatedOperacao);
    }

    @DeleteMapping("/{publicId}")
    public ResponseEntity<Void> delete(@PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
        operacaoService.delete(publicId, headers);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<ResponseBase<List<OperacaoResponseDTO>>> findAll(@RequestHeader HttpHeaders headers) {
    List<OperacaoResponseDTO> operacoes = operacaoService.findAll(headers);
    
    var response = new ResponseBase<List<OperacaoResponseDTO>>()
                .setData(operacoes)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());

        return ResponseEntity.ok(response);
    }

    @GetMapping("/{publicId}")
    public ResponseEntity<ResponseBase<OperacaoResponseDTO>> findByPublicId(@PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
        OperacaoResponseDTO operacao = operacaoService.findOperacaoDTOByPublicId(publicId,headers);
        
        var response = new ResponseBase<OperacaoResponseDTO>()
                .setData(operacao)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());

        return ResponseEntity.ok(response);
    }

    @GetMapping("/dashboard")
    public ResponseEntity<OperacaoDashBoardDTO> getDashBoard(@RequestHeader HttpHeaders headers) {
        OperacaoDashBoardDTO operacaoDashBoard = operacaoService.getDashBoard(headers);
        return ResponseEntity.ok(operacaoDashBoard);
    }

    @GetMapping("/dashboard-admin")
    public ResponseEntity<OperacaoDashBoardAdminDTO> getDashBoardAdmin(@RequestHeader HttpHeaders headers) {
        OperacaoDashBoardAdminDTO operacaoDashBoard = operacaoService.getDashBoardAdmin(headers);
        return ResponseEntity.ok(operacaoDashBoard);
    }

    @GetMapping("/periodo/{periodo}")
    public ResponseEntity<ResponseBase<List<OperacaoPeriodoDTO>>> getOperacoesPeriodo(@RequestHeader HttpHeaders headers, @PathVariable("periodo") String periodo) {
       
        Cliente cliente = accessService.getClienteLogado(headers);
        List<OperacaoExecutada> operacaoExecutadas = operacaoExecutadaService.findAllCliente(cliente);
        List<OperacaoPausa> operacaoPausas = operacaoPausaService.getOperacoesPausadas(cliente);
        List<OperacaoPeriodoDTO> operacoes = operacaoService.getAtividadesPeriodoCliente(cliente, periodo, operacaoExecutadas, operacaoPausas);

        var response = new ResponseBase<List<OperacaoPeriodoDTO>>()
                .setData(operacoes)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(HttpStatus.OK.value());

        return ResponseEntity.ok(response);
    }

    @GetMapping("/periodo-data")
    public ResponseEntity<ResponseBase<List<OperacaoPeriodoDTO>>> getOperacoesPeriodoUser(
        @RequestHeader HttpHeaders headers, 
        @RequestParam("startDate") String startDate, 
        @RequestParam("endDate") String endDate) {

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate dataInicio = LocalDate.parse(startDate, formatter);
            LocalDate dataFim = LocalDate.parse(endDate, formatter);
            
            Cliente cliente = accessService.getClienteLogado(headers);
            
            List<OperacaoExecutada> operacaoExecutadas = operacaoExecutadaService.findAllCliente(cliente);
            List<OperacaoPausa> operacaoPausas = operacaoPausaService.getOperacoesPausadas(cliente);
            List<OperacaoPeriodoDTO> operacoes = operacaoService.getAtividadesPeriodoInformado(cliente, dataInicio, dataFim, operacaoExecutadas, operacaoPausas);

            var response = new ResponseBase<List<OperacaoPeriodoDTO>>()
                    .setData(operacoes)
                    .setSuccess(true)
                    .setMessage(SUCCES_OPERATION)
                    .setStatus(HttpStatus.OK.value());

            return ResponseEntity.ok(response);
}

    




}
