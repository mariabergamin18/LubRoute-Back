package com.br.lubvel.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.OperacaoExecutadaParamDTO;
import com.br.lubvel.dto.OperacaoExecutadaRelatorioResponseDTO;
import com.br.lubvel.dto.OperacaoExecutadaResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.services.OperacaoExecutadaService;
import com.br.lubvel.services.OperacaoService;

import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/operacao-executada")
public class OperacaoExecutadaController {

    private static final String SUCCES_OPERATION = "SUCCES OPERATION";
    
    
    @Autowired
    private OperacaoExecutadaService service;

    @Autowired
    private OperacaoService operacaoService;

    @PostMapping
    public ResponseEntity<ResponseBase<List<OperacaoExecutadaResponseDTO>>> store(@Valid @RequestBody List<OperacaoExecutadaParamDTO> operacaoExecutadaParamDTO, @RequestHeader HttpHeaders headers) {
        
        List<OperacaoExecutadaResponseDTO> operacaoExecutadaResponseDTO = new ArrayList<>();
        for (OperacaoExecutadaParamDTO operacaoDto : operacaoExecutadaParamDTO) {
            Operacao operacao = operacaoService.findByPublicIdAuth(operacaoDto.getOperacaoPublicId(), headers);
            operacaoExecutadaResponseDTO.add(service.save(operacaoDto, headers, operacao));
        }
        return ResponseEntity.ok(new ResponseBase<List<OperacaoExecutadaResponseDTO>>().setSuccess(true).setMessage(SUCCES_OPERATION).setData(operacaoExecutadaResponseDTO));                                
    }

    @GetMapping("relato-tecnico")
    public ResponseEntity<ResponseBase<List<OperacaoExecutadaRelatorioResponseDTO>>> getRelatosTecnicos(@RequestHeader HttpHeaders headers, @RequestParam String dataInicio, @RequestParam String dataFim) {
        List<OperacaoExecutadaRelatorioResponseDTO> operacaoExecutadaResponseDTO = service.getRelatosTecnicos(headers, dataInicio, dataFim);
        
        var response = new ResponseBase<List<OperacaoExecutadaRelatorioResponseDTO>>()
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(200)
                .setData(operacaoExecutadaResponseDTO);
        return ResponseEntity.ok(response);
    }
    

}
