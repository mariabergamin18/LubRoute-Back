package com.br.lubvel.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.OperacaoPausaParamDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.AccessService;
import com.br.lubvel.services.OperacaoPausaService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;



@RestController
@RequestMapping("/operacoes-pausa")
public class OperacaoPausaController {

   private static final String SUCCESS_OPERATION = "SUCCES OPERATION";

   @Autowired
   private OperacaoPausaService operacaoPausaService;

   @Autowired
   private AccessService accessService;   

   @GetMapping("/{operacaoPublicId}")
   public ResponseEntity<ResponseBase<Boolean>> getMethodName(@PathVariable String operacaoPublicId, @RequestHeader HttpHeaders headers, @RequestParam String data) {
         accessService.getClienteLogado(headers);
         Boolean isPaused = operacaoPausaService.isPaused(operacaoPublicId, data);
         var response = new ResponseBase<Boolean>()
            .setData(isPaused)
            .setSuccess(true)
            .setMessage(SUCCESS_OPERATION)
            .setStatus(HttpStatus.OK.value());

         return ResponseEntity.ok(response);
   }   
   
   @PostMapping
   public ResponseEntity<Boolean> create(@RequestBody OperacaoPausaParamDTO operacaoPausaRequest, @RequestHeader HttpHeaders headers) {
       accessService.getClienteLogado(headers);
       operacaoPausaService.save(operacaoPausaRequest);
       return ResponseEntity.ok(true);
   }

   @DeleteMapping("/{operacaoPublicId}")
   public ResponseEntity<Boolean> removePausa(@PathVariable String operacaoPublicId, @RequestHeader HttpHeaders headers) {       accessService.getClienteLogado(headers);
       operacaoPausaService.removePausa(operacaoPublicId);
       return ResponseEntity.ok(true);
   }   
   
}
