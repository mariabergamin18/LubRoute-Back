package com.br.lubvel.controllers;

import com.br.lubvel.dto.PtLubParamDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.dto.PontoDeLubrificacaoResponseDTO;
import com.br.lubvel.services.PontoDeLubrificacaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pontos-de-lubrificacao")
public class PontoDeLubrificacaoController {

    @Autowired
    private PontoDeLubrificacaoService service;

    @GetMapping("/{setorPublicId}")
    public ResponseEntity<ResponseBase<List<PontoDeLubrificacaoResponseDTO>>> findAll(@PathVariable("setorPublicId") String setorPublicId,@RequestHeader HttpHeaders headers) {
        List<PontoDeLubrificacaoResponseDTO> pontosDeLubrificacao = service.findAll(setorPublicId, headers);
        ResponseBase<List<PontoDeLubrificacaoResponseDTO>> response = new ResponseBase<List<PontoDeLubrificacaoResponseDTO>>();
        response.setData(pontosDeLubrificacao);
        response.setSuccess(true);
        response.setMessage("SUCCES OPERATION");
        response.setStatus(200);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/equipamento/{equipamentoPublicId}")
    public ResponseEntity<ResponseBase<List<PontoDeLubrificacaoResponseDTO>>> findAllByEquipamento(@PathVariable("equipamentoPublicId") String equipamentoPublicId, @RequestHeader HttpHeaders headers) {
        List<PontoDeLubrificacaoResponseDTO> pontosDeLubrificacao = service.findAllByEquipamento(equipamentoPublicId, headers);
        ResponseBase<List<PontoDeLubrificacaoResponseDTO>> response = new ResponseBase<List<PontoDeLubrificacaoResponseDTO>>();
        response.setData(pontosDeLubrificacao);
        response.setSuccess(true);
        response.setMessage("SUCCES OPERATION");
        response.setStatus(200);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/detalhe/{publicId}")
    public ResponseEntity<ResponseBase<PontoDeLubrificacaoResponseDTO>> findByPublicId(@PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
        PontoDeLubrificacaoResponseDTO pontoDeLubrificacao = service.findByPublicIdResponseDTO(publicId, headers);
        ResponseBase<PontoDeLubrificacaoResponseDTO> response = new ResponseBase<PontoDeLubrificacaoResponseDTO>();
        response.setData(pontoDeLubrificacao);
        response.setSuccess(true);
        response.setMessage("SUCCES OPERATION");
        response.setStatus(200);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<ResponseBase<PontoDeLubrificacaoResponseDTO>> save(@RequestHeader HttpHeaders headers, @RequestBody @Validated PtLubParamDTO ptLubParamDTO) {
        PontoDeLubrificacaoResponseDTO pontoDeLubrificacao = service.save(ptLubParamDTO, headers);
        ResponseBase<PontoDeLubrificacaoResponseDTO> response = new ResponseBase<PontoDeLubrificacaoResponseDTO>();
        response.setData(pontoDeLubrificacao);
        response.setSuccess(true);
        response.setMessage("SUCCES OPERATION");
        response.setStatus(200);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/{publicId}")
    public ResponseEntity<PontoDeLubrificacaoResponseDTO> update(@RequestHeader HttpHeaders headers, @PathVariable("publicId") String publicId, @RequestBody @Validated PtLubParamDTO ptLubParamDTO) {
        return ResponseEntity.ok(service.update(publicId, ptLubParamDTO, headers));
    }

    @DeleteMapping("/{publicId}")
    public ResponseEntity<Void> delete(@RequestHeader HttpHeaders headers, @PathVariable("publicId") String publicId) {
        service.delete(publicId, headers);
        return ResponseEntity.noContent().build();
    }
}