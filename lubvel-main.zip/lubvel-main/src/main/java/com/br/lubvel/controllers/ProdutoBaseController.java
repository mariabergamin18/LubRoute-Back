package com.br.lubvel.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.ProdutoBaseResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.ProdutoBaseService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;


@RestController
@RequestMapping("/produtos-base")
public class ProdutoBaseController {

   @Autowired
   private ProdutoBaseService service;


   @GetMapping
   public ResponseEntity<ResponseBase<List<ProdutoBaseResponseDTO>>> findAll(@RequestHeader HttpHeaders headers) {
       List<ProdutoBaseResponseDTO> produtos = service.findAll(headers);
       ResponseBase<List<ProdutoBaseResponseDTO>> response = new ResponseBase<List<ProdutoBaseResponseDTO>>();
       response.setData(produtos);
       response.setSuccess(true);
       response.setMessage("SUCCES OPERATION");
       response.setStatus(200);
       return ResponseEntity.ok(response);
   }
   
}
