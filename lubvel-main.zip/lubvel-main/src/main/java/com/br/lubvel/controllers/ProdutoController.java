package com.br.lubvel.controllers;


import com.br.lubvel.dto.ProdutoErroResponseDTO;
import com.br.lubvel.dto.ProdutoEstoqueResponseDTO;
import com.br.lubvel.dto.ProdutoLoteDTO;
import com.br.lubvel.dto.ProdutoParamDTO;
import com.br.lubvel.dto.ProdutoResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.EstoqueService;
import com.br.lubvel.services.ProdutoService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

    @Autowired
    private ProdutoService service;

    @Autowired
    private EstoqueService estoqueService;
    
    @GetMapping
    public ResponseEntity<ResponseBase<List<ProdutoEstoqueResponseDTO>>> findAllEstoque(@RequestHeader HttpHeaders headers) {
        List<ProdutoEstoqueResponseDTO> produtos = estoqueService.findAllCliente(headers);
        ResponseBase<List<ProdutoEstoqueResponseDTO>> response = new ResponseBase<List<ProdutoEstoqueResponseDTO>>();
        response.setData(produtos);
        response.setSuccess(true);
        response.setMessage("SUCCES OPERATION");
        response.setStatus(200);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/todos")
    public ResponseEntity<ResponseBase<List<ProdutoResponseDTO>>> findAll(@RequestHeader HttpHeaders headers) {
        List<ProdutoResponseDTO> produtos = service.findAll(headers);
        ResponseBase<List<ProdutoResponseDTO>> response = new ResponseBase<List<ProdutoResponseDTO>>();
        response.setData(produtos);
        response.setSuccess(true);
        response.setMessage("SUCCES OPERATION");
        response.setStatus(200);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<ProdutoResponseDTO> save(@RequestHeader HttpHeaders headers, @RequestBody ProdutoParamDTO produtoParamDTO) {
        return ResponseEntity.ok(service.save(produtoParamDTO, headers));
    }

    @PostMapping("cadastro-lote")
public ResponseEntity<ResponseBase<List<ProdutoErroResponseDTO>>> saveLote(
        @RequestHeader HttpHeaders headers,
        @Valid @RequestBody ProdutoLoteDTO produtoParamDTO) {

    List<ProdutoErroResponseDTO> produtosErroSalvar = service.saveLote(produtoParamDTO, headers);

    ResponseBase<List<ProdutoErroResponseDTO>> response = new ResponseBase<>();

    if (produtosErroSalvar.isEmpty()) {
        // Caso de sucesso
        response.setData(null)
                .setSuccess(true)
                .setMessage("Produtos salvos com sucesso")
                .setStatus(HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    } else {
        // Caso de erro
        response.setData(produtosErroSalvar)
                .setSuccess(false)
                .setMessage("Erro ao salvar um ou mais produtos")
                .setStatus(HttpStatus.BAD_REQUEST.value());
        return ResponseEntity.badRequest().body(response);
    }
}


    @PutMapping("/{publicId}")
    public ResponseEntity<ProdutoResponseDTO> update(@RequestHeader HttpHeaders headers, @PathVariable("publicId") String publicId, @RequestBody ProdutoParamDTO produtoParamDTO) {
        return ResponseEntity.ok(service.update(publicId, produtoParamDTO, headers));
    }

    @DeleteMapping("/{publicId}")
    public ResponseEntity<Void> delete(@RequestHeader HttpHeaders headers,@PathVariable("publicId") String publicId) {
        service.delete(publicId, headers);
        return ResponseEntity.noContent().build();
    }
}
