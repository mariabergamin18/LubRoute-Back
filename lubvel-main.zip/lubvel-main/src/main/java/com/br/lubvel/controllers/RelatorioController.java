package com.br.lubvel.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.RelatorioDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.RelatorioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;


@RestController
@RequestMapping("/relatorios")
public class RelatorioController {
    private static final String SUCCES_OPERATION = "SUCCES OPERATION";

    @Autowired
    private RelatorioService service;

    @GetMapping("/{tipoRelatorio}")
    public ResponseEntity<ResponseBase<RelatorioDTO>> getRelatorio(@PathVariable("tipoRelatorio") String tipoRelatorio, @RequestHeader HttpHeaders headers) {
        RelatorioDTO relatorio = service.getRelatorio(tipoRelatorio, headers);
        
        return ResponseEntity.ok(new ResponseBase<RelatorioDTO>()
                .setData(relatorio)
                .setSuccess(true)
                .setMessage(SUCCES_OPERATION)
                .setStatus(200));
    }
    
}
