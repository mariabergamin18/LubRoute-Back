package com.br.lubvel.controllers;

import com.br.lubvel.dto.SetorParamDTO;
import com.br.lubvel.dto.SetorResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.services.SetorService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/setor")
public class SetorController {

	private final SetorService setorService;

	public SetorController(SetorService setorService) {
		this.setorService = setorService;
	}

	@PostMapping
	public ResponseEntity<SetorResponseDTO> createSetor(@RequestBody  @Validated SetorParamDTO setorParamDTO,
			@RequestHeader HttpHeaders headers) {
		SetorResponseDTO setorResponseDTO = setorService.createSetor(setorParamDTO, headers);
		return new ResponseEntity<>(setorResponseDTO, HttpStatus.CREATED);
	}

	@PutMapping("/{publicId}")
	public ResponseEntity<SetorResponseDTO> updateSetor(@PathVariable("publicId") String publicId,
			@RequestBody  @Validated SetorParamDTO setorParamDTO, @RequestHeader HttpHeaders headers) {
		
		SetorResponseDTO setorResponseDTO = setorService.updateSetor(publicId, setorParamDTO, headers);
		return new ResponseEntity<>(setorResponseDTO, HttpStatus.OK);
	}

	@DeleteMapping("/{publicId}")
	public ResponseEntity<Void> deleteSetor( @PathVariable("publicId") String publicId, @RequestHeader HttpHeaders headers) {
		
		setorService.delete(publicId,headers);
		return ResponseEntity.noContent().build();
	}

	@GetMapping()
	public ResponseEntity<ResponseBase<List<SetorResponseDTO>>> getAllSetoresByClienteId(@RequestHeader HttpHeaders headers) {
		
		List<SetorResponseDTO> setores = setorService.findAllByClienteId(headers);
		ResponseBase<List<SetorResponseDTO>> response = new ResponseBase<List<SetorResponseDTO>>()
				.setData(setores)
				.setSuccess(true)
				.setMessage("SUCCES OPERATION")
				.setStatus(HttpStatus.OK.value());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
