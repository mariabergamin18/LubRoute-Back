package com.br.lubvel.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.lubvel.dto.UsuarioClienteParamDTO;
import com.br.lubvel.dto.UsuarioClienteResponseDTO;
import com.br.lubvel.dto.commons.ResponseBase;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.services.AccessService;
import com.br.lubvel.services.ClienteService;
import com.br.lubvel.services.UsuarioClienteService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/usuario-cliente")
public class UsuarioClienteController {

      @Autowired
      private UsuarioClienteService service;

      @Autowired
      private ClienteService clienteManagerService;

      @Autowired
      private AccessService accessService;

      private static final String SUCCES_OPERATION = "SUCCES OPERATION";

      @PostMapping()
      public ResponseEntity<ResponseBase<UsuarioClienteParamDTO>> store(
                  @Valid @RequestBody UsuarioClienteParamDTO usuarioClienteDto,
                  @RequestHeader HttpHeaders headers) {

            // Validar se usuario é userManager
            accessService.isUserManager(headers);

            Cliente clienteManager = accessService.getClienteLogado(headers);
            List<String> emailsRestritos = clienteManagerService.findAllEmails();
            service.store(usuarioClienteDto, clienteManager, emailsRestritos);

            var response = new ResponseBase<UsuarioClienteParamDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
                        .setStatus(HttpStatus.CREATED.value());
            return ResponseEntity.ok(response);
      }

      @PutMapping()
      public ResponseEntity<ResponseBase<UsuarioClienteParamDTO>> update(
                  @Valid @RequestBody UsuarioClienteParamDTO usuarioClienteDto, @RequestHeader HttpHeaders headers) {

            // Validar se usuario é userManager
            accessService.isUserManager(headers);

            Cliente clienteManager = accessService.getClienteLogado(headers);
            List<String> emailsRestritos = clienteManagerService.findAllEmails();
            service.update(usuarioClienteDto, clienteManager, emailsRestritos);

            var response = new ResponseBase<UsuarioClienteParamDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
                        .setStatus(HttpStatus.CREATED.value());
            return ResponseEntity.ok(response);
      }

      @GetMapping()
      public ResponseEntity<ResponseBase<List<UsuarioClienteResponseDTO>>> index(@RequestHeader HttpHeaders headers) {

            // Validar se usuario é userManager
            accessService.isUserManager(headers);

            Cliente clienteManager = accessService.getClienteLogado(headers);

            List<UsuarioClienteResponseDTO> usuarios = service.index(clienteManager);

            var response = new ResponseBase<List<UsuarioClienteResponseDTO>>().setSuccess(true)
                        .setMessage(SUCCES_OPERATION)
                        .setStatus(HttpStatus.CREATED.value()).setData(usuarios);
            return ResponseEntity.ok(response);
      }

      @GetMapping("/{publicId}")
      public ResponseEntity<ResponseBase<UsuarioClienteResponseDTO>> show(@PathVariable String publicId,
                  @RequestHeader HttpHeaders headers) {

            // Validar se usuario é userManager
            accessService.isUserManager(headers);

            Cliente clienteManager = accessService.getClienteLogado(headers);

            UsuarioClienteResponseDTO usuario = service.show(publicId, clienteManager);

            var response = new ResponseBase<UsuarioClienteResponseDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
                        .setStatus(HttpStatus.CREATED.value()).setData(usuario);
            return ResponseEntity.ok(response);
      }

      @DeleteMapping("/{publicId}")
      public ResponseEntity<ResponseBase<UsuarioClienteParamDTO>> delete(@PathVariable String publicId,
                  @RequestHeader HttpHeaders headers) {

            // Validar se usuario é userManager
            accessService.isUserManager(headers);

            Cliente clienteManager = accessService.getClienteLogado(headers);

            service.delete(publicId, clienteManager);

            var response = new ResponseBase<UsuarioClienteParamDTO>().setSuccess(true).setMessage(SUCCES_OPERATION)
                        .setStatus(HttpStatus.CREATED.value());
            return ResponseEntity.ok(response);
      }

}
