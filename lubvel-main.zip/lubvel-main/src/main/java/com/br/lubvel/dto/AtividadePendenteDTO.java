package com.br.lubvel.dto;

import com.br.lubvel.models.Cliente;

public class AtividadePendenteDTO {
    private Long quantidade;
    private Long pendentes;
    private Cliente cliente;

    public Long getQuantidade() {
        return quantidade;
    }
    public void setQuantidade(Long quantidade) {
        this.quantidade = quantidade;
    }
    public Long getPendentes() {
        return pendentes;
    }
    public void setPendentes(Long pendentes) {
        this.pendentes = pendentes;
    }
    public Cliente getCliente() {
        return cliente;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
}
