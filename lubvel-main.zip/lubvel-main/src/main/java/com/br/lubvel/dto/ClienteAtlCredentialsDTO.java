package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ClienteAtlCredentialsDTO extends ClienteCredentialsDTO{
    
    @NotBlank(message = "Nova senha é obrigatória")
    @NotNull(message = "Nova senha é obrigatória")
    private String novaSenha;

    public String getNovaSenha() {
        return novaSenha;
    }
    public void setNovaSenha(String novaSenha) {
        this.novaSenha = novaSenha;
    }
}
