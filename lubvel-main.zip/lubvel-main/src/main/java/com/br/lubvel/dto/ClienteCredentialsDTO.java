package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ClienteCredentialsDTO {
    @NotBlank(message = "Email é obrigatório")
	@NotNull(message = "Email é obrigatório")
	private String clienteEmail;

	@NotBlank(message = "Senha é obrigatória")
	@NotNull(message = "Senha é obrigatória")
    private String password;

	@NotNull(message = "erro parametro faltando")
	private boolean requestAdmin;
	
	public String getClienteEmail() {
		return clienteEmail;
	}
	public void setClienteEmail(String clienteEmail) {
		this.clienteEmail = clienteEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isRequestAdmin() {
		return requestAdmin;
	}
	public void setRequestAdmin(boolean requestAdmin) {
		this.requestAdmin = requestAdmin;
	}

   
}
