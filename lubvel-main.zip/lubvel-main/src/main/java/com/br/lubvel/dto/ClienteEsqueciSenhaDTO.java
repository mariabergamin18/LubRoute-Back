package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ClienteEsqueciSenhaDTO {
   @NotBlank(message = "Email é obrigatório")
	@NotNull(message = "Email é obrigatório")
	private String email;
   
   @NotNull(message = "isAdmin é obrigatório")
   private Boolean isAdmin;


   public String getEmail() {
      return email;
   }
   public void setEmail(String email) {
      this.email = email;
   }
   public Boolean getIsAdmin() {
      return isAdmin;
   }
   public void setIsAdmin(Boolean isAdmin) {
      this.isAdmin = isAdmin;
   }
}
