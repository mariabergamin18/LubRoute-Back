package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ClienteRedefinirSenhaDTO {
   
   @NotBlank(message = "Senha é obrigatória")
   @NotNull(message = "Senha é obrigatória")
   private String senha;
   
   @NotBlank(message = "Token é obrigatório")
   @NotNull(message = "Token é obrigatório")
   private String token;
   
   public String getSenha() {
      return senha;
   }
   public void setSenha(String senha) {
      this.senha = senha;
   }
   public String getToken() {
      return token;
   }
   public void setToken(String token) {
      this.token = token;
   }
}
