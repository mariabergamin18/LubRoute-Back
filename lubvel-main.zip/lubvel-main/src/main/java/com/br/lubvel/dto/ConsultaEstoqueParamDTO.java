package com.br.lubvel.dto;

public class ConsultaEstoqueParamDTO {
   private String codigo;
   private Double quantidade;

   public String getCodigo() {
      return codigo;
   }

   public void setCodigo(String codigo) {
      this.codigo = codigo;
   }

   public Double getQuantidade() {
      return quantidade;
   }

   public void setQuantidade(Double quantidade) {
      this.quantidade = quantidade;
   }

}
