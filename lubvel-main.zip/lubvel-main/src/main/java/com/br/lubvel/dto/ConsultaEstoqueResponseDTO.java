package com.br.lubvel.dto;

public class ConsultaEstoqueResponseDTO {
    private String codigo;
    private boolean qtdSuficiente;
    private Double qtdNecessaria;
    private Double qtdDisponivel;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public boolean isQtdSuficiente() {
        return qtdSuficiente;
    }

    public void setQtdSuficiente(boolean qtdSuficiente) {
        this.qtdSuficiente = qtdSuficiente;
    }

    public Double getQtdNecessaria() {
        return qtdNecessaria;
    }

    public void setQtdNecessaria(Double qtdNecessaria) {
        this.qtdNecessaria = qtdNecessaria;
    }

    public Double getQtdDisponivel() {
        return qtdDisponivel;
    }

    public void setQtdDisponivel(Double qtdDisponivel) {
        this.qtdDisponivel = qtdDisponivel;
    }

}
