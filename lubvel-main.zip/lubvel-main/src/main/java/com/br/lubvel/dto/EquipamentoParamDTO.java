package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class EquipamentoParamDTO {
	
	@NotNull(message = "informe a descricao")
	@NotBlank(message = "informe a descricao")
	private String descricao;

	@NotNull(message = "informe o setor")
	@NotBlank(message = "informe o setor")
	private String idSetor;

	@NotNull(message = "informe a tag")
	@NotBlank(message = "informe a tag")
	private String tag;
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getIdSetor() {
		return idSetor;
	}
	public void setIdSetor(String idSetor) {
		this.idSetor = idSetor;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	
	
	

}
