package com.br.lubvel.dto;

public class EquipamentoResponseDTO {
	
	private String publicId;
	private String descricao;
	private String setor;
	private String setorPublicId;
	private String tag;
	
	public String getPublicId() {
		return publicId;
	}
	public void setPublicId(String publicId) {
		this.publicId = publicId;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	public String getSetorPublicId() {
		return setorPublicId;
	}
	public void setSetorPublicId(String setorPublicId) {
		this.setorPublicId = setorPublicId;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}

	
	
}
