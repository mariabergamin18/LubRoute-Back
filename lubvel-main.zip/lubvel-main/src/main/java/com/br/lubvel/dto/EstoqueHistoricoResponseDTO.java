package com.br.lubvel.dto;

public class EstoqueHistoricoResponseDTO {
    private String publicId;
    private String produtoNome;
    private Long qtd;
    private Double preco;
    private String dataInclusao;
    
    public String getPublicId() {
        return publicId;
    }
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
    public String getProdutoNome() {
        return produtoNome;
    }
    public void setProdutoNome(String produtoNome) {
        this.produtoNome = produtoNome;
    }
    public Long getQtd() {
        return qtd;
    }
    public void setQtd(Long qtd) {
        this.qtd = qtd;
    }
    public Double getPreco() {
        return preco;
    }
    public void setPreco(Double preco) {
        this.preco = preco;
    }
    public String getDataInclusao() {
        return dataInclusao;
    }
    public void setDataInclusao(String dataInclusao) {
        this.dataInclusao = dataInclusao;
    }
    
    
}
