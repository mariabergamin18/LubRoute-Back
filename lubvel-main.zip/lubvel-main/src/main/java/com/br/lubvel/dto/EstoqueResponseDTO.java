package com.br.lubvel.dto;

public class EstoqueResponseDTO {
    private String publicId;
    private String produtoNome;
    private String tpLub;
    private Double qtd;
    private int unidades;
    private Double qtdPorUnidade;
    
    public String getPublicId() {
        return publicId;
    }
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
    public String getTpLub() {
        return tpLub;
    }
    public void setTpLub(String tpLub) {
        this.tpLub = tpLub;
    }
    public String getProdutoNome() {
        return produtoNome;
    }
    public void setProdutoNome(String produtoNome) {
        this.produtoNome = produtoNome;
    }
    public Double getQtd() {
        return qtd;
    }
    public void setQtd(Double qtd) {
        this.qtd = qtd;
    }
    public int getUnidades() {
        return unidades;
    }
    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }
    public Double getQtdPorUnidade() {
        return qtdPorUnidade;
    }
    public void setQtdPorUnidade(Double qtdPorUnidade) {
        this.qtdPorUnidade = qtdPorUnidade;
    }
    
}
