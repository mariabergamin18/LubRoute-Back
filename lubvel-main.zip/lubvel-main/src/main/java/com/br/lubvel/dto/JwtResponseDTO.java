package com.br.lubvel.dto;

import java.util.Date;

public class JwtResponseDTO {
    private String token;
    private String type = "Bearer";
    private String userId;
    private String username;
    private String codigoEmpresa;
    private Date expirationDate;
    private boolean firstAccess;
    private boolean admin;
    private boolean userCliente;
    private boolean userManager;
    private String nomeUsuario;

    // Constructors
    public JwtResponseDTO() {
    }

    public JwtResponseDTO(String token, String userId, String username, Date expirationDate, String nomeUsuario) {
        this.token = token;
        this.userId = userId;
        this.username = username;
        this.expirationDate = expirationDate;
        this.nomeUsuario = nomeUsuario;
    }

    // Getters and Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }
    public boolean isFirstAccess() {
        return firstAccess;
    }
    public void setFirstAccess(boolean firstAccess) {
        this.firstAccess = firstAccess;
    }
    public boolean isAdmin() {
        return admin;
    }
    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public boolean isUserCliente() {
        return userCliente;
    }

    public void setUserCliente(boolean userCliente) {
        this.userCliente = userCliente;
    }

    public boolean isUserManager() {
        return userManager;
    }

    public void setUserManager(boolean userManager) {
        this.userManager = userManager;
    }

    public String getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(String codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }
    
    
    
    
}
