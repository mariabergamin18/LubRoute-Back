package com.br.lubvel.dto;

import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;
import com.br.lubvel.models.Cliente;

public class MarcosDTO {
   private MarcoEnum marco;
   private String usuario;
   private String observacao;
   private EntidadeEnum entidade;
   private Long idReferencia;
   private Cliente cliente;
   private Boolean marcoAdmin = false;

   // Construtor padrão
   public MarcosDTO() {}

   // Construtor com todos os campos
   public MarcosDTO(MarcoEnum marco, String usuario, String observacao, EntidadeEnum entidade, Long idReferencia, Cliente cliente, Boolean marcoAdmin) {
       this.marco = marco;
       this.usuario = usuario;
       this.observacao = observacao;
       this.entidade = entidade;
       this.idReferencia = idReferencia;
       this.cliente = cliente;
       this.marcoAdmin = marcoAdmin;
   }

   // Getters e Setters
   public MarcoEnum getMarco() {
       return marco;
   }

   public void setMarco(MarcoEnum marco) {
       this.marco = marco;
   }

   public String getUsuario() {
       return usuario;
   }

   public void setUsuario(String usuario) {
       this.usuario = usuario;
   }

   public String getObservacao() {
       return observacao;
   }

   public void setObservacao(String observacao) {
       this.observacao = observacao;
   }

   public EntidadeEnum getEntidade() {
       return entidade;
   }

   public void setEntidade(EntidadeEnum entidade) {
       this.entidade = entidade;
   }

   public Long getIdReferencia() {
       return idReferencia;
   }

   public void setIdReferencia(Long idReferencia) {
       this.idReferencia = idReferencia;
   }

   public Cliente getCliente() {
    return cliente;
   }

   public void setCliente(Cliente cliente) {
    this.cliente = cliente;
   }

   public Boolean getMarcoAdmin() {
    return marcoAdmin;
   }

   public void setMarcoAdmin(Boolean marcoAdmin) {
    this.marcoAdmin = marcoAdmin;
   }

   

   
}
