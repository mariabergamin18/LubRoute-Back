package com.br.lubvel.dto;

import java.time.LocalDateTime;

public class MarcosResponseDTO {
   private String marco;
   private String tabela;
   private LocalDateTime dataHora;
   private String usuario;
   private String observacao;

   public MarcosResponseDTO() {}
   public MarcosResponseDTO(String marco, String tabela, LocalDateTime dataHora, String usuario, String observacao) {
      this.marco = marco;
      this.tabela = tabela;
      this.dataHora = dataHora;
      this.usuario = usuario;
      this.observacao = observacao;
   }

   // Getters and Setters
   public String getMarco() {
      return marco;
   }
   public void setMarco(String marco) {
      this.marco = marco;
   }
   public String getTabela() {
      return tabela;
   }
   public void setTabela(String tabela) {
      this.tabela = tabela;
   }
   public LocalDateTime getDataHora() {
      return dataHora;
   }
   public void setDataHora(LocalDateTime dataHora) {
      this.dataHora = dataHora;
   }
   public String getUsuario() {
      return usuario;
   }
   public void setUsuario(String usuario) {
      this.usuario = usuario;
   }
   public String getObservacao() {
      return observacao;
   }
   public void setObservacao(String observacao) {
      this.observacao = observacao;
   }   
}
