package com.br.lubvel.dto;

public class MetricasResponseDTO {
    private String descricao;
    private String quantidade;
    private String definicao;

    public MetricasResponseDTO(String descricao, String quantidade, String definicao) {
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.definicao = definicao;
    }

    public MetricasResponseDTO(String descricao, Long quantidade, String definicao) {
        this.descricao = descricao;
        this.quantidade = quantidade.toString();
        this.definicao = definicao;
    }

    public MetricasResponseDTO(String descricao, Double quantidade, String definicao) {
        this.descricao = descricao;
        this.quantidade = quantidade.toString();
        this.definicao = definicao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }
    public String getDefinicao() {
        return definicao;
    }
    public void setDefinicao(String definicao) {
        this.definicao = definicao;
    }
}
