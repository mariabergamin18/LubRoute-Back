package com.br.lubvel.dto;

public class NotificacaoDTO {
    private String publicId;
    private String mensagem;
    private String titulo;
    private String dataHoraNotificacao;
    private boolean lida;
    private String dataHoraLeitura;
    private boolean allowMarkAsRead;

    public String getPublicId() {
        return publicId;
    }
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
    public String getMensagem() {
        return mensagem;
    }
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getDataHoraNotificacao() {
        return dataHoraNotificacao;
    }
    public void setDataHoraNotificacao(String dataHoraNotificacao) {
        this.dataHoraNotificacao = dataHoraNotificacao;
    }
    public boolean isLida() {
        return lida;
    }
    public void setLida(boolean lida) {
        this.lida = lida;
    }
    public String getDataHoraLeitura() {
        return dataHoraLeitura;
    }
    public void setDataHoraLeitura(String dataHoraLeitura) {
        this.dataHoraLeitura = dataHoraLeitura;
    }
    public boolean isAllowMarkAsRead() {
        return allowMarkAsRead;
    }
    public void setAllowMarkAsRead(boolean allowMarkAsRead) {
        this.allowMarkAsRead = allowMarkAsRead;
    }
    
}
