package com.br.lubvel.dto;

import java.util.List;

public class OperacaoDashBoardAdminDTO {
  
    private String empresaNome;
    private int produtosBaixoEstoque;
    private int clientesCadastros;
    private List<ProdutoClienteBaixoEstoqueDTO> produtosClienteBaixoEstoque;
    

    public int getProdutosBaixoEstoque() {
        return produtosBaixoEstoque;
    }
    public void setProdutosBaixoEstoque(int produtosBaixoEstoque) {
        this.produtosBaixoEstoque = produtosBaixoEstoque;
    }
    public int getClientesCadastros() {
        return clientesCadastros;
    }
    public void setClientesCadastros(int clientesCadastros) {
        this.clientesCadastros = clientesCadastros;
    }
    public List<ProdutoClienteBaixoEstoqueDTO> getProdutosClienteBaixoEstoque() {
        return produtosClienteBaixoEstoque;
    }
    public void setProdutosClienteBaixoEstoque(List<ProdutoClienteBaixoEstoqueDTO> produtosClienteBaixoEstoque) {
        this.produtosClienteBaixoEstoque = produtosClienteBaixoEstoque;
    }  
    public String getEmpresaNome() {
        return empresaNome;
    }
    public void setEmpresaNome(String empresaNome) {
        this.empresaNome = empresaNome;
    }


    

    
}
