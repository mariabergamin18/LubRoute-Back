package com.br.lubvel.dto;

public class OperacaoDashBoardDTO {
    private int atividadesDia;
    private int atividadesSemana;
    private int produtosBaixoEstoque;
    private String empresaNome;
    private String empresaCnpj;
    
    public int getAtividadesDia() {
        return atividadesDia;
    }
    public void setAtividadesDia(int atividadesDia) {
        this.atividadesDia = atividadesDia;
    }
    public int getAtividadesSemana() {
        return atividadesSemana;
    }
    public void setAtividadesSemana(int atividadesSemana) {
        this.atividadesSemana = atividadesSemana;
    }
    public int getProdutosBaixoEstoque() {
        return produtosBaixoEstoque;
    }
    public void setProdutosBaixoEstoque(int produtosBaixoEstoque) {
        this.produtosBaixoEstoque = produtosBaixoEstoque;
    }
    public String getEmpresaNome() {
        return empresaNome;
    }
    public void setEmpresaNome(String empresaNome) {
        this.empresaNome = empresaNome;
    }
    public String getEmpresaCnpj() {
        return empresaCnpj;
    }
    public void setEmpresaCnpj(String empresaCnpj) {
        this.empresaCnpj = empresaCnpj;
    }

    

    
}
