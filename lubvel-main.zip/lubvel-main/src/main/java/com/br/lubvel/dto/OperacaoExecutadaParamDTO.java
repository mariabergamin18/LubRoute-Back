package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class OperacaoExecutadaParamDTO {

    @NotBlank(message = "Operacao é obrigatória")
    @NotNull(message = "Operacao é obrigatória")
    private String operacaoPublicId;
    
    @NotBlank(message = "DataHora é obrigatória")
    @NotNull(message = "DataHora é obrigatória")
    private String dataHoraExecucao;
    
    private String observacao;

    private Double quantidadeLubrificante;

    public String getOperacaoPublicId() {
        return operacaoPublicId;
    }
    public void setOperacaoPublicId(String operacaoPublicId) {
        this.operacaoPublicId = operacaoPublicId;
    }
    public String getDataHoraExecucao() {
        return dataHoraExecucao;
    }
    public void setDataHoraExecucao(String dataHoraExecucao) {
        this.dataHoraExecucao = dataHoraExecucao;
    }
    public String getObservacao() {
        return observacao;
    }
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    public Double getQuantidadeLubrificante() {
        return quantidadeLubrificante;
    }
    public void setQuantidadeLubrificante(Double quantidadeLubrificante) {
        this.quantidadeLubrificante = quantidadeLubrificante;
    }

    

}