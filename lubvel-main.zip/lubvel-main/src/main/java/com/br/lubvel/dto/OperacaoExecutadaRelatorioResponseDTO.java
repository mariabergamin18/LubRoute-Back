package com.br.lubvel.dto;

public class OperacaoExecutadaRelatorioResponseDTO {
   
   private String dataHoraExecucao;
   private String dataHoraExecucaoReal;
   private String operador;
   private String setor;
   private String equipamento;
   private String pontoDeLubrificacaoTag;
   private String observacao;
   
   public String getDataHoraExecucaoReal() {
      return dataHoraExecucaoReal;
   }
   public void setDataHoraExecucaoReal(String dataHoraExecucaoReal) {
      this.dataHoraExecucaoReal = dataHoraExecucaoReal;
   }
   public String getDataHoraExecucao() {
      return dataHoraExecucao;
   }
   public void setDataHoraExecucao(String dataHoraExecucao) {
      this.dataHoraExecucao = dataHoraExecucao;
   }
   public String getOperador() {
      return operador;
   }
   public void setOperador(String operador) {
      this.operador = operador;
   }
   public String getSetor() {
      return setor;
   }
   public void setSetor(String setor) {
      this.setor = setor;
   }
   public String getEquipamento() {
      return equipamento;
   }
   public void setEquipamento(String equipamento) {
      this.equipamento = equipamento;
   }
   public String getPontoDeLubrificacaoTag() {
      return pontoDeLubrificacaoTag;
   }
   public void setPontoDeLubrificacaoTag(String pontoDeLubrificacaoTag) {
      this.pontoDeLubrificacaoTag = pontoDeLubrificacaoTag;
   }
   public String getObservacao() {
      return observacao;
   }
   public void setObservacao(String observacao) {
      this.observacao = observacao;
   }
   
}
