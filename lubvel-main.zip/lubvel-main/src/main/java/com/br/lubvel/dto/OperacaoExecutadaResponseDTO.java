package com.br.lubvel.dto;

public class OperacaoExecutadaResponseDTO {   
   private String operacaoPublicId;
   private boolean success;
   private String message;

   public String getOperacaoPublicId() {
       return operacaoPublicId;
   }
   public void setOperacaoPublicId(String operacaoPublicId) {
       this.operacaoPublicId = operacaoPublicId;
   }
   public boolean isSuccess() {
       return success;
   }
   public void setSuccess(boolean success) {
       this.success = success;
   }
   public String getMessage() {
       return message;
   }
   public void setMessage(String message) {
       this.message = message;
   }
}
