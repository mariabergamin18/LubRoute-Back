package com.br.lubvel.dto;

public class OperacaoParamDTO {
    private String pontoDeLubrificacaoId;
    private String frequencia;
    private String atividade;
    private String dataHoraInicio;
    private Double quantidade;
    private String modoAplicacao;
    private Long qtdHoras;
    private String unidadeMedida;
    private Boolean atividadeRequerMaquinaDesligada;
    
    public String getPontoDeLubrificacaoId() {
        return pontoDeLubrificacaoId;
    }
    public void setPontoDeLubrificacaoId(String pontoDeLubrificacaoId) {
        this.pontoDeLubrificacaoId = pontoDeLubrificacaoId;
    }
    public String getFrequencia() {
        return frequencia;
    }
    public void setFrequencia(String frequencia) {
        this.frequencia = frequencia;
    }
    public String getAtividade() {
        return atividade;
    }
    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }
    public String getDataHoraInicio() {
        return dataHoraInicio;
    }
    public void setDataHoraInicio(String dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }
    public Double getQuantidade() {
        return quantidade;
    }
    public void setQuantidade(Double quantidade) {
        this.quantidade = quantidade;
    }
    public String getModoAplicacao() {
        return modoAplicacao;
    }
    public void setModoAplicacao(String modoAplicacao) {
        this.modoAplicacao = modoAplicacao;
    }
    public Long getQtdHoras() {
        return qtdHoras;
    }
    public void setQtdHoras(Long qtdHoras) {
        this.qtdHoras = qtdHoras;
    }
    public String getUnidadeMedida() {
        return unidadeMedida;
    }
    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }
    public Boolean getAtividadeRequerMaquinaDesligada() {
        return atividadeRequerMaquinaDesligada;
    }
    public void setAtividadeRequerMaquinaDesligada(Boolean atividadeRequerMaquinaDesligada) {
        this.atividadeRequerMaquinaDesligada = atividadeRequerMaquinaDesligada;
    }


    
}
