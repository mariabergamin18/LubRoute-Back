package com.br.lubvel.dto;

public class OperacaoPausaParamDTO {

   private String operacaoPublicId;

   private String dataInicio;

   private String dataFim;

   public String getOperacaoPublicId() {
      return operacaoPublicId;
   }

   public void setOperacaoPublicId(String operacaoPublicId) {
      this.operacaoPublicId = operacaoPublicId;
   }

   public String getDataInicio() {
      return dataInicio;
   }

   public void setDataInicio(String dataInicio) {
      this.dataInicio = dataInicio;
   }

   public String getDataFim() {
      return dataFim;
   }

   public void setDataFim(String dataFim) {
      this.dataFim = dataFim;
   }

}
