package com.br.lubvel.dto;


public class OperacaoPeriodoDTO {

    private EquipamentoResponseDTO equipamento;
    private OperacaoResponseDTO operacao;
    private String dataHoraParaExecucao;
    private boolean executado = false;
    private String tempoParaExecutar;
    private boolean isFuture; 
    private boolean isPaused;

    public EquipamentoResponseDTO getEquipamento() {
        return equipamento;
    }
    public void setEquipamento(EquipamentoResponseDTO equipamento) {
        this.equipamento = equipamento;
    }
    public OperacaoResponseDTO getOperacao() {
        return operacao;
    }
    public void setOperacao(OperacaoResponseDTO operacao) {
        this.operacao = operacao;
    }
    public String getDataHoraParaExecucao() {
        return dataHoraParaExecucao;
    }
    public void setDataHoraParaExecucao(String dataHoraParaExecucao) {
        this.dataHoraParaExecucao = dataHoraParaExecucao;
    }
    public boolean isExecutado() {
        return executado;
    }
    public void setExecutado(boolean executado) {
        this.executado = executado;
    }
    public String getTempoParaExecutar() {
        return tempoParaExecutar;
    }
    public void setTempoParaExecutar(String tempoParaExecutar) {
        this.tempoParaExecutar = tempoParaExecutar;
    }
    public boolean isFuture() {
        return isFuture;
    }
    public void setFuture(boolean isFuture) {
        this.isFuture = isFuture;
    }
    public boolean isPaused() {
        return isPaused;
    }
    public void setPaused(boolean isPaused) {
        this.isPaused = isPaused;
    }
    
}
