package com.br.lubvel.dto;

import java.util.List;

import com.br.lubvel.models.Cliente;

public class OperacaoPeriodoSchedulerDTO {

    private List<OperacaoPeriodoDTO> operacoesDoDia;

    private Cliente cliente;

    public List<OperacaoPeriodoDTO> getOperacoesDoDia() {
        return operacoesDoDia;
    }

    public void setOperacoesDoDia(List<OperacaoPeriodoDTO> operacoesDoDia) {
        this.operacoesDoDia = operacoesDoDia;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

}
