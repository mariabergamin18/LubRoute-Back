package com.br.lubvel.dto;

public class OperacaoResponseDTO {
    private String equipamentoId;
    private String equipamentoNome;
    private String publicId;
    private String pontoDeLubrificacaoId;
    private String pontoDeLubrificacaoTag;
    private String pontoDeLubrificacaoDescricaoComponente;
    private String frequencia;
    private String atividade;
    private String dataHoraInicio;
    private Long quantidade;
    private String modoAplicacao;
    private Long qtdHoras;
    private ProdutoResponseDTO produto;
    private String setorPublicId;
    private String unidadeMedida;
    private Boolean atividadeRequerMaquinaDesligada;
    
    public String getPublicId() {
        return publicId;
    }
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
    public String getPontoDeLubrificacaoId() {
        return pontoDeLubrificacaoId;
    }
    public void setPontoDeLubrificacaoId(String pontoDeLubrificacaoId) {
        this.pontoDeLubrificacaoId = pontoDeLubrificacaoId;
    }
    public String getFrequencia() {
        return frequencia;
    }
    public void setFrequencia(String frequencia) {
        this.frequencia = frequencia;
    }
    public String getAtividade() {
        return atividade;
    }
    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }
    public String getDataHoraInicio() {
        return dataHoraInicio;
    }
    public void setDataHoraInicio(String dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }
    public Long getQuantidade() {
        return quantidade;
    }
    public void setQuantidade(Long quantidade) {
        this.quantidade = quantidade;
    }
    public String getModoAplicacao() {
        return modoAplicacao;
    }
    public void setModoAplicacao(String modoAplicacao) {
        this.modoAplicacao = modoAplicacao;
    }
    public String getEquipamentoId() {
        return equipamentoId;
    }
    public void setEquipamentoId(String equipamentoId) {
        this.equipamentoId = equipamentoId;
    }
    public String getEquipamentoNome() {
        return equipamentoNome;
    }
    public void setEquipamentoNome(String equipamentoNome) {
        this.equipamentoNome = equipamentoNome;
    }
    public String getPontoDeLubrificacaoTag() {
        return pontoDeLubrificacaoTag;
    }
    public void setPontoDeLubrificacaoTag(String pontoDeLubrificacaoTag) {
        this.pontoDeLubrificacaoTag = pontoDeLubrificacaoTag;
    }
    public String getPontoDeLubrificacaoDescricaoComponente() {
        return pontoDeLubrificacaoDescricaoComponente;
    }
    public void setPontoDeLubrificacaoDescricaoComponente(String pontoDeLubrificacaoDescricaoComponente) {
        this.pontoDeLubrificacaoDescricaoComponente = pontoDeLubrificacaoDescricaoComponente;
    }
    public Long getQtdHoras() {
        return qtdHoras;
    }
    public void setQtdHoras(Long qtdHoras) {
        this.qtdHoras = qtdHoras;
    }
    public ProdutoResponseDTO getProduto() {
        return produto;
    }
    public void setProduto(ProdutoResponseDTO produto) {
        this.produto = produto;
    }
    public String getSetorPublicId() {
        return setorPublicId;
    }
    public void setSetorPublicId(String setorPublicId) {
        this.setorPublicId = setorPublicId;
    }
    public String getUnidadeMedida() {
        return unidadeMedida;
    }
    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }
    public Boolean getAtividadeRequerMaquinaDesligada() {
        return atividadeRequerMaquinaDesligada;
    }
    public void setAtividadeRequerMaquinaDesligada(Boolean atividadeRequerMaquinaDesligada) {
        this.atividadeRequerMaquinaDesligada = atividadeRequerMaquinaDesligada;
    }

    
}
