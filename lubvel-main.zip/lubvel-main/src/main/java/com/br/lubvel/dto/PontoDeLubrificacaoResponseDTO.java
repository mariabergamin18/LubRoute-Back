package com.br.lubvel.dto;

public class PontoDeLubrificacaoResponseDTO {

    private String publicId;
    private String equipamentoPublicId;
    private String equipamento;
    private String produtoPublicId;
    private String tag;
    private String tipoLubrificante;
    private String descricaoComponente;
    private String lubrificante;

    public String getPublicId() {
        return publicId;
    }
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }
    public String getTipoLubrificante() {
        return tipoLubrificante;
    }
    public void setTipoLubrificante(String tipoLubrificante) {
        this.tipoLubrificante = tipoLubrificante;
    }
    public String getDescricaoComponente() {
        return descricaoComponente;
    }
    public void setDescricaoComponente(String descricaoComponente) {
        this.descricaoComponente = descricaoComponente;
    }
    public String getLubrificante() {
        return lubrificante;
    }
    public void setLubrificante(String lubrificante) {
        this.lubrificante = lubrificante;
    }
    public String getEquipamentoPublicId() {
        return equipamentoPublicId;
    }
    public void setEquipamentoPublicId(String equipamentoPublicId) {
        this.equipamentoPublicId = equipamentoPublicId;
    }
    public String getEquipamento() {
        return equipamento;
    }
    public void setEquipamento(String equipamento) {
        this.equipamento = equipamento;
    }
    public String getProdutoPublicId() {
        return produtoPublicId;
    }
    public void setProdutoPublicId(String produtoPublicId) {
        this.produtoPublicId = produtoPublicId;
    }
    
}