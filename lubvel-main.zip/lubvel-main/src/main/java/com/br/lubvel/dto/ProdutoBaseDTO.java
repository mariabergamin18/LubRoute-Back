package com.br.lubvel.dto;

public class ProdutoBaseDTO {

   private String nome;
   private String tipoLubrificante;

   //contructor
   public ProdutoBaseDTO(String nome, String tipoLubrificante) {
      this.nome = nome;
      this.tipoLubrificante = tipoLubrificante;
   }
   
   //constructor vazio
   public ProdutoBaseDTO() {
   }

   public String getNome() {
      return nome;
   }
   public void setNome(String nome) {
      this.nome = nome;
   }
   public String getTipoLubrificante() {
      return tipoLubrificante;
   }
   public void setTipoLubrificante(String tipoLubrificante) {
      this.tipoLubrificante = tipoLubrificante;
   }
   

}
