package com.br.lubvel.dto;

public class ProdutoBaseResponseDTO {
   private String publicId;
   private String nome;
   private String tipoLubrificante;
   
   public String getPublicId() {
      return publicId;
   }
   public void setPublicId(String publicId) {
      this.publicId = publicId;
   }
   public String getNome() {
      return nome;
   }
   public void setNome(String nome) {
      this.nome = nome;
   }
   public String getTipoLubrificante() {
      return tipoLubrificante;
   }
   public void setTipoLubrificante(String tipoLubrificante) {
      this.tipoLubrificante = tipoLubrificante;
   }
   
   
}
