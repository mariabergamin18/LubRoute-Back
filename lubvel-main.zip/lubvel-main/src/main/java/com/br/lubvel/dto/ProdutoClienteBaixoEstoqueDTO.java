package com.br.lubvel.dto;

import java.util.List;

public class ProdutoClienteBaixoEstoqueDTO {

   private String clientePublicId;
   private String clienteNome;
   private List<String> produtosPublicId;

   public String getClientePublicId() {
      return clientePublicId;
   }
   public void setClientePublicId(String clientePublicId) {
      this.clientePublicId = clientePublicId;
   }
   public String getClienteNome() {
      return clienteNome;
   }
   public void setClienteNome(String clienteNome) {
      this.clienteNome = clienteNome;
   }
   public List<String> getProdutosPublicId() {
      return produtosPublicId;
   }
   public void setProdutosPublicId(List<String> produtosPublicId) {
      this.produtosPublicId = produtosPublicId;
   }

}
