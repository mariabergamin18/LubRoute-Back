package com.br.lubvel.dto;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ProdutoLoteDTO {

   @NotBlank(message = "Nome é obrigatório")
   @NotNull(message = "Nome é obrigatório")
   private String nome;

   @NotBlank(message = "Tipo de lubrificante é obrigatório")
   @NotNull(message = "Tipo de lubrificante é obrigatório")
   private String tipoLubrificante;

   @NotNull(message = "Produtos são obrigatórios")   
   private List<ProdutoParamDTO> produtos;

   public String getNome() {
      return nome;
   }
   public void setNome(String nome) {
      this.nome = nome;
   }
   public String getTipoLubrificante() {
      return tipoLubrificante;
   }
   public void setTipoLubrificante(String tipoLubrificante) {
      this.tipoLubrificante = tipoLubrificante;
   }
   public List<ProdutoParamDTO> getProdutos() {
      return produtos;
   }
   public void setProdutos(List<ProdutoParamDTO> produtos) {
      this.produtos = produtos;
   }   
}
