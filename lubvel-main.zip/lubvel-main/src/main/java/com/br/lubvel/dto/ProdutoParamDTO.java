package com.br.lubvel.dto;

public class ProdutoParamDTO {
    private String nome;
    private String tipoLubrificante;
    private Double qtMls;
    private Double qtGramas;
    private String codigo;
    private String produtoBasePublicId;
    private Double qtd;

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getTipoLubrificante() {
        return tipoLubrificante;
    }
    public void setTipoLubrificante(String tipoLubrificante) {
        this.tipoLubrificante = tipoLubrificante;
    }
    public Double getQtMls() {
        return qtMls;
    }
    public void setQtMls(Double qtMls) {
        this.qtMls = qtMls;
    }
    public Double getQtGramas() {
        return qtGramas;
    }
    public void setQtGramas(Double qtGramas) {
        this.qtGramas = qtGramas;
    }
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getProdutoBasePublicId() {
        return produtoBasePublicId;
    }
    public void setProdutoBasePublicId(String produtoBasePublicId) {
        this.produtoBasePublicId = produtoBasePublicId;
    }
    public Double getQtd() {
        return qtd;
    }
    public void setQtd(Double qtd) {
        this.qtd = qtd;
    }


    

   
    
}
