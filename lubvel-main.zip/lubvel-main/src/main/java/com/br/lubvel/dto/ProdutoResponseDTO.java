package com.br.lubvel.dto;

public class ProdutoResponseDTO {
    private String publicId;
    private String nome;
    private String tipoLubrificante;
    private Double qtMls;
    private Double qtGramas;

    public String getPublicId() {
        return publicId;
    }
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getTipoLubrificante() {
        return tipoLubrificante;
    }
    public void setTipoLubrificante(String tipoLubrificante) {
        this.tipoLubrificante = tipoLubrificante;
    }
    public Double getQtMls() {
        return qtMls;
    }
    public void setQtMls(Double qtMls) {
        this.qtMls = qtMls;
    }
    public Double getQtGramas() {
        return qtGramas;
    }
    public void setQtGramas(Double qtdGramas) {
        this.qtGramas = qtdGramas;
    }
    
    
}
