package com.br.lubvel.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class PtLubParamDTO{
    
    @NotNull(message = "O id do equipamento é obrigatório")
    @NotBlank(message = "O id do equipamento é obrigatório")
    private String equipamentoId;

    @NotNull(message = "O id do produto é obrigatório")
    @NotBlank(message = "O id do produto é obrigatório")
    private String produtoId;   

    @NotNull(message = "A tag é obrigatória")
    @NotBlank(message = "A tag é obrigatória")
    private String tag;

    @NotNull(message = "A descricaoComponente é obrigatória")
    @NotBlank(message = "A descricaoComponente é obrigatória")
    private String descricaoComponente;

    public String getEquipamentoId() {
        return equipamentoId;
    }
    public void setEquipamentoId(String equipamentoId) {
        this.equipamentoId = equipamentoId;
    }

    public String getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(String produtoId) {
        this.produtoId = produtoId;
    }
    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }
    public String getDescricaoComponente() {
        return descricaoComponente;
    }
    public void setDescricaoComponente(String descricaoComponente) {
        this.descricaoComponente = descricaoComponente;
    }    
    

}