package com.br.lubvel.dto;

import java.util.List;

public class RelatorioDTO {
    private List<String> cabecalho;
    private List<Object> dados;

    public List<String> getCabecalho() {
        return cabecalho;
    }
    public void setCabecalho(List<String> cabecalho) {
        this.cabecalho = cabecalho;
    }
    public List<Object> getDados() {
        return dados;
    }
    public void setDados(List<Object> dados) {
        this.dados = dados;
    }
}
