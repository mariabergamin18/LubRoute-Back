package com.br.lubvel.dto;

public class RelatorioOperacoesDTO {

    private String produto;
    private String quantidade;
    private String data;
    private String dataHoraExecucao;
    private String tpLub;
    private String observacao;
    private String atividade;
    public String getProduto() {
        return produto;
    }
    public void setProduto(String produto) {
        this.produto = produto;
    }
    public String getQuantidade() {
        return quantidade;
    }
    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
    public String getDataHoraExecucao() {
        return dataHoraExecucao;
    }
    public void setDataHoraExecucao(String dataHoraExecucao) {
        this.dataHoraExecucao = dataHoraExecucao;
    }
    public String getTpLub() {
        return tpLub;
    }
    public void setTpLub(String tpLub) {
        this.tpLub = tpLub;
    }
    public String getObservacao() {
        return observacao;
    }
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    public String getAtividade() {
        return atividade;
    }
    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    

}
