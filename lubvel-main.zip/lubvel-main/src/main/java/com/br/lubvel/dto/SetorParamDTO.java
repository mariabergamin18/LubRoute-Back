package com.br.lubvel.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class SetorParamDTO{

    @NotNull(message = "O nome do setor é obrigatório")
    @Size(min = 3, max = 50, message = "O nome do setor deve ter entre 3 e 50 caracteres")
    private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	

    
}
