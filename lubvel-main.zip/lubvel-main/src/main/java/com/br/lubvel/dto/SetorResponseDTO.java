package com.br.lubvel.dto;

public class SetorResponseDTO {

    private String publicId;

    private String nome;

	public String getPublicId() {
		return publicId;
	}

	public void setPublicId(String publicId) {
		this.publicId = publicId;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

    
    
    
}
