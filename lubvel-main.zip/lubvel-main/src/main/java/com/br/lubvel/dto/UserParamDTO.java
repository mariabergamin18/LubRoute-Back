package com.br.lubvel.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class UserParamDTO {

   @NotNull(message = "Nome é obrigatório")
	@NotBlank(message = "Nome é obrigatório")
	@Size(min = 3, max = 255, message = "Nome deve ter entre 3 e 255 caracteres")
	private String nome;

   @NotNull(message = "email é obrigatório")
	@NotBlank(message = "email é obrigatório")
	@Size(min = 3, max = 255, message = "Email deve ter entre 3 e 255 caracteres")
	@Email(message = "Email inválido")
	private String email;
 
   @NotNull(message = "cpf é obrigatório")
   @NotBlank(message = "cpf é obrigatório")
   @Size(min = 11, max = 11, message = "CPF deve ter 11 caracteres")
   private String cpf;
   
   @NotNull(message =  "endereco é obrigatório")
   @NotBlank(message = "endereco é obrigatório")
   @Size(min = 3, max = 255, message = "Endereço deve ter entre 3 e 255 caracteres")
   private String endereco;

   private String publicId;

   private Boolean usuarioAtual;

   // Getters and Setters
   public String getNome() {
      return nome;
   }

   public void setNome(String nome) {
      this.nome = nome;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public String getCpf() {
      return cpf;
   }

   public void setCpf(String cpf) {
      this.cpf = cpf;
   }

   public String getEndereco() {
      return endereco;
   }

   public void setEndereco(String endereco) {
      this.endereco = endereco;
   }

   public String getPublicId() {
      return publicId;
   }

   public void setPublicId(String publicId) {
      this.publicId = publicId;
   }

   public Boolean getUsuarioAtual() {
      return usuarioAtual;
   }

   public void setUsuarioAtual(Boolean usuarioAtual) {
      this.usuarioAtual = usuarioAtual;
   }

}
