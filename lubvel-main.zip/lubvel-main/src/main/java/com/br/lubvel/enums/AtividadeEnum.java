package com.br.lubvel.enums;

public enum AtividadeEnum {
	LIMPEZA,
	LUBRIFICACAO,
	MANUTENCAO
}
