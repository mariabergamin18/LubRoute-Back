package com.br.lubvel.enums;

public enum ComponenteEnum {
	OP1,
	OP2,
	OP3
}
