package com.br.lubvel.enums;

public enum DescricaoMetricaEnum {
   VALOR_GASTO_LUBRIFICACAO("Contabilização dos custos com base na quantidade de lubrificações executadas, volume de lubrificante utilizado e preço médio do lubrificante, considerando o histórico de compras."),
   QUANTIDADE_EQUIPAMENTOS("Número total de equipamentos cadastrados no sistema."),
   QUANTIDADE_PONTOS_LUBRIFICACAO("Número total de pontos de lubrificação cadastrados no sistema."),
   QUANTIDADE_OPERACOES("Número total de operações cadastradas no sistema."),
   QUANTIDADE_ATIVIDADES_EXECUTADAS("Número total de atividades do tipo especificado no título executadas no sistema."),
   VALOR_MEDIO_LUBRIFICACAO("Valor médio gasto com lubrificação por atividade. Calculado a partir do valor total gasto com lubrificação dividido pela quantidade de atividades de lubrificação executadas.");

   private final String descricao;

   DescricaoMetricaEnum(String descricao) {
      this.descricao = descricao;
   }

   public String getDescricao() {
      return descricao;
   }   


}
