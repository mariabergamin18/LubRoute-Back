package com.br.lubvel.enums;

public enum EntidadeEnum {
   CLIENTE("Cliente"),
   EQUIPAMENTO("Equipamento"),
   ESTOQUE("Estoque"),
   ESTOQUE_HISTORICO("EstoqueHistorico"),
   OPERACAO("Operacao"),
   OPERACAO_EXECUTADA("OperacaoExecutada"),
   PONTO_DE_LUBRIFICACAO("PontoDeLubrificacao"),
   PRODUTO("Produto"),
   PRODUTO_BASE("ProdutoBase"),
   SETOR("Setor"),
   USER("Usuario");

   private final String descricao;

   EntidadeEnum(String descricao) {
      this.descricao = descricao;
   }

   public String getDescricao() {
      return descricao;
   }

}
