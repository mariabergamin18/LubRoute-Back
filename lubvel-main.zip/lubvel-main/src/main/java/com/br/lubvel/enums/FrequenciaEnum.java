package com.br.lubvel.enums;

public enum FrequenciaEnum {
	HORARIA,
	DIARIA,
	SEMANAL,
	MENSAL,
	ANUAL,
	UNICA,
}
