package com.br.lubvel.enums;

public enum MarcoEnum {
   CRIACAO("Criacao"),
   ALTERACAO("Alteracao"),
   EXCLUSAO("Exclusao"),
   EXECUCAO("Execucao");

   private final String descricao;

   MarcoEnum(String descricao) {
       this.descricao = descricao;
   }

   public String getDescricao() {
       return descricao;
   }
}
