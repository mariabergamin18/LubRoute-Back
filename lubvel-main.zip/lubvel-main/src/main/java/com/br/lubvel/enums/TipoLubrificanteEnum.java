package com.br.lubvel.enums;

public enum TipoLubrificanteEnum {
	LIQUIDO,
	GRAXA
}
