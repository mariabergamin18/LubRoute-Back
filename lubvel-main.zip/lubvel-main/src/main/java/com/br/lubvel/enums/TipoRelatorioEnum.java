package com.br.lubvel.enums;

public enum TipoRelatorioEnum {
    EQUIPAMENTOS,
    ESTOQUE,
    OPERACOES,
    ATIVIDADESDIA
}
