package com.br.lubvel.enums;

public enum TituloEnum {

    // Definição dos valores do enum com descrições associadas
    ATIVIDADE_PENDENTE("Atividade Pendente de execução");    

    // Campo privado para armazenar o valor associado
    private final String descricao;

    // Construtor do enum
    TituloEnum(String descricao) {
        this.descricao = descricao;
    }

    // Método getter para acessar o valor associado
    public String getDescricao() {
        return descricao;
    }
}
