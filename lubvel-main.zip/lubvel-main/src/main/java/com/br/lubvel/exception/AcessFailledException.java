package com.br.lubvel.exception;

public class AcessFailledException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public AcessFailledException(String message){
        super(message);
    }
}
