package com.br.lubvel.exception;
import java.util.ArrayList;
import java.util.List;

import java.util.HashSet;
import java.util.Set;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.br.lubvel.dto.commons.ErrorDto;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(AcessFailledException.class)
    public ResponseEntity<ErrorDto> handleAcessFailledException(AcessFailledException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(401);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED.value()).body(errorDto);
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorDto> handleNotFoundException(NotFoundException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(404);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.badRequest().body(errorDto);
    }

    @ExceptionHandler(AlreadyExistsException.class)
    public ResponseEntity<ErrorDto> handleAlreadyExistsException(AlreadyExistsException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(409);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.badRequest().body(errorDto);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorDto> handleException(Exception e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage("Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
        errorDto.setSatus(500);
        errorDto.setTimestamp(System.currentTimeMillis());
        e.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorDto);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorDto> handleConstraintViolationException(ConstraintViolationException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(400);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.badRequest().body(errorDto);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorDto> handleIllegalArgumentException(IllegalArgumentException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(400);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.badRequest().body(errorDto);
    }

    @ExceptionHandler(NotificacaoException.class)
    public ResponseEntity<ErrorDto> handleNotificacaoException(NotificacaoException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(400);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.badRequest().body(errorDto);
    }

    @ExceptionHandler(OperacaoPausaException.class)
    public ResponseEntity<ErrorDto> handleOperacaoPausaException(OperacaoPausaException e) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setMessage(e.getMessage());
        errorDto.setSatus(400);
        errorDto.setTimestamp(System.currentTimeMillis());
        return ResponseEntity.badRequest().body(errorDto);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorDto> handleValidationExceptions(MethodArgumentNotValidException ex) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setSuccess(false);
        errorDto.setSatus(400);
        errorDto.setTimestamp(System.currentTimeMillis());
        List<String> errors = new ArrayList<>();
        String erroMsg = "";

        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String errorMessage = error.getDefaultMessage();
            errors.add(errorMessage);
        });
        Set<String> erroSet = new HashSet<String>(errors);
        erroMsg = erroSet.toString().replace("[", "").replace("]", "");
        
        errorDto.setMessage(erroMsg);

        return ResponseEntity.badRequest().body(errorDto);
    }

}
