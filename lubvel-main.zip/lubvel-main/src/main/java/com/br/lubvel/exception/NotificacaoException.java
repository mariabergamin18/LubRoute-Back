package com.br.lubvel.exception;

public class NotificacaoException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public NotificacaoException(String message){
        super(message);
    }
    
}
