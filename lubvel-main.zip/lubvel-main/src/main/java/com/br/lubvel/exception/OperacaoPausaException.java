package com.br.lubvel.exception;

public class OperacaoPausaException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public OperacaoPausaException(String message){
        super(message);
    }
   
}
