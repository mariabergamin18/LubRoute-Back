package com.br.lubvel.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "cliente")
public class Cliente {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
	private Long id;
	
	@Column(name = "publicId", unique = true)
	private String publicId;
	
	@Column(name = "nome")
	private String nome;
	
	@Column(name = "cnpj", unique = true)
	private String cnpj;
	
	@Column(name = "email", unique = true)
	private String email;
	
	@Column(name = "endereco")
	private String endereco;
	
	@Column(name = "passwordhash")
	private String passwordHash;
	
	@Column(name = "deleted")
	private boolean deleted;

	@Column(name = "firstAccess")
	private boolean firstAccess;

	@Column(name = "tokenRecuperacaoSenha", unique = true)
	private String tokenRecuperacaoSenha;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getPublicId() {
		return publicId;
	}

	public void setPublicId(String publicId) {
		this.publicId = publicId;
	}

	public boolean isFirstAccess() {
		return firstAccess;
	}
	public void setFirstAccess(boolean firstAccess) {
		this.firstAccess = firstAccess;
	}
	public String getTokenRecuperacaoSenha() {
		return tokenRecuperacaoSenha;
	}
	public void setTokenRecuperacaoSenha(String tokenRecuperacaoSenha) {
		this.tokenRecuperacaoSenha = tokenRecuperacaoSenha;
	}

}
