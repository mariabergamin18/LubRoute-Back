package com.br.lubvel.models;

import java.time.LocalDateTime;

import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "marco")
public class Marco {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "id")
   private Long id;

   @Enumerated(EnumType.STRING)
   @Column(nullable = false)
   private MarcoEnum marco;

   @Column(name = "data_hora", nullable = false)
   private LocalDateTime dataHora;

   @Column(nullable = false, length = 100)
   private String usuario;

   @Column(columnDefinition = "TEXT")
   private String observacao;

   @Enumerated(EnumType.STRING)
   @Column(nullable = false)
   private EntidadeEnum entidade;

   @Column(name = "id_referencia", nullable = false)
   private Long idReferencia;

   @ManyToOne
   @JoinColumn(name = "cliente_id")
   private Cliente cliente;

   @Column(name = "marco_admin")
   private Boolean marcoAdmin = false;

   // Constructor using DTO
   public Marco(MarcosDTO dto) {
      this.marco = dto.getMarco();
      this.usuario = dto.getUsuario();
      this.observacao = dto.getObservacao();
      this.entidade = dto.getEntidade();
      this.idReferencia = dto.getIdReferencia();
      this.dataHora = LocalDateTime.now();
      this.cliente = dto.getCliente();
   }

   // No-args constructor for JPA
   public Marco() {      
   }

   // All args constructor
   public Marco(Long id, MarcoEnum marco, LocalDateTime dataHora, String usuario, String observacao,
                EntidadeEnum entidade, Long idReferencia, Cliente cliente) {
      this.id = id;
      this.marco = marco;
      this.dataHora = dataHora;
      this.usuario = usuario;
      this.observacao = observacao;
      this.entidade = entidade;
      this.idReferencia = idReferencia;
      this.cliente = cliente;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public MarcoEnum getMarco() {
      return marco;
   }

   public void setMarco(MarcoEnum marco) {
      this.marco = marco;
   }

   public LocalDateTime getDataHora() {
      return dataHora;
   }

   public void setDataHora(LocalDateTime dataHora) {
      this.dataHora = dataHora;
   }

   public String getUsuario() {
      return usuario;
   }

   public void setUsuario(String usuario) {
      this.usuario = usuario;
   }

   public String getObservacao() {
      return observacao;
   }

   public void setObservacao(String observacao) {
      this.observacao = observacao;
   }

   public EntidadeEnum getEntidade() {
      return entidade;
   }

   public void setEntidade(EntidadeEnum entidade) {
      this.entidade = entidade;
   }

   public Long getIdReferencia() {
      return idReferencia;
   }

   public void setIdReferencia(Long idReferencia) {
      this.idReferencia = idReferencia;
   }

   public Cliente getCliente() {
      return cliente;
   }

   public void setCliente(Cliente cliente) {
      this.cliente = cliente;
   }

}
