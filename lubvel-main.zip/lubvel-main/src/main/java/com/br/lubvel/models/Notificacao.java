package com.br.lubvel.models;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "notificacao")
public class Notificacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "publicId", unique = true)
    private String publicId;

    @Column(name = "mensagem")
    private String mensagem;

    @Column(name = "titulo")
    private String titulo;

    @Column(name = "data_hora_notificacao")
    private Date dataHoraNotificacao;

    @Column(name = "lida")
    private boolean lida;

    @Column(name = "data_hora_leitura")
    private Date dataHoraLeitura;

    @ManyToOne
    @JoinColumn(name = "cliente_id", referencedColumnName = "id")
    private Cliente cliente;

    @Column(name = "atividade_pendente_id")
    private Long atividadePendenteId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPublicId() {
        return publicId;
    }

    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Date getDataHoraNotificacao() {
        return dataHoraNotificacao;
    }

    public void setDataHoraNotificacao(Date dataHoraNotificacao) {
        this.dataHoraNotificacao = dataHoraNotificacao;
    }

    public boolean isLida() {
        return lida;
    }

    public void setLida(boolean lida) {
        this.lida = lida;
    }

    public Date getDataHoraLeitura() {
        return dataHoraLeitura;
    }

    public void setDataHoraLeitura(Date dataHoraLeitura) {
        this.dataHoraLeitura = dataHoraLeitura;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Long getAtividadePendenteId() {
        return atividadePendenteId;
    }

    public void setAtividadePendenteId(Long atividadePendenteId) {
        this.atividadePendenteId = atividadePendenteId;
    }

}
