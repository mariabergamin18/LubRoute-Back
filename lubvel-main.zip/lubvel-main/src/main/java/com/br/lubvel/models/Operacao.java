package com.br.lubvel.models;

import java.util.Date;

import com.br.lubvel.enums.AtividadeEnum;
import com.br.lubvel.enums.FrequenciaEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "operacao")
public class Operacao {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "publicId", unique = true)
	private String publicId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ponto_de_lubrificacao_id", nullable = false)
	private PontoDeLubrificacao pontoDeLubrificacao;

	@Enumerated(EnumType.STRING)
	@Column(name = "frequencia")
	private FrequenciaEnum frequencia;

	@Enumerated(EnumType.STRING)
	@Column(name = "atividade")
	private AtividadeEnum atividade;

	@Column(name = "data_hora_inicio")
	private Date dataHoraInicio;

	@Column(name = "quantidade")
	private Double quantidade;

	@Column(name = "modoAplicacao")
	private String modoAplicacao;

	@Column(name = "qtdHoras")
	private Long qtdHoras;

	@Column(name = "unidadeMedida")
	private String unidadeMedida;

	@Column(name = "atividadeRequerMaquinaDesligada")
	private Boolean atividadeRequerMaquinaDesligada;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPublicId() {
		return publicId;
	}

	public void setPublicId(String publicId) {
		this.publicId = publicId;
	}

	public PontoDeLubrificacao getPontoDeLubrificacao() {
		return pontoDeLubrificacao;
	}

	public void setPontoDeLubrificacao(PontoDeLubrificacao pontoDeLubrificacao) {
		this.pontoDeLubrificacao = pontoDeLubrificacao;
	}

	public FrequenciaEnum getFrequencia() {
		return frequencia;
	}

	public void setFrequencia(FrequenciaEnum frequencia) {
		this.frequencia = frequencia;
	}

	public AtividadeEnum getAtividade() {
		return atividade;
	}

	public void setAtividade(AtividadeEnum atividade) {
		this.atividade = atividade;
	}

	public Date getDataHoraInicio() {
		return dataHoraInicio;
	}

	public void setDataHoraInicio(Date dataHoraInicio) {
		this.dataHoraInicio = dataHoraInicio;
	}

	public Double getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Double quantidade) {
		this.quantidade = quantidade;
	}

	public String getModoAplicacao() {
		return modoAplicacao;
	}

	public void setModoAplicacao(String modoAplicacao) {
		this.modoAplicacao = modoAplicacao;
	}

	public Long getQtdHoras() {
		return qtdHoras;
	}

	public void setQtdHoras(Long qtdHoras) {
		this.qtdHoras = qtdHoras;
	}

	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

	public Boolean getAtividadeRequerMaquinaDesligada() {
		return atividadeRequerMaquinaDesligada;
	}
	public void setAtividadeRequerMaquinaDesligada(Boolean atividadeRequerMaquinaDesligada) {
		this.atividadeRequerMaquinaDesligada = atividadeRequerMaquinaDesligada;
	}

}
