package com.br.lubvel.models;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "operacao_executada")
public class OperacaoExecutada {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "publicId", unique = true)
    private String publicId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "operacao_id", nullable = false)
    private Operacao operacao;

    @Column(name = "data_hora_execucao")
    private Date dataHoraExecucao;

    @Column(name = "data_hora_execucao_real")
    private Date dataHoraExecucaoReal;

    @Column(name = "observacao")
    private String observacao;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPublicId() {
        return publicId;
    }

    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }

    public Operacao getOperacao() {
        return operacao;
    }

    public void setOperacao(Operacao operacao) {
        this.operacao = operacao;
    }

    public Date getDataHoraExecucao() {
        return dataHoraExecucao;
    }

    public void setDataHoraExecucao(Date dataHoraExecucao) {
        this.dataHoraExecucao = dataHoraExecucao;
    }

    public Date getDataHoraExecucaoReal() {
        return dataHoraExecucaoReal;
    }

    public void setDataHoraExecucaoReal(Date dataHoraExecucaoReal) {
        this.dataHoraExecucaoReal = dataHoraExecucaoReal;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

}
