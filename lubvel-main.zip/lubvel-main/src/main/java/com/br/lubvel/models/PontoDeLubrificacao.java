package com.br.lubvel.models;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "ponto_de_lubrificacao")
public class PontoDeLubrificacao {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "publicId", unique = true)
	private String publicId;

	@Column(name = "descricaoComponente", nullable = false)
	private String descricaoComponente;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "equipamento_id", nullable = false)
	private Equipamento equipamento;

	@Column(name = "tag", unique = true)
	private String tag;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "produto_id", nullable = false)
	private ProdutoBase produto;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPublicId() {
		return publicId;
	}

	public void setPublicId(String publicId) {
		this.publicId = publicId;
	}

	public String getDescricaoComponente() {
		return descricaoComponente;
	}

	public void setDescricaoComponente(String descricaoComponente) {
		this.descricaoComponente = descricaoComponente;
	}

	public Equipamento getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(Equipamento equipamento) {
		this.equipamento = equipamento;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public ProdutoBase getProduto() {
		return produto;
	}

	public void setProduto(ProdutoBase produto) {
		this.produto = produto;
	}

}
