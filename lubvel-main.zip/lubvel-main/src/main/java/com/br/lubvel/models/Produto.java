package com.br.lubvel.models;

import com.br.lubvel.dto.ProdutoResponseDTO;
import com.br.lubvel.enums.TipoLubrificanteEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "produto")
public class Produto {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "publicId", unique = true)
	private String publicId;

	@Column(name = "nome", unique = true)
	private String nome;

	@Enumerated(EnumType.STRING)
	@Column(name = "tipo_lubrificante")
	private TipoLubrificanteEnum tipoLubrificante;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "produto_base_id", nullable = false)
	private ProdutoBase produtoBase;

	@Column(name = "qtMls")
	private Double qtMls;

	@Column(name = "qtGramas")
	private Double qtGramas;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPublicId() {
		return publicId;
	}

	public void setPublicId(String publicId) {
		this.publicId = publicId;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public TipoLubrificanteEnum getTipoLubrificante() {
		return tipoLubrificante;
	}

	public void setTipoLubrificante(TipoLubrificanteEnum tipoLubrificante) {
		this.tipoLubrificante = tipoLubrificante;
	}

	public Double getQtMls() {
		return qtMls;
	}

	public void setQtMls(Double qtMls) {
		this.qtMls = qtMls;
	}

	public Double getQtGramas() {
		return qtGramas;
	}

	public void setQtGramas(Double qtGramas) {
		this.qtGramas = qtGramas;
	}

	public ProdutoBase getProdutoBase() {
		return produtoBase;
	}

	public void setProdutoBase(ProdutoBase produtoBase) {
		this.produtoBase = produtoBase;
	}

	public ProdutoResponseDTO toDTO() {
		ProdutoResponseDTO dto = new ProdutoResponseDTO();
		dto.setPublicId(publicId);
		dto.setNome(nome);
		dto.setTipoLubrificante(tipoLubrificante.toString());
		dto.setQtMls(qtMls);
		dto.setQtGramas(qtGramas);
		return dto;
	}

}
