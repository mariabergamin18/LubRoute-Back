package com.br.lubvel.models;

import com.br.lubvel.dto.ProdutoBaseResponseDTO;
import com.br.lubvel.dto.ProdutoResponseDTO;
import com.br.lubvel.enums.TipoLubrificanteEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "produto_base")
public class ProdutoBase {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "id")
   private Long id;

   @Column(name = "publicId", unique = true)
   private String publicId;

   @Column(name = "nome", unique = true)
   private String nome;

   @Enumerated(EnumType.STRING)
   @Column(name = "tipo_lubrificante")
   private TipoLubrificanteEnum tipoLubrificante;

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getPublicId() {
      return publicId;
   }

   public void setPublicId(String publicId) {
      this.publicId = publicId;
   }

   public String getNome() {
      return nome;
   }

   public void setNome(String nome) {
      this.nome = nome;
   }

   public TipoLubrificanteEnum getTipoLubrificante() {
      return tipoLubrificante;
   }

   public void setTipoLubrificante(TipoLubrificanteEnum tipoLubrificante) {
      this.tipoLubrificante = tipoLubrificante;
   }

   public ProdutoResponseDTO toDTO() {
      ProdutoResponseDTO dto = new ProdutoResponseDTO();
      dto.setPublicId(publicId);
      dto.setNome(nome);
      dto.setTipoLubrificante(tipoLubrificante.toString());
      return dto;
   }

   public ProdutoBaseResponseDTO toDTOBase() {
      ProdutoBaseResponseDTO dto = new ProdutoBaseResponseDTO();
      dto.setPublicId(publicId);
      dto.setNome(nome);
      dto.setTipoLubrificante(tipoLubrificante.toString());
      return dto;
   }

   


}
