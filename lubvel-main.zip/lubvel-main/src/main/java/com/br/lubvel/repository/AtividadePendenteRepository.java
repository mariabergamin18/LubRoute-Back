package com.br.lubvel.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.br.lubvel.models.AtividadePendente;
import com.br.lubvel.models.Cliente;

public interface AtividadePendenteRepository extends JpaRepository<AtividadePendente, Long> {        
        @Query("SELECT a FROM AtividadePendente a " +
                        "WHERE a.cliente = :cliente AND CAST(a.data AS date) = :data")
        Optional<AtividadePendente> findByClienteAndData(
                        @Param("cliente") Cliente cliente,
                        @Param("data") LocalDate data);

        @Query("SELECT a.data FROM AtividadePendente a WHERE a.cliente = :cliente")
        List<Date> recuperarDatasAtividadesPendentes(@Param("cliente") Cliente cliente);

        @Query("SELECT a FROM AtividadePendente a " +
               "WHERE a.cliente = :cliente AND CAST(a.data AS date) IN :datas")
        List<AtividadePendente> findByClienteAndDataIn(
                @Param("cliente") Cliente cliente,
                @Param("datas") List<LocalDate> datas);

}
