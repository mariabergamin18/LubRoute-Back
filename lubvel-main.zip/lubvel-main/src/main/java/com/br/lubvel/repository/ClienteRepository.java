package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.br.lubvel.models.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

	Optional<Cliente> findByCnpj(String cnpj);

	Optional<Cliente> findByEmail(String email);

	Optional<Cliente> findByCnpjOrEmail(String cnpj, String email);

	Optional<Cliente> findByPublicId(String publicId);

	Optional<Cliente> findByTokenRecuperacaoSenha(String token);

	@Query("SELECT c.email FROM Cliente c")
   List<String> findAllEmails();
}
