package com.br.lubvel.repository;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Equipamento;
import com.br.lubvel.models.Setor;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipamentoRepository extends JpaRepository<Equipamento, Long> {

    List<Equipamento> findByCliente(Cliente cliente);
    
    Optional<Equipamento> findByPublicId (String publicId);

    List<Equipamento> findBySetor(Setor setor);
}

