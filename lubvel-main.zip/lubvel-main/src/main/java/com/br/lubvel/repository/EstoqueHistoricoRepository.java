package com.br.lubvel.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.EstoqueHistorico;
import com.br.lubvel.models.Cliente;
import java.util.List;
import java.util.Optional;

public interface EstoqueHistoricoRepository extends JpaRepository<EstoqueHistorico, Long>{
    Optional<EstoqueHistorico> findByPublicId(String publicId);

    List<EstoqueHistorico> findByCliente(Cliente cliente);
}
