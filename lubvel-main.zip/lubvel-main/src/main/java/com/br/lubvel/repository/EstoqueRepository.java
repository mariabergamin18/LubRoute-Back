package com.br.lubvel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Estoque;

public interface EstoqueRepository extends JpaRepository<Estoque, Long>{
    public Estoque findByPublicId(String publicId);

    public List<Estoque> findByCliente(Cliente cliente);
}
