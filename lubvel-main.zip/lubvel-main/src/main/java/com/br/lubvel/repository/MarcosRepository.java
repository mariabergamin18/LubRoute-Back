package com.br.lubvel.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Marco;

public interface MarcosRepository extends JpaRepository<Marco, Long> {

    /**
     * Método para buscar os marcos por entidade e lista de ids de referência.
     *
     * @param operacaoExecutada    a entidade a ser filtrada
     * @param idsOperacaoExecutada a lista de ids de referência
     * @return uma lista de objetos Marco que correspondem aos critérios de busca
     */
    List<Marco> findByEntidadeAndIdReferenciaIn(EntidadeEnum entidade, List<Long> idsReferencia);

    List<Marco> findByCliente(Cliente cliente);

    /**
     * Busca marcos por cliente e intervalo de datas
     * Converte as datas do banco para comparar apenas a parte da data (sem hora)
     *
     * @param cliente    o cliente dos marcos
     * @param dataInicio a data inicial do período de busca
     * @param dataFim    a data final do período de busca
     * @return lista de marcos que correspondem aos critérios de busca
     */
    @Query("SELECT m FROM Marco m " +
            "WHERE m.cliente = :cliente " +
            "AND m.dataHora BETWEEN :dataInicio AND :dataFim")
    List<Marco> findByClienteAndDataHoraBetween(
            @Param("cliente") Cliente cliente,
            @Param("dataInicio") LocalDateTime dataInicio,
            @Param("dataFim") LocalDateTime dataFim);

}