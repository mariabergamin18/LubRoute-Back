package com.br.lubvel.repository;

import java.time.LocalDate;

import com.br.lubvel.dto.MetricasResponseDTO;
import com.br.lubvel.enums.AtividadeEnum;
import com.br.lubvel.models.Cliente;

public interface MetricasRepository {
    MetricasResponseDTO getValorGastoLubrificacao(LocalDate dataInicio, LocalDate dataFim, Cliente cliente);
    MetricasResponseDTO getQuantidadeEquipamentos(Cliente cliente);
    MetricasResponseDTO getQuantidadePontosLubrificacao(Cliente cliente);
    MetricasResponseDTO getQuantidadeOperacoes(Cliente cliente);    
    MetricasResponseDTO getQuantidadeAtividadesExecutadasPorTipo(LocalDate dataInicio, LocalDate dataFim, Cliente cliente, AtividadeEnum tipoAtividade);
}
