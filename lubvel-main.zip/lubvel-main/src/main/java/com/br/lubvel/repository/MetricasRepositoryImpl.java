package com.br.lubvel.repository;

import java.time.LocalDate;

import org.springframework.stereotype.Repository;

import com.br.lubvel.dto.MetricasResponseDTO;
import com.br.lubvel.enums.AtividadeEnum;
import com.br.lubvel.enums.DescricaoMetricaEnum;
import com.br.lubvel.models.Cliente;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class MetricasRepositoryImpl implements MetricasRepository {

    @PersistenceContext
    private EntityManager entityManager;


    @Override
    public MetricasResponseDTO getValorGastoLubrificacao(LocalDate dataInicio, LocalDate dataFim, Cliente cliente) {
        // Usando uma query nativa para chamar a função do PostgreSQL
        Object[] result = (Object[]) entityManager.createNativeQuery(
                "SELECT * FROM calcular_gasto_lubrificante(CAST(:dataInicio AS DATE), CAST(:dataFim AS DATE), CAST(:clienteId AS INTEGER))")
                .setParameter("dataInicio", java.sql.Date.valueOf(dataInicio)) // Converte LocalDate para java.sql.Date
                .setParameter("dataFim", java.sql.Date.valueOf(dataFim)) // Converte LocalDate para java.sql.Date
                .setParameter("clienteId", cliente.getId()) // Cliente ID como Long
                .getSingleResult();

        // Monta o DTO com os resultados
        String descricao = (String) result[0];
        String valorTotal = (String) result[1];

        return new MetricasResponseDTO(descricao, valorTotal, DescricaoMetricaEnum.VALOR_GASTO_LUBRIFICACAO.getDescricao());
    }

    @Override
    public MetricasResponseDTO getQuantidadeEquipamentos(Cliente cliente) {
        return entityManager.createQuery(
                "SELECT new com.br.lubvel.dto.MetricasResponseDTO('Quantidade de Equipamentos', COUNT(e), :descricao) " +
                        "FROM Equipamento e WHERE e.cliente = :cliente",
                MetricasResponseDTO.class)
                .setParameter("cliente", cliente)
                .setParameter("descricao", DescricaoMetricaEnum.QUANTIDADE_EQUIPAMENTOS.getDescricao())
                .getSingleResult();
    }

    @Override
    public MetricasResponseDTO getQuantidadePontosLubrificacao(Cliente cliente) {
        return entityManager.createQuery(
                "SELECT new com.br.lubvel.dto.MetricasResponseDTO('Quantidade de Pontos de Lubrificação', COUNT(p), :descricao) " +
                        "FROM PontoDeLubrificacao p WHERE p.equipamento.cliente = :cliente",
                MetricasResponseDTO.class)
                .setParameter("cliente", cliente)
                .setParameter("descricao", DescricaoMetricaEnum.QUANTIDADE_PONTOS_LUBRIFICACAO.getDescricao())
                .getSingleResult();
    }

    @Override
    public MetricasResponseDTO getQuantidadeOperacoes(Cliente cliente) {
        return entityManager.createQuery(
                "SELECT new com.br.lubvel.dto.MetricasResponseDTO('Quantidade de Operações', COUNT(o), :descricao) " +
                        "FROM Operacao o WHERE o.pontoDeLubrificacao.equipamento.cliente = :cliente",
                MetricasResponseDTO.class)
                .setParameter("cliente", cliente)
                .setParameter("descricao", DescricaoMetricaEnum.QUANTIDADE_OPERACOES.getDescricao())
                .getSingleResult();
    }    

    @Override
    public MetricasResponseDTO getQuantidadeAtividadesExecutadasPorTipo(LocalDate dataInicio, LocalDate dataFim,
            Cliente cliente, AtividadeEnum tipoAtividade) {
        return entityManager.createQuery(
                "SELECT new com.br.lubvel.dto.MetricasResponseDTO(:tipoAtividade || ' executadas', COUNT(o), :descricao) " +
                        "FROM OperacaoExecutada o WHERE DATE(o.dataHoraExecucao) BETWEEN :dataInicio AND :dataFim AND o.operacao.atividade = :tipoAtividade AND o.operacao.pontoDeLubrificacao.equipamento.cliente = :cliente",
                MetricasResponseDTO.class)
                .setParameter("dataInicio", java.sql.Date.valueOf(dataInicio))
                .setParameter("dataFim", java.sql.Date.valueOf(dataFim))
                .setParameter("tipoAtividade", tipoAtividade)
                .setParameter("cliente", cliente)
                .setParameter("descricao", DescricaoMetricaEnum.QUANTIDADE_ATIVIDADES_EXECUTADAS.getDescricao())
                .getSingleResult();
    }

}
