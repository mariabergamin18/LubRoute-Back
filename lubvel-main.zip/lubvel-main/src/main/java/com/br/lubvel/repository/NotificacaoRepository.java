package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Notificacao;

public interface NotificacaoRepository extends JpaRepository<Notificacao, Long> {

    Notificacao findByAtividadePendenteId(Long id);

    List<Notificacao> findByCliente(Cliente cliente);

    @Query("SELECT n FROM Notificacao n WHERE n.cliente = :cliente ORDER BY n.lida ASC, n.dataHoraNotificacao DESC")
    List<Notificacao> buscarNotificacoesPorCliente(@Param("cliente") Cliente cliente);

    Optional<Notificacao> findByClienteAndPublicId(Cliente cliente, String publicId);

}
