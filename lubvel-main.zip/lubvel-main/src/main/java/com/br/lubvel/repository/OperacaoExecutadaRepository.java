package com.br.lubvel.repository;

import java.util.List;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.models.OperacaoExecutada;
import java.util.Optional;

public interface OperacaoExecutadaRepository  extends JpaRepository<OperacaoExecutada, Long>{
    Optional<OperacaoExecutada> findByPublicId(String publicId);

    List<OperacaoExecutada> findByOperacaoPontoDeLubrificacaoEquipamentoCliente(Cliente cliente);
    
    @Query("SELECT o FROM OperacaoExecutada o WHERE o.operacao.pontoDeLubrificacao.equipamento.cliente = :cliente " +
           "AND o.observacao IS NOT NULL AND o.observacao <> '' " +
           "AND CAST(o.dataHoraExecucao AS date) >= CAST(:dataInicio AS date) " +
           "AND CAST(o.dataHoraExecucao AS date) <= CAST(:dataFim AS date) " +
           "ORDER BY o.dataHoraExecucao")
    List<OperacaoExecutada> findByClienteAndDataBetweenWithObservacao(
            @Param("cliente") Cliente cliente, 
            @Param("dataInicio") Date dataInicio, 
            @Param("dataFim") Date dataFim);

    List<OperacaoExecutada> findByOperacao(Operacao operacao);
}


