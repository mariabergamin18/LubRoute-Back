package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.models.OperacaoPausa;

public interface OperacaoPausaRepository extends JpaRepository<OperacaoPausa, Long> {

   public Optional<OperacaoPausa> findByPublicId(String publicId);   

   public List<OperacaoPausa> findByOperacao(Operacao operacao);

   public List<OperacaoPausa> findByOperacaoPontoDeLubrificacaoEquipamentoCliente(Cliente cliente);
   
}
