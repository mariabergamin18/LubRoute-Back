package com.br.lubvel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Operacao;

import java.util.List;
import java.util.Optional;

public interface OperacaoRepository extends JpaRepository<Operacao, Long> {

        Optional<Operacao> findByPublicId(String publicId);

        List<Operacao> findByPontoDeLubrificacaoEquipamentoCliente(Cliente cliente);

}
