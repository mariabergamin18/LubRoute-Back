package com.br.lubvel.repository;

import java.util.Optional;
import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Equipamento;
import com.br.lubvel.models.PontoDeLubrificacao;
import com.br.lubvel.models.Setor;

public interface PontoDeLubrificacaoRepository extends JpaRepository<PontoDeLubrificacao, Long> {

    Optional<PontoDeLubrificacao> findByPublicId(String publicId);

    List<PontoDeLubrificacao> findByEquipamento(Equipamento equipamento);

    List<PontoDeLubrificacao> findByEquipamentoSetor(Setor setor);

    List<PontoDeLubrificacao> findByEquipamentoCliente(Cliente cliente);

    Optional<PontoDeLubrificacao> findByTag(String tag);

}
