package com.br.lubvel.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.ProdutoBase;

public interface ProdutoBaseRepository extends JpaRepository<ProdutoBase, Long> {
    
   public Optional<ProdutoBase> findByPublicId(String publicId);
   
}
