package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.br.lubvel.models.Produto;
import com.br.lubvel.models.ProdutoBase;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    public Optional<Produto> findByPublicId(String publicId);

    public List<Produto> findByProdutoBase(ProdutoBase produtoBase);

    @Query("SELECT p FROM Produto p WHERE p.produtoBase.publicId IN :codigos")
    List<Produto> findByProdutosBase(@Param("codigos") List<String> codigos);
}
