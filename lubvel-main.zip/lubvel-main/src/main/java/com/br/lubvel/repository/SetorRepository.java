package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Setor;

public interface SetorRepository extends JpaRepository<Setor, Long> {

    List<Setor> findByCliente(Cliente cliente);
    
    Optional<Setor> findByPublicId(String publicId);
}

