package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.lubvel.models.User;

public interface UserRepository extends JpaRepository<User,Long>{

     Optional<User> findByEmail(String email);

     Optional<User> findByTokenRecuperacaoSenha(String token);
     
     List<User> findByEmailOrCpf(String email, String cpf);

     Optional<User> findByPublicId(String publicId);

     Optional<User> findByCpf(String cpf);

}
