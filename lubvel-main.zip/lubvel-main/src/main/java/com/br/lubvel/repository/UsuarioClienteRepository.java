package com.br.lubvel.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.UsuarioCliente;

public interface UsuarioClienteRepository extends JpaRepository<UsuarioCliente, Long> {

   Optional<UsuarioCliente> findByEmail(String email);

   List<UsuarioCliente> findByEmailOrCpf(String email, String cpf);

   Optional<UsuarioCliente> findByPublicId(String publicId);

   List<UsuarioCliente> findByCliente(Cliente clienteManager);

   @Query("SELECT c.email FROM UsuarioCliente c")
   List<String> findAllEmails();

   Optional<UsuarioCliente> findByTokenRecuperacaoSenha(String token);

}
