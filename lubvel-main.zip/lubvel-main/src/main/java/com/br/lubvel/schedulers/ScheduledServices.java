/**
 * Este serviço é restrito para execução em agendamentos automáticos.
 * Não deve ser utilizado por controladores públicos ou exposto via API.
 */

package com.br.lubvel.schedulers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.br.lubvel.schedulers.services.SchedulVerificaAtividadesPendentes;

@Component
public class ScheduledServices {
    @Autowired
    private SchedulVerificaAtividadesPendentes schedulVerificaAtividadesPendentes;

    // executa a verificação de atividades pendentes todos os dias às 00:00
    @Transactional
    @Scheduled(cron = "0 0 0 * * *")
    public void verificaAtividadesPendentes() {
        Date dataAtual = new Date();
        System.out.println("Executando verificação de atividades pendentes do dia: " + dataAtual);
        schedulVerificaAtividadesPendentes.verificarAtividadesDoDia(dataAtual);
    }
}
