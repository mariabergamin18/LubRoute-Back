package com.br.lubvel.schedulers.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.OperacaoPeriodoSchedulerDTO;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.OperacaoPausa;
import com.br.lubvel.services.ClienteService;
import com.br.lubvel.services.OperacaoExecutadaService;
import com.br.lubvel.services.OperacaoPausaService;
import com.br.lubvel.services.OperacaoPeriodoService;

@Service
public class AtividadesDiaService {

    private final OperacaoPeriodoService operacaoPeriodoService;
    private final OperacaoExecutadaService operacaoExecutadaService;
    private final ClienteService clienteService;
    private final OperacaoPausaService operacaoPausaService;

    @Autowired
    public AtividadesDiaService(
            OperacaoPeriodoService operacaoPeriodoService,
            OperacaoExecutadaService operacaoExecutadaService,
            ClienteService clienteService,
            OperacaoPausaService operacaoPausaService) {
        this.operacaoPeriodoService = operacaoPeriodoService;
        this.operacaoExecutadaService = operacaoExecutadaService;
        this.clienteService = clienteService;
        this.operacaoPausaService = operacaoPausaService;
    }

    public List<OperacaoPeriodoSchedulerDTO> recuperarAtividadesDoDia() {
        List<Cliente> clientes = clienteService.findAll();
        List<OperacaoPeriodoSchedulerDTO> operacoes = new ArrayList<>();
        LocalDate dataAtual = LocalDate.now();

        for (Cliente cliente : clientes) {
            tratarOperacoes(cliente, operacoes, dataAtual, dataAtual);
        }

        return operacoes;
    }

    public void tratarOperacoes(Cliente cliente, List<OperacaoPeriodoSchedulerDTO> operacoes, LocalDate dataInicio,
            LocalDate dataFim) {
        List<OperacaoExecutada> operacoesExecutadas = operacaoExecutadaService.findAllCliente(cliente);
        List<OperacaoPausa> operacoesPausadas = operacaoPausaService.getOperacoesPausadas(cliente);
        List<OperacaoPeriodoDTO> operacoesDoDia = operacaoPeriodoService.getAtividadesPeriodoInformado(cliente,
                dataInicio, dataFim, operacoesExecutadas, operacoesPausadas);
        OperacaoPeriodoSchedulerDTO operacoesDoDiaScheduler = new OperacaoPeriodoSchedulerDTO();
        operacoesDoDiaScheduler.setCliente(cliente);
        operacoesDoDiaScheduler.setOperacoesDoDia(operacoesDoDia);
        operacoes.add(operacoesDoDiaScheduler);
    }
}