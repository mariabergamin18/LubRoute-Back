/**
 * Este serviço é restrito para execução em agendamentos automáticos.
 * Não deve ser utilizado por controladores públicos ou exposto via API.
 */

package com.br.lubvel.schedulers.services;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.AtividadePendenteDTO;
import com.br.lubvel.dto.NotificacaoDTO;
import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.OperacaoPeriodoSchedulerDTO;
import com.br.lubvel.models.AtividadePendente;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.services.AtividadePendenteService;
import com.br.lubvel.services.NotificacaoService;
import com.br.lubvel.utils.Utils;

@Service
public class SchedulVerificaAtividadesPendentes {

    @Autowired
    private AtividadesDiaService atividadesDiaService;

    @Autowired
    private AtividadePendenteService atividadePendteService;

    @Autowired
    private NotificacaoService notificacaoService;

    public void verificarAtividadesDoDia(Date dataAtual) {

        try {
            // recupera as atividades do dia para cada cliente
            List<OperacaoPeriodoSchedulerDTO> operacoes = atividadesDiaService.recuperarAtividadesDoDia();

            // cria um map com as atividades do dia para cada cliente
            Map<Cliente, List<OperacaoPeriodoDTO>> mapOperacoes = new HashMap<>();
            for (OperacaoPeriodoSchedulerDTO operacaoPeriodoSchedulerDTO : operacoes) {
                mapOperacoes.put(operacaoPeriodoSchedulerDTO.getCliente(),
                        operacaoPeriodoSchedulerDTO.getOperacoesDoDia());
            }

            // verifica se há atividades pendentes para o dia para cada cliente
            for (Cliente cliente : mapOperacoes.keySet()) {

                // Verifica se já ha salvo atividades pendentes para o dia
                AtividadePendente atividadePendenteSalva = atividadePendteService.findByClienteAndData(cliente, LocalDate.now());
                if (atividadePendenteSalva != null) {
                    System.out.println("Atividades pendentes já salvas para o dia: " + dataAtual);
                } else {

                    Long quantidadeAtividadesPendentes = 0L;
                    List<OperacaoPeriodoDTO> operacoesDoDia = mapOperacoes.get(cliente);
                    for (OperacaoPeriodoDTO operacaoPeriodoDTO : operacoesDoDia) {
                        if (!operacaoPeriodoDTO.isExecutado() && !operacaoPeriodoDTO.isPaused()) {
                            quantidadeAtividadesPendentes++;
                        }
                    }

                    // se houver atividades pendentes para o dia que não foram salvas
                    AtividadePendenteDTO atividadePendenteDTO = new AtividadePendenteDTO();
                    atividadePendenteDTO.setCliente(cliente);
                    atividadePendenteDTO.setQuantidade(quantidadeAtividadesPendentes);
                    atividadePendenteDTO.setPendentes(quantidadeAtividadesPendentes);
                    AtividadePendente atividadePendente = atividadePendteService.save(atividadePendenteDTO);
                    // cria notificação para o cliente
                    notificacaoService.addNotificacaoAtividade(atividadePendente);
                    System.out.println("Verificação de atividades pendentes finalizada para o dia: " + dataAtual);
                    verificaAtividadesMaquinaDesligada(operacoesDoDia, cliente, dataAtual);
                }
            }
        } catch (Exception e) {
            System.out.println("Erro ao verificar atividades pendentes para o dia: " + dataAtual);
            e.printStackTrace();
        }
    }

    private void verificaAtividadesMaquinaDesligada(List<OperacaoPeriodoDTO> operacoesDoDia, Cliente cliente,
            Date dataAtual) {
        System.out.println("Verificando atividades que requerem máquina desligada para o dia: " + dataAtual);
        // Verifica se tem operações para o dia que precisa ter a máquina desligada e gera notificação
        List<OperacaoPeriodoDTO> operacoesMaquinaDesligada = operacoesDoDia.stream()
                .filter(obj -> Boolean.TRUE.equals(obj.getOperacao().getAtividadeRequerMaquinaDesligada())  && !obj.isExecutado() && !obj.isPaused())
                .toList();
        if (!operacoesMaquinaDesligada.isEmpty()) {
            String dataDDMMYYY = Utils.dateToStringDdMmYyyy(dataAtual);            
            dataDDMMYYY = dataDDMMYYY.substring(0, 10);
            dataDDMMYYY = dataDDMMYYY.replace("-", "/");

            StringBuilder sb = new StringBuilder();
            sb.append("Atenção! Algumas atividades para o dia ");
            sb.append(dataDDMMYYY).append(" requerem que a máquina esteja desligada. ");
            sb.append("Consulte a lista de atividades pendentes para mais detalhes.");
            
            // Cria notificação para o cliente informando que a máquina precisa estar desligada
            NotificacaoDTO notificacaoDTO = new NotificacaoDTO();
            notificacaoDTO.setTitulo("Máquina Desligada Necessária");
            notificacaoDTO.setMensagem(sb.toString());
            // Adiciona a notificação ao cliente            
            notificacaoService.adicionarNotificacao(notificacaoDTO, cliente);
        }
        System.out.println("Verificação de atividades que requerem máquina desligada finalizada para o dia: " + dataAtual);
    }

}
