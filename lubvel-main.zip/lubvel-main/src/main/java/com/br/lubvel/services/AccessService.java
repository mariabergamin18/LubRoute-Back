package com.br.lubvel.services;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import jakarta.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.ClienteAtlCredentialsDTO;
import com.br.lubvel.dto.ClienteCredentialsDTO;
import com.br.lubvel.dto.ClienteEsqueciSenhaDTO;
import com.br.lubvel.dto.ClienteRedefinirSenhaDTO;
import com.br.lubvel.dto.JwtResponseDTO;
import com.br.lubvel.dto.commons.JwtConfig;
import com.br.lubvel.exception.AcessFailledException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.User;
import com.br.lubvel.models.UsuarioCliente;
import com.br.lubvel.utils.EmailManager;
import com.br.lubvel.utils.SegurancaSenha;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@SuppressWarnings("deprecation")
@Service
public class AccessService {

	private static final Logger logger = LoggerFactory.getLogger(AccessService.class);

	@Autowired
	private ClienteService clienteManagerService;

	@Autowired
	private UsuarioClienteService clienteService;

	@Autowired
	private UserService userService;

	private JwtConfig jwtConfig;

	private static final String ERRO_ACESSO_MSG = "Acesso negado: Usuário ou senha inválidos";

	public AccessService(JwtConfig jwtConfig) {
		this.jwtConfig = jwtConfig;
	}

	public JwtResponseDTO authenticateAndGetJWT(ClienteCredentialsDTO userCredentialsDTO) {
		logger.info("Iniciando autenticação para usuário.");
		JwtResponseDTO jwtDto = new JwtResponseDTO();

		try {
			if (userCredentialsDTO.isRequestAdmin()) {
				logger.info("Tentativa de autenticação como admin.");
				jwtDto = tratarAcessoAdmin(userCredentialsDTO);
			} else {
				logger.info("Tentativa de autenticação como cliente/orquestrador.");
				jwtDto = tratarAcessoClienteOrquestrador(userCredentialsDTO);
			}
			logger.info("Autenticação realizada com sucesso.");
		} catch (Exception e) {
			logger.error("Erro ao autenticar usuário.", e);
			throw new AcessFailledException("Ocorreu um erro ao tentar autenticar o usuário");
		}

		return jwtDto;

	}

	private JwtResponseDTO tratarAcessoClienteOrquestrador(ClienteCredentialsDTO credentials){
		logger.info("Tratando acesso de cliente/orquestrador.");
		List<String> emailsClienteManager = clienteManagerService.findAllEmails();
		List<String> emailsCliente = clienteService.findAllEmails();

		if (emailsClienteManager.contains(credentials.getClienteEmail())) {
			return tratarAcessoClienteManager(credentials);
		} else if (emailsCliente.contains(credentials.getClienteEmail())) {
			return tratarAcessoCliente(credentials);
		} else {
			logger.warn("Acesso negado: email não encontrado.");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}
	}

	private JwtResponseDTO tratarAcessoClienteManager(ClienteCredentialsDTO userCredentialsDTO) {
		logger.info("Autenticando cliente manager.");
		JwtResponseDTO jwtDto = new JwtResponseDTO();
		Cliente cliente = validarAcessoClienteManager(userCredentialsDTO);
		boolean primeiroAcesso = verificarPrimeiroAcessoManager(cliente);

		jwtDto = gerarJwtDtoClienteManager(cliente, primeiroAcesso);

		if (primeiroAcesso) {
			logger.info("Primeiro acesso detectado para cliente manager.");
			jwtDto.setFirstAccess(true);
		}
		return jwtDto;
	}

	private JwtResponseDTO tratarAcessoCliente(ClienteCredentialsDTO userCredentialsDTO) {
		logger.info("Autenticando cliente usuário.");
		JwtResponseDTO jwtDto = new JwtResponseDTO();
		UsuarioCliente cliente = validarAcessoCliente(userCredentialsDTO);
		boolean primeiroAcesso = cliente.isFirstAccess();

		jwtDto = gerarJwtDtoCliente(cliente, primeiroAcesso);

		if (primeiroAcesso) {
			logger.info("Primeiro acesso detectado para cliente usuário.");
			jwtDto.setFirstAccess(true);
		}
		return jwtDto;
	}

	private JwtResponseDTO tratarAcessoAdmin(ClienteCredentialsDTO userCredentialsDTO) {
		logger.info("Autenticando usuário admin.");
		JwtResponseDTO jwtDto = new JwtResponseDTO();
		User usuario = validarAcessoAdmin(userCredentialsDTO);
		Boolean primeiroAcesso = usuario.isFirstAccess();

		jwtDto = gerarJwtDtoAdmin(usuario, primeiroAcesso);
		return jwtDto;

	}

	private JwtResponseDTO gerarJwtDtoCliente(UsuarioCliente cliente, boolean primeiroAcesso) {
		SecretKey key = Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
		Date exp = new Date(nowMillis + 14400000); // Expira em 4 horas

		String jwt = Jwts.builder()
				.setSubject(cliente.getPublicId())
				.claim("name", cliente.getNome())
				.claim("admin", false)
				.claim("codigo_empresa", cliente.getCliente().getPublicId())
				.claim("firstAccess", primeiroAcesso)
				.claim("userCliente", true)
				.claim("userManager", false)
				.setIssuedAt(now)
				.setExpiration(exp)
				.signWith(key, SignatureAlgorithm.HS256)
				.compact();

		JwtResponseDTO jwtDto = new JwtResponseDTO();
		jwtDto.setExpirationDate(exp);
		jwtDto.setToken(jwt);
		jwtDto.setUserId(cliente.getPublicId());
		jwtDto.setUsername(cliente.getEmail());
		jwtDto.setNomeUsuario(cliente.getNome());
		jwtDto.setAdmin(false);
		jwtDto.setUserCliente(true);
		jwtDto.setUserManager(false);
		jwtDto.setCodigoEmpresa(cliente.getCliente().getPublicId());

		return jwtDto;
	}

	private JwtResponseDTO gerarJwtDtoClienteManager(Cliente cliente, boolean primeiroAcesso) {
		SecretKey key = Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
		Date exp = new Date(nowMillis + 14400000); // Expira em 4 horas

		String jwt = Jwts.builder()
				.setSubject(cliente.getPublicId())
				.claim("name", cliente.getNome())
				.claim("admin", false)
				.claim("firstAccess", primeiroAcesso)
				.claim("userCliente", false)
				.claim("userManager", true)
				.setIssuedAt(now)
				.setExpiration(exp)
				.signWith(key, SignatureAlgorithm.HS256)
				.compact();

		JwtResponseDTO jwtDto = new JwtResponseDTO();
		jwtDto.setExpirationDate(exp);
		jwtDto.setToken(jwt);
		jwtDto.setUserId(cliente.getPublicId());
		jwtDto.setUsername(cliente.getEmail());
		jwtDto.setNomeUsuario(cliente.getNome());
		jwtDto.setAdmin(false);
		jwtDto.setUserCliente(false);
		jwtDto.setUserManager(true);

		return jwtDto;
	}

	private JwtResponseDTO gerarJwtDtoAdmin(User usuario, Boolean primeiroAcesso) {
		SecretKey key = Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
		Date exp = new Date(nowMillis + 14400000); // Expira em 4 horas

		String jwt = Jwts.builder()
				.setSubject(usuario.getCpf())
				.claim("name", usuario.getNome())
				.claim("admin", true)
				.claim("firstAccess", false)
				.claim("userCliente", false)
				.claim("userManager", false)
				.claim("firstAccess", primeiroAcesso)
				.setIssuedAt(now)
				.setExpiration(exp)
				.signWith(key, SignatureAlgorithm.HS256)
				.compact();

		JwtResponseDTO jwtDto = new JwtResponseDTO();
		jwtDto.setExpirationDate(exp);
		jwtDto.setToken(jwt);
		jwtDto.setAdmin(true);
		jwtDto.setUserCliente(false);
		jwtDto.setUserManager(false);
		jwtDto.setNomeUsuario(usuario.getNome());
		jwtDto.setFirstAccess(usuario.isFirstAccess());

		return jwtDto;
	}

	private User validarAcessoAdmin(ClienteCredentialsDTO userCredentialsDTO) {
		Optional<User> userAdmin = userService.findByEmail(userCredentialsDTO.getClienteEmail());
		if (userAdmin.isPresent()) {
			User userAdminFound = userAdmin.get();
			if (!SegurancaSenha.validarSenha(userCredentialsDTO.getPassword(), userAdminFound.getPasswordHash())) {
				logger.warn("Senha inválida para admin.");
				throw new AcessFailledException(ERRO_ACESSO_MSG);
			}
		} else {
			logger.warn("Usuário admin não encontrado.");
			throw new AcessFailledException(ERRO_ACESSO_MSG);
		}
		return userAdmin.get();
	}

	private boolean verificarPrimeiroAcessoManager(Cliente cliente) {
		return cliente.isFirstAccess();
	}

	private Cliente validarAcessoClienteManager(ClienteCredentialsDTO userCredentialsDTO) {
		Optional<Cliente> cliente = clienteManagerService.findByEmail(userCredentialsDTO.getClienteEmail());
		if (cliente.isPresent()) {
			Cliente clienteFounded = cliente.get();
			if (!SegurancaSenha.validarSenha(userCredentialsDTO.getPassword(), clienteFounded.getPasswordHash())) {
				logger.warn("Senha inválida para cliente manager.");
				throw new AcessFailledException(ERRO_ACESSO_MSG);
			}
		} else {
			logger.warn("Cliente manager não encontrado.");
			throw new AcessFailledException(ERRO_ACESSO_MSG);
		}
		return cliente.get();
	}

	private UsuarioCliente validarAcessoCliente(ClienteCredentialsDTO userCredentialsDTO) {
		Optional<UsuarioCliente> cliente = clienteService.findByEmail(userCredentialsDTO.getClienteEmail());
		if (cliente.isPresent()) {
			UsuarioCliente clienteFounded = cliente.get();
			if (!SegurancaSenha.validarSenha(userCredentialsDTO.getPassword(), clienteFounded.getPasswordHash())) {
				logger.warn("Senha inválida para cliente usuário.");
				throw new AcessFailledException(ERRO_ACESSO_MSG);
			}
		} else {
			logger.warn("Cliente usuário não encontrado.");
			throw new AcessFailledException(ERRO_ACESSO_MSG);
		}
		return cliente.get();
	}

	public Cliente getClienteLogado(HttpHeaders headers) {
		logger.info("Obtendo cliente logado.");
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		if (jwtResponseDTO.isFirstAccess()) {
			logger.warn("Primeiro acesso: operação não permitida.");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}
		String publicId = (jwtResponseDTO.isAdmin() || jwtResponseDTO.isUserCliente()) ? headers.getFirst("user-id")
				: jwtResponseDTO.getUserId();

		Cliente existingCliente = clienteManagerService.findByPublicId(publicId);

		return existingCliente;
	}

	public User getUserLogado(HttpHeaders headers) {
		logger.info("Obtendo usuário logado.");
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		Optional<User> existingUser = userService.findByEmail(jwtResponseDTO.getUsername());
		if (!existingUser.isPresent()) {
			logger.warn("Usuário não encontrado.");
			throw new AcessFailledException("Acesso negado");
		}

		return existingUser.get();
	}

	public JwtResponseDTO validateAccessAndReturnJwt(HttpHeaders headers) {
		logger.info("Validando token de acesso.");
		String token = extractTokenFromHeaders(headers);
		if (token == null || !isValidToken(token)) {
			logger.warn("Token inválido ou ausente.");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}

		Claims claims = parseTokenClaims(token);
		String publicId = claims.getSubject();
		String username = claims.get("name", String.class);
		boolean isAdmin = claims.get("admin", Boolean.class);
		boolean userCliente = claims.get("userCliente", Boolean.class);
		boolean userManager = claims.get("userManager", Boolean.class);
		boolean firstAccess = claims.get("firstAccess", Boolean.class);
		Date expirationDate = claims.getExpiration();

		JwtResponseDTO jwtResponseDTO = new JwtResponseDTO();
		jwtResponseDTO.setToken(token);
		jwtResponseDTO.setUserId(publicId);
		jwtResponseDTO.setUsername(username);
		jwtResponseDTO.setExpirationDate(expirationDate);
		jwtResponseDTO.setAdmin(isAdmin);
		jwtResponseDTO.setFirstAccess(firstAccess);
		jwtResponseDTO.setUserCliente(userCliente);
		jwtResponseDTO.setUserManager(userManager);

		return jwtResponseDTO;
	}

	private String extractTokenFromHeaders(HttpHeaders headers) {
		String authorizationHeader = headers.getFirst("Authorization");
		if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
			return authorizationHeader.replace("Bearer ", "");
		}
		return null;
	}

	private boolean isValidToken(String token) {
		try {
			SecretKey key = Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());
			Jwts.parser()
					.setSigningKey(key)
					.build()
					.parseClaimsJws(token);
			return true;
		} catch (Exception e) {
			logger.error("Falha ao validar token.", e);
			return false;
		}
	}

	private Claims parseTokenClaims(String token) {
		SecretKey key = Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());
		return Jwts.parser()
				.setSigningKey(key)
				.build()
				.parseClaimsJws(token)
				.getBody();
	}

	public JwtResponseDTO alterarSenhaOrquestrador(@Valid ClienteAtlCredentialsDTO credentials, HttpHeaders headers) {
		logger.info("Solicitação de alteração de senha para orquestrador.");
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		if (jwtResponseDTO.isAdmin()) {
			return alterarSenhaAdmin(credentials, headers);
		} else if (jwtResponseDTO.isUserManager()) {
			return alterarSenhaClienteManager(credentials, headers);
		} else if (jwtResponseDTO.isUserCliente()) {
			return alterarSenhaCliente(credentials, headers);
		} else {
			logger.warn("Acesso negado: Token inválido ou ausente");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}
	}



	public JwtResponseDTO alterarSenhaAdmin(@Valid ClienteAtlCredentialsDTO credentials, HttpHeaders headers) {
		logger.info("Alterando senha de admin.");
		User user = getUserLogadoPrimeiroAcesso(headers);
		user.setPasswordHash(SegurancaSenha.gerarHashSenha(credentials.getNovaSenha()));
		user.setFirstAccess(false);
		userService.save(user);

		return gerarJwtDtoAdmin(user, false);
	}

	public JwtResponseDTO alterarSenhaClienteManager(@Valid ClienteAtlCredentialsDTO credentials, HttpHeaders headers) {
		logger.info("Alterando senha de cliente manager.");
		Cliente cliente = getClienteManagerLogadoPrimeiroAcesso(headers);
		cliente.setPasswordHash(SegurancaSenha.gerarHashSenha(credentials.getNovaSenha()));
		cliente.setFirstAccess(false);
		clienteManagerService.save(cliente);

		JwtResponseDTO response = gerarJwtDtoClienteManager(cliente, false);
		return response;
	}

	private Cliente getClienteManagerLogadoPrimeiroAcesso(HttpHeaders headers) {
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		if (!jwtResponseDTO.isFirstAccess()) {
			logger.warn("Primeiro acesso não detectado para cliente manager.");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}
		String publicId = jwtResponseDTO.getUserId();

		Cliente existingCliente = clienteManagerService.findByPublicId(publicId);

		return existingCliente;
	}

	public JwtResponseDTO alterarSenhaCliente(@Valid ClienteAtlCredentialsDTO credentials, HttpHeaders headers) {
		logger.info("Alterando senha de cliente usuário.");
		UsuarioCliente cliente = getClienteLogadoPrimeiroAcesso(headers);
		cliente.setPasswordHash(SegurancaSenha.gerarHashSenha(credentials.getNovaSenha()));
		cliente.setFirstAccess(false);
		clienteService.save(cliente);

		JwtResponseDTO response = gerarJwtDtoCliente(cliente, false);
		return response;
	}

	private UsuarioCliente getClienteLogadoPrimeiroAcesso(HttpHeaders headers) {
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		if (!jwtResponseDTO.isFirstAccess()) {
			logger.warn("Primeiro acesso não detectado para cliente usuário.");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}
		String publicId = jwtResponseDTO.getUserId();

		return clienteService.findByPublicId(publicId);
	}

	private User getUserLogadoPrimeiroAcesso(HttpHeaders headers) {
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		if (!jwtResponseDTO.isFirstAccess()) {
			logger.warn("Primeiro acesso não detectado para usuário admin.");
			throw new AcessFailledException("Acesso negado: Token inválido ou ausente");
		}

		String cpf = jwtResponseDTO.getUserId();

		return userService.findByCpf(cpf);
	}

	public void isAdmin(HttpHeaders headers) {
		logger.info("Verificando permissão de admin.");
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		if (!jwtResponseDTO.isAdmin()) {
			logger.warn("Usuário sem permissão de admin.");
			throw new AcessFailledException("Acesso negado");
		}
	}

	private String gerarJwtDtoRecuperaSenha(String email, boolean isAdmin) {
		SecretKey key = Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
		Date exp = new Date(nowMillis + 14400000); // Expira em 4 horas

		String jwt = Jwts.builder()
				.setSubject(email)
				.claim("email", email)
				.claim("admin", isAdmin)
				.setIssuedAt(now)
				.setExpiration(exp)
				.signWith(key, SignatureAlgorithm.HS256)
				.compact();

		return jwt;
	}

	public void esqueciSenha(ClienteEsqueciSenhaDTO clienteEsqueciSenhaDTO) {
		logger.info("Solicitação de recuperação de senha recebida.");
		if (clienteEsqueciSenhaDTO.getIsAdmin().equals(Boolean.TRUE)) {
			tratarEsqueciSenhaAdmin(clienteEsqueciSenhaDTO.getEmail());
		} else {
			tratarEsqueciSenhaOrquestrador(clienteEsqueciSenhaDTO.getEmail());
		}

	}

	private void tratarEsqueciSenhaOrquestrador(String email){
		logger.info("Tratando recuperação de senha para orquestrador.");
		List<String> emailsClienteManager = clienteManagerService.findAllEmails();
		List<String> emailsCliente = clienteService.findAllEmails();

		if (emailsClienteManager.contains(email)) {
			tratarEsqueciSenhaClienteManager(email);
		} else if (emailsCliente.contains(email)) {
			tratarEsqueciSenhaCliente(email);
		}
	}

	public void tratarEsqueciSenhaAdmin(String email) {
		logger.info("Tratando recuperação de senha para admin.");
		Optional<User> user = userService.findByEmail(email);
		if (!user.isPresent()) {
			logger.error("Usuário admin para recuperação de senha não encontrado.");
			throw new RuntimeException("Ocorreu um erro ao tentar recuperar a senha");
		} else {

			User userFound = user.get();
			String tokenRecuperacaoSenha = gerarJwtDtoRecuperaSenha(email, true);
			userFound.setTokenRecuperacaoSenha(tokenRecuperacaoSenha);
			userService.save(userFound);

			EmailManager emailManager = new EmailManager();
			emailManager.sendEmailRecuperacaoSenha(userFound.getEmail(), tokenRecuperacaoSenha, userFound.getNome());
			logger.info("Email de recuperação de senha enviado para admin.");
		}
	}

	public void tratarEsqueciSenhaClienteManager(String email) {
		logger.info("Tratando recuperação de senha para cliente manager.");
		Optional<Cliente> cliente = clienteManagerService.findByEmail(email);
		if (!cliente.isPresent()) {
			logger.error("Cliente manager para recuperação de senha não encontrado.");
			throw new RuntimeException("Ocorreu um erro ao tentar recuperar a senha");
		} else {

			Cliente clienteFound = cliente.get();
			String tokenRecuperacaoSenha = gerarJwtDtoRecuperaSenha(email, false);
			clienteFound.setTokenRecuperacaoSenha(tokenRecuperacaoSenha);
			clienteManagerService.save(clienteFound);

			EmailManager emailManager = new EmailManager();
			emailManager.sendEmailRecuperacaoSenha(clienteFound.getEmail(), tokenRecuperacaoSenha, clienteFound.getNome());
			logger.info("Email de recuperação de senha enviado para cliente manager.");
		}
	}

	public void tratarEsqueciSenhaCliente(String email) {
		logger.info("Tratando recuperação de senha para cliente usuário.");
		Optional<UsuarioCliente> cliente = clienteService.findByEmail(email);
		if (!cliente.isPresent()) {
			logger.error("Cliente usuário para recuperação de senha não encontrado.");
			throw new RuntimeException("Ocorreu um erro ao tentar recuperar a senha");
		} else {

			UsuarioCliente clienteFound = cliente.get();
			String tokenRecuperacaoSenha = gerarJwtDtoRecuperaSenha(email, false);
			clienteFound.setTokenRecuperacaoSenha(tokenRecuperacaoSenha);
			clienteService.save(clienteFound);

			EmailManager emailManager = new EmailManager();
			emailManager.sendEmailRecuperacaoSenha(clienteFound.getEmail(), tokenRecuperacaoSenha, clienteFound.getNome());
			logger.info("Email de recuperação de senha enviado para cliente usuário.");
		}
	}

	public void redefinirSenha(@Valid ClienteRedefinirSenhaDTO clienteRedefinirSenhaDTO) {
		logger.info("Solicitação de redefinição de senha recebida.");
		if (!isValidToken(clienteRedefinirSenhaDTO.getToken())) {
			logger.error("Token inválido na redefinição de senha.");
			throw new RuntimeException("Token inválido");
		}

		Claims claims = parseTokenClaims(clienteRedefinirSenhaDTO.getToken());
		boolean isAdmin = claims.get("admin", Boolean.class);
		String email = claims.get("sub", String.class);
		if (isAdmin) {
			redefinirSenhaAdmin(clienteRedefinirSenhaDTO);
		} else {
			redefinirSenhaOrquestrador(clienteRedefinirSenhaDTO, email);
		}

	}

	private void redefinirSenhaOrquestrador(ClienteRedefinirSenhaDTO clienteRedefinirSenhaDTO, String email){
		logger.info("Redefinindo senha para orquestrador.");
		List<String> emailsClienteManager = clienteManagerService.findAllEmails();
		List<String> emailsCliente = clienteService.findAllEmails();

		if (emailsClienteManager.contains(email)) {
			redefinirSenhaClienteManager(clienteRedefinirSenhaDTO);
		} else if (emailsCliente.contains(email)) {
			redefinirSenhaCliente(clienteRedefinirSenhaDTO);
		} else {
			logger.warn("Email não encontrado para redefinição de senha.");
			throw new AcessFailledException("Token inválido ou ausente");
		}
	}

	private void redefinirSenhaClienteManager(@Valid ClienteRedefinirSenhaDTO clienteRedefinirSenhaDTO) {
		logger.info("Redefinindo senha para cliente manager.");
		Optional<Cliente> cliente = clienteManagerService
				.findByTokenRecuperacaoSenha(clienteRedefinirSenhaDTO.getToken());
		if (!cliente.isPresent()) {
			logger.error("Token inválido para redefinição de senha de cliente manager.");
			throw new RuntimeException("Token inválido");
		} else {
			Cliente clienteFound = cliente.get();
			clienteFound.setPasswordHash(SegurancaSenha.gerarHashSenha(clienteRedefinirSenhaDTO.getSenha()));
			clienteFound.setTokenRecuperacaoSenha(null);
			clienteManagerService.save(clienteFound);
			logger.info("Senha redefinida para cliente manager.");
		}
	}

	private void redefinirSenhaCliente(@Valid ClienteRedefinirSenhaDTO clienteRedefinirSenhaDTO) {
		logger.info("Redefinindo senha para cliente usuário.");
		Optional<UsuarioCliente> cliente = clienteService
				.findByTokenRecuperacaoSenha(clienteRedefinirSenhaDTO.getToken());
		if (!cliente.isPresent()) {
			logger.error("Token inválido para redefinição de senha de cliente usuário.");
			throw new RuntimeException("Token inválido");
		} else {
			UsuarioCliente clienteFound = cliente.get();
			clienteFound.setPasswordHash(SegurancaSenha.gerarHashSenha(clienteRedefinirSenhaDTO.getSenha()));
			clienteFound.setTokenRecuperacaoSenha(null);
			clienteService.save(clienteFound);
			logger.info("Senha redefinida para cliente usuário.");
		}
	}

	private void redefinirSenhaAdmin(@Valid ClienteRedefinirSenhaDTO clienteRedefinirSenhaDTO) {
		logger.info("Redefinindo senha para admin.");
		Optional<User> user = userService.findByTokenRecuperacaoSenha(clienteRedefinirSenhaDTO.getToken());
		if (!user.isPresent()) {
			logger.error("Token inválido para redefinição de senha de admin.");
			throw new RuntimeException("Token inválido");
		} else {
			User userFound = user.get();
			userFound.setPasswordHash(SegurancaSenha.gerarHashSenha(clienteRedefinirSenhaDTO.getSenha()));
			userFound.setTokenRecuperacaoSenha(null);
			userService.save(userFound);
			logger.info("Senha redefinida para admin.");
		}
	}

	public List<Cliente> getClientes() {
		logger.info("Obtendo lista de clientes.");
		return clienteManagerService.findAll();
	}

	public Cliente getClienteByPublicId(String publicId) {
		logger.info("Obtendo cliente por publicId.");
		return clienteManagerService.findByPublicId(publicId);
	}

	public void isUserManager(HttpHeaders headers) {
		logger.info("Verificando permissão de user manager.");
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);

		if (!jwtResponseDTO.isUserManager()) {
			logger.warn("Usuário sem permissão de user manager.");
			throw new AcessFailledException("Acesso negado - Usuario sem permissao");
		}
	}

	public String getNomeOperador(HttpHeaders headers) {
		logger.info("Obtendo nome do operador.");
		JwtResponseDTO jwtResponseDTO = validateAccessAndReturnJwt(headers);
		return jwtResponseDTO.getUsername();
	}
}
