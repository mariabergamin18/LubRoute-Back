package com.br.lubvel.services;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.AtividadePendenteDTO;
import com.br.lubvel.models.AtividadePendente;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.repository.AtividadePendenteRepository;
import com.br.lubvel.utils.Utils;

@Service
public class AtividadePendenteService {

    @Autowired
    private AtividadePendenteRepository repository;

    @Autowired
    private NotificacaoService notificacaoService;    

    public void executaAtividade(AtividadePendente atividade) {
        atividade.setQuantidade(atividade.getQuantidade() - 1);
        repository.save(atividade);

        checarUltimaAtividade(atividade);
    }

    private void checarUltimaAtividade(AtividadePendente atividadePendente) {
        if (atividadePendente.getQuantidade() == 0 || atividadePendente.getPendentes() == 0) {
            notificacaoService.desativaNotificacaoAtividade(atividadePendente);
        }
    }

    public AtividadePendente save(AtividadePendenteDTO atividadePendenteDTO) {
        AtividadePendente atividadePendente = dtoToEntity(atividadePendenteDTO);
        return repository.save(atividadePendente);
    }

    public AtividadePendente update(AtividadePendente atividadePendente) {
        atividadePendente.setAtualizadoEm(new Date());
        return repository.save(atividadePendente);
    }

    private AtividadePendente dtoToEntity(AtividadePendenteDTO atividadePendenteDTO) {
        AtividadePendente atividadePendente = new AtividadePendente();
        atividadePendente.setCliente(atividadePendenteDTO.getCliente());
        atividadePendente.setData(new Date());
        atividadePendente.setAtualizadoEm(new Date());
        atividadePendente.setPublicId(Utils.gerarPublicId());
        atividadePendente.setQuantidade(atividadePendenteDTO.getQuantidade());
        atividadePendente.setPendentes(atividadePendenteDTO.getPendentes());
        return atividadePendente;
    }

    public AtividadePendente findByClienteAndData(Cliente cliente, LocalDate dataAtual) {
        return repository.findByClienteAndData(cliente, dataAtual).orElse(null);
    }

    public List<LocalDate> recuperarDatasAtividadesPendentes(Cliente cliente) {
        List<Date> datas = repository.recuperarDatasAtividadesPendentes(cliente);
        List<LocalDate> datasLocalDate = new ArrayList<>();
        for (Date data : datas) {
            LocalDate localDate = data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            datasLocalDate.add(localDate);
        }
        return datasLocalDate;
        
    }    

    public Map<LocalDate, AtividadePendente> findByClienteAndDatas(Cliente cliente, List<LocalDate> datas) {
        Map<LocalDate, AtividadePendente> map = new HashMap<>();
        if (datas == null || datas.isEmpty()) {
            return map;
        }
        List<AtividadePendente> atividades = repository.findByClienteAndDataIn(cliente, datas);
        for (AtividadePendente atividade : atividades) {
            LocalDate localDate = atividade.getData().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            map.put(localDate, atividade);
        }
        return map;
    }    

}
