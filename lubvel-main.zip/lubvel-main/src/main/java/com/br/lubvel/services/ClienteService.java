package com.br.lubvel.services;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.ClienteDTO;
import com.br.lubvel.dto.ClienteParamDTO;
import com.br.lubvel.exception.AlreadyExistsException;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.repository.ClienteRepository;
import com.br.lubvel.utils.EmailManager;
import com.br.lubvel.utils.SegurancaSenha;
import com.br.lubvel.utils.Utils;

import jakarta.validation.Valid;

@Service
public class ClienteService {

	@Autowired
	private ClienteRepository repository;

	public void store(@Valid ClienteParamDTO clienteDto) {
		validateCliente(clienteDto);
		String password = Utils.gerarSenhaPrimaria();

		Cliente cliente = fromParamDtoToEntity(clienteDto);
		cliente.setPublicId(Utils.gerarPublicId());
		cliente.setPasswordHash(SegurancaSenha.gerarHashSenha(password));
		cliente.setFirstAccess(true);

		EmailManager eManager = new EmailManager();
		eManager.enviarSenha(password, cliente.getEmail(), cliente.getNome());

		repository.save(cliente);

	}

	public List<ClienteDTO> showAll() {
		List<Cliente> clientes = findAll();
		List<ClienteDTO> response = createClienteDtoResponse(clientes);
		return response;
	}

	public void update(String publicId, @Valid ClienteParamDTO clienteDto) {
		Cliente existingCliente = repository.findByPublicId(publicId)
				.orElseThrow(() -> new RuntimeException("Cliente não encontrado com o ID: " + publicId));

		ModelMapper modelMapper = new ModelMapper();
		modelMapper.map(clienteDto, existingCliente);

		repository.save(existingCliente);
	}

	public void delete(String publicId) {
		try {
			Cliente existingCliente = repository.findByPublicId(publicId)
					.orElseThrow(() -> new RuntimeException("Cliente não encontrado com o ID: " + publicId));

			repository.delete(existingCliente);
		} catch (Exception e) {
			// verifica se o erro é por violação de chave estrangeira
			if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
				throw new ConstraintViolationException("Cliente não pode ser deletado pois está ativo");
			}
			throw new RuntimeException("Erro ao deletar cliente");
		}
	}

	public List<Cliente> findAll() {
		return repository.findAll();
	}

	public Optional<Cliente> findByCnpjOrEmail(String cnpj, String email) {
		return repository.findByCnpjOrEmail(cnpj, email);
	}

	public Optional<Cliente> findByEmail(String email) {
		return repository.findByEmail(email);
	}

	private Cliente fromParamDtoToEntity(@Valid ClienteParamDTO clienteDto) {
		return new ModelMapper().map(clienteDto, Cliente.class);
	}

	private List<ClienteDTO> createClienteDtoResponse(List<Cliente> clientes) {
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(clientes, new TypeToken<List<ClienteDTO>>() {
		}.getType());
	}

	private void validateCliente(ClienteParamDTO clienteDto) {

		Optional<Cliente> cliente = findByCnpjOrEmail(clienteDto.getCnpj(), clienteDto.getEmail());

		if (cliente.isPresent()) {
			throw new AlreadyExistsException("Já existe um cliente com este email ou cnpj");
		}
	}

	public Cliente findByPublicId(String publicId) {
		Cliente existingCliente = repository.findByPublicId(publicId)
				.orElseThrow(() -> new RuntimeException("Cliente não encontrado com o ID: " + publicId));

		return existingCliente;
	}

	public ClienteDTO getByPublicId(String publicId) {
		Cliente cliente = findByPublicId(publicId);
		return new ModelMapper().map(cliente, ClienteDTO.class);
	}

	public void save(Cliente cliente) {
		repository.save(cliente);
	}

	public Optional<Cliente> findByTokenRecuperacaoSenha(String token) {
		return repository.findByTokenRecuperacaoSenha(token);
	}

	public List<String> findAllEmails() {
		return repository.findAllEmails();
	}

}
