package com.br.lubvel.services;

import com.br.lubvel.dto.EquipamentoParamDTO;
import com.br.lubvel.dto.EquipamentoResponseDTO;
import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;
import com.br.lubvel.exception.AcessFailledException;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.exception.NotFoundException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Equipamento;
import com.br.lubvel.models.Setor;
import com.br.lubvel.repository.EquipamentoRepository;
import com.br.lubvel.utils.Utils;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EquipamentoService {

    private final EquipamentoRepository equipamentoRepository;

    private AccessService accessService;

    private SetorService setorService;
    
    @Autowired
    private MarcosService marcosService;

    public EquipamentoService(EquipamentoRepository equipamentoRepository, AccessService accessService,
            SetorService setorService) {
        this.equipamentoRepository = equipamentoRepository;
        this.accessService = accessService;
        this.setorService = setorService;
    }

    public List<EquipamentoResponseDTO> getAllEquipamentos(HttpHeaders headers) {
        try {
            Cliente cliente = accessService.getClienteLogado(headers);
            List<Equipamento> equipamentos = equipamentoRepository.findByCliente(cliente);
            return equipamentos.stream()
                    .map(this::mapToResponseDTO)
                    .collect(Collectors.toList());
        } catch (AcessFailledException e) {
            throw e;
        }catch (Exception e) {
            throw new RuntimeException("Erro ao buscar equipamentos");
        }

    }

    public Equipamento findEquipamentoByPublicId(String publicId) {
        return equipamentoRepository.findByPublicId(publicId)
                .orElseThrow(() -> new NotFoundException("Equipamento " + publicId + " não encontrado"));
    }

    public EquipamentoResponseDTO getEquipamentoById(String publicId, HttpHeaders headers) {
        try {
            Cliente cliente = accessService.getClienteLogado(headers);

            Equipamento equipamento = equipamentoRepository.findByPublicId(publicId).orElseThrow(
                    () -> new NotFoundException("Equipamento " + publicId + " não encontrado"));

            if (!equipamento.getCliente().getId().equals(cliente.getId())) {
                throw new AcessFailledException("Equipamento " + publicId + " não encontrado");
            }

            return mapToResponseDTO(equipamento);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar equipamento");
        }

    }

    public EquipamentoResponseDTO createEquipamento(EquipamentoParamDTO equipamentoParamDTO, HttpHeaders headers) {
        try {
            Cliente cliente = accessService.getClienteLogado(headers);
            List<Setor> setores = setorService.findByCliente(cliente);

            Setor setor = setores.stream()
                    .filter(s -> s.getPublicId().equals(equipamentoParamDTO.getIdSetor()))
                    .findFirst()
                    .orElseThrow(() -> new NotFoundException("Setor " + equipamentoParamDTO.getIdSetor() + " não encontrado"));
            Equipamento equipamento = mapToModel(equipamentoParamDTO, setor);
            equipamento = equipamentoRepository.save(equipamento);
            
            // Create equipment creation marco
            criarMarcoEquipamento(equipamento, headers, MarcoEnum.CRIACAO, "Equipamento criado com sucesso");
            
            return mapToResponseDTO(equipamento);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao criar equipamento");
        }
    }

    public EquipamentoResponseDTO updateEquipamento(String publicId, EquipamentoParamDTO equipamentoParamDTO,
            HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);        
        List<Equipamento> equipamentos = equipamentoRepository.findByCliente(cliente);
        Optional<Equipamento> optionalEquipamento = equipamentos.stream()
                .filter(e -> e.getPublicId().equals(publicId))
                .findFirst();
        if (optionalEquipamento.isPresent()) {
            try {
                Equipamento equipamento = optionalEquipamento.get();
                equipamento.setDescricao(equipamentoParamDTO.getDescricao());
                equipamento.setTag(equipamentoParamDTO.getTag());
                equipamento = equipamentoRepository.save(equipamento);
                
                // Create equipment update marco
                criarMarcoEquipamento(equipamento, headers, MarcoEnum.ALTERACAO, "Equipamento alterado com sucesso");
                
                return mapToResponseDTO(equipamento);
            } catch (Exception e) {
                throw new RuntimeException("Erro ao atualizar equipamento");
            }
        } else {
            throw new NotFoundException("Equipamento " + publicId + " não encontrado");
        }
    }

    public void deleteEquipamento(String publicId, HttpHeaders headers) {
        try {
            Cliente cliente = accessService.getClienteLogado(headers);
            List<Equipamento> equipamentos = equipamentoRepository.findByCliente(cliente);
            Equipamento equipamento = equipamentos.stream()
                    .filter(e -> e.getPublicId().equals(publicId))
                    .findFirst()
                    .orElseThrow(() -> new NotFoundException("Equipamento " + publicId + " não encontrado"));

            // Create equipment deletion marco before actually deleting the equipment
            criarMarcoEquipamento(equipamento, headers, MarcoEnum.EXCLUSAO, "Equipamento excluído com sucesso");
            
            equipamentoRepository.delete(equipamento);
        } catch (Exception e) {
            // verifica se o erro é por violação de chave estrangeira
            if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
                throw new ConstraintViolationException("Equipamento não pode ser deletado pois está associado a um ponto de lubrificação");
            }
            throw new RuntimeException("Erro ao deletar equipamento");
        }
    }
    
    /**
     * Creates a marco for equipment actions
     * 
     * @param equipamento The equipment entity
     * @param headers HTTP headers for user identification
     * @param tipoMarco Type of marco (CRIACAO, ALTERACAO, EXCLUSAO)
     * @param observacao Observation text for the marco
     */
    private void criarMarcoEquipamento(Equipamento equipamento, HttpHeaders headers, MarcoEnum tipoMarco, String observacao) {
        String nomeOperador = accessService.getNomeOperador(headers);
        Cliente cliente = accessService.getClienteLogado(headers);
        
        MarcosDTO marcosDTO = new MarcosDTO(
            tipoMarco, 
            nomeOperador,
            observacao, 
            EntidadeEnum.EQUIPAMENTO, 
            equipamento.getId(), 
            cliente, 
            Boolean.FALSE
        );
        
        marcosService.criarNovoMarco(marcosDTO);
    }

    private EquipamentoResponseDTO mapToResponseDTO(Equipamento equipamento) {
        ModelMapper mapper = new ModelMapper();
        EquipamentoResponseDTO dto = mapper.map(equipamento, EquipamentoResponseDTO.class);
        dto.setSetor(equipamento.getSetor().getNome());
        dto.setSetorPublicId(equipamento.getSetor().getPublicId());
        return dto;
    }

    private Equipamento mapToModel(EquipamentoParamDTO equipamentoParamDTO, Setor setor) {
        Equipamento equipamento = new Equipamento();
        equipamento.setDescricao(equipamentoParamDTO.getDescricao());
        equipamento.setSetor(setor);
        equipamento.setCliente(setor.getCliente());
        equipamento.setTag(equipamentoParamDTO.getTag());
        equipamento.setPublicId(Utils.gerarPublicId());
        return equipamento;
    }

    public List<EquipamentoResponseDTO> getEquipamentosBySetor(String setorPublicId, HttpHeaders headers) {
        try {
            Cliente cliente = accessService.getClienteLogado(headers);
            List<Setor> setores = setorService.findByCliente(cliente);
            Setor setor = setores.stream()
                    .filter(s -> s.getPublicId().equals(setorPublicId))
                    .findFirst()
                    .orElseThrow(() -> new NotFoundException("Setor " + setorPublicId + " não encontrado"));
            List<Equipamento> equipamentos = equipamentoRepository.findBySetor(setor);
            return equipamentos.stream()
                    .map(this::mapToResponseDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar equipamentos");
        }
    }

    public List<Equipamento> findByCliente(Cliente cliente) {
        return equipamentoRepository.findByCliente(cliente);
    }
}
