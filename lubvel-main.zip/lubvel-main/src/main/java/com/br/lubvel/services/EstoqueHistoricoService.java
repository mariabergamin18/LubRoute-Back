package com.br.lubvel.services;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import com.br.lubvel.repository.EstoqueHistoricoRepository;
import com.br.lubvel.models.EstoqueHistorico;
import com.br.lubvel.models.Produto;
import com.br.lubvel.dto.EstoqueHistoricoResponseDTO;
import com.br.lubvel.dto.EstoqueParamDTO;
import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.utils.Utils;
import com.br.lubvel.exception.NotFoundException;

@Service
public class EstoqueHistoricoService {
    @Autowired
    private EstoqueHistoricoRepository estoqueHistoricoRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AccessService accessService;
    
    @Autowired
    private MarcosService marcosService;

    public List<EstoqueHistoricoResponseDTO> findByCliente(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<EstoqueHistorico> estoques = estoqueHistoricoRepository.findByCliente(cliente);
        return estoques.stream().map(this::entityToDTO).collect(Collectors.toList());
    }

    public EstoqueHistorico findByPublicId(String publicId) {
        return estoqueHistoricoRepository.findByPublicId(publicId).orElseThrow(() -> new NotFoundException("Estoque não encontrado"));
    }

    private EstoqueHistoricoResponseDTO entityToDTO(EstoqueHistorico estoque) {
        EstoqueHistoricoResponseDTO estoqueResponseDTO = new EstoqueHistoricoResponseDTO();
        estoqueResponseDTO = modelMapper.map(estoque, EstoqueHistoricoResponseDTO.class);
        estoqueResponseDTO.setProdutoNome(estoque.getProduto().getNome());
        estoqueResponseDTO.setDataInclusao(Utils.dateToString(estoque.getDataInclusao()));
        estoqueResponseDTO.setQtd(estoque.getQuantidade());
        return estoqueResponseDTO;
    }

    private EstoqueHistorico dtoToEntity(EstoqueParamDTO estoqueParamDTO, Cliente cliente, Produto produto) {
        EstoqueHistorico estoque = new EstoqueHistorico();
        estoque = modelMapper.map(estoqueParamDTO, EstoqueHistorico.class);        
        estoque.setCliente(cliente);
        estoque.setProduto(produto);
        estoque.setQuantidade(estoqueParamDTO.getQuantidade());
        return estoque;
    }

    public void adicionarHistorico(EstoqueParamDTO estoqueParamDTO, Cliente cliente, Produto produto, HttpHeaders headers) {
        EstoqueHistorico estoque = dtoToEntity(estoqueParamDTO, cliente, produto);
        estoque.setPublicId(Utils.gerarPublicId());
        estoque.setDataInclusao(new Date());
        estoqueHistoricoRepository.save(estoque);
        
        // Create a marco for this estoque historico creation
        criarMarcoEstoqueHistoricoComHeaders(estoque, headers);
    }    
    
    /**
     * Creates a marco for estoque historico with user information from headers
     * 
     * @param estoqueHistorico The estoque historico entity
     * @param headers HTTP headers for user identification
     */
    public void criarMarcoEstoqueHistoricoComHeaders(EstoqueHistorico estoqueHistorico, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        String nomeOperador = accessService.getNomeOperador(headers);
        
        MarcosDTO marcosDTO = new MarcosDTO(
            MarcoEnum.CRIACAO,
            nomeOperador,
            "Estoque histórico criado com sucesso", 
            EntidadeEnum.ESTOQUE_HISTORICO, 
            estoqueHistorico.getId(), 
            cliente, 
            Boolean.FALSE
        );
        
        marcosService.criarNovoMarco(marcosDTO);
    }
}
