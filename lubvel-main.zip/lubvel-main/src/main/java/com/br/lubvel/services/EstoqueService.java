package com.br.lubvel.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.ConsultaEstoqueParamDTO;
import com.br.lubvel.dto.ConsultaEstoqueResponseDTO;
import com.br.lubvel.dto.EstoqueParamDTO;
import com.br.lubvel.dto.EstoqueResponseDTO;
import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.dto.ProdutoClienteBaixoEstoqueDTO;
import com.br.lubvel.dto.ProdutoEstoqueResponseDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;
import com.br.lubvel.enums.TipoLubrificanteEnum;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Estoque;
import com.br.lubvel.models.Produto;
import com.br.lubvel.repository.EstoqueRepository;
import com.br.lubvel.utils.Utils;

@Service
public class EstoqueService {
    @Autowired
    private EstoqueRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AccessService accessService;

    @Autowired
    private ProdutoService produtoService;

    @Autowired
    private EstoqueHistoricoService estoqueHistoricoService;
    
    @Autowired
    private MarcosService marcosService;

    public EstoqueResponseDTO save(EstoqueParamDTO estoqueParamDTO, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Estoque> estoque = findByCliente(cliente);
        Estoque estoqueExistente = estoque.stream()
                .filter(e -> e.getProduto().getPublicId().equals(estoqueParamDTO.getCodigo())).findFirst()
                .orElse(null);
        if (estoqueExistente != null) {

            Produto produtoEstoque = estoqueExistente.getProduto();
            TipoLubrificanteEnum tipoLubrificante = produtoEstoque.getTipoLubrificante();
            Double qtdProduto = tipoLubrificante == TipoLubrificanteEnum.LIQUIDO ? produtoEstoque.getQtMls()
                    : produtoEstoque.getQtGramas();
            Double qtdEstoqueAdicionar = (estoqueParamDTO.getQuantidade() * qtdProduto);
            estoqueExistente.setQuantidade(estoqueExistente.getQuantidade() + qtdEstoqueAdicionar);

            repository.save(estoqueExistente);
            // Inclui historico de estoque
            estoqueHistoricoService.adicionarHistorico(estoqueParamDTO, cliente, estoqueExistente.getProduto(), headers);
            
            // Criar marco para atualização de estoque existente
            criarMarcoEstoque(estoqueExistente, headers, cliente, "Estoque atualizado com sucesso", MarcoEnum.ALTERACAO);
            
            return entityToDTO(estoqueExistente);
        } else {
            Estoque estoqueEntity = dtoToEntity(estoqueParamDTO);
            Produto produto = produtoService.findByPublicId(estoqueParamDTO.getCodigo());

            TipoLubrificanteEnum tipoLubrificante = produto.getTipoLubrificante();
            Double qtdEstoque = tipoLubrificante == TipoLubrificanteEnum.LIQUIDO ? produto.getQtMls()
                    : produto.getQtGramas();
            Double qtdEstoqueAdicionar = (estoqueParamDTO.getQuantidade() * qtdEstoque);

            estoqueEntity.setQuantidade(qtdEstoqueAdicionar);
            estoqueEntity.setPublicId(Utils.gerarPublicId());
            estoqueEntity.setCliente(cliente);
            estoqueEntity.setProduto(produto);
            estoqueEntity = repository.save(estoqueEntity);

            // Inclui historico de estoque
            estoqueHistoricoService.adicionarHistorico(estoqueParamDTO, cliente, produto, headers);
            
            // Criar marco para novo estoque
            criarMarcoEstoque(estoqueEntity, headers, cliente, "Estoque criado com sucesso", MarcoEnum.CRIACAO);

            return entityToDTO(estoqueEntity);
        }
    }
    
    /**
     * Cria um marco para operações de estoque
     * 
     * @param estoque A entidade de estoque
     * @param headers Headers HTTP para identificação do usuário
     * @param cliente O cliente associado ao estoque
     * @param observacao Texto informativo sobre a operação
     */
    private void criarMarcoEstoque(Estoque estoque, HttpHeaders headers, Cliente cliente, String observacao, MarcoEnum marcoEnum) {
        String nomeOperador = accessService.getNomeOperador(headers);
        MarcosDTO marcosDTO = new MarcosDTO(
            marcoEnum,
            nomeOperador,
            observacao,
            EntidadeEnum.ESTOQUE,
            estoque.getId(),
            cliente,
            Boolean.FALSE
        );
        
        marcosService.criarNovoMarco(marcosDTO);
    }

    public List<EstoqueResponseDTO> getEstoque(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Estoque> estoque = findByCliente(cliente);
        Set<Produto> produtos = estoque.stream().map(Estoque::getProduto).collect(Collectors.toSet());
        return produtos.stream().map(produto -> {
            EstoqueResponseDTO estoqueResponseDTO = new EstoqueResponseDTO();
            estoqueResponseDTO.setProdutoNome(produto.getNome());
            estoqueResponseDTO.setPublicId(produto.getPublicId());
            estoqueResponseDTO.setTpLub(produto.getTipoLubrificante().toString());
            estoqueResponseDTO.setQtd(estoque.stream().filter(e -> e.getProduto().equals(produto))
                    .mapToDouble(Estoque::getQuantidade).sum());
            estoqueResponseDTO.setQtdPorUnidade(produto.getTipoLubrificante() == TipoLubrificanteEnum.LIQUIDO
                    ? produto.getQtMls()
                    : produto.getQtGramas());
            
            // Calcula a quantidade de unidades
            double resultadoDivisao = (double) estoqueResponseDTO.getQtd() / estoqueResponseDTO.getQtdPorUnidade();
            int unidades;                    
            
            if (resultadoDivisao % 1 == 0) {
                unidades = (int) resultadoDivisao;
            } else {
                unidades = (int) resultadoDivisao + 1;
            }                    
            estoqueResponseDTO.setUnidades(unidades);
                    

            return estoqueResponseDTO;
        }).collect(Collectors.toList());

    }

    public List<Estoque> findByCliente(Cliente cliente) {
        return repository.findByCliente(cliente);
    }

    private EstoqueResponseDTO entityToDTO(Estoque estoque) {
        return modelMapper.map(estoque, EstoqueResponseDTO.class);
    }

    private Estoque dtoToEntity(EstoqueParamDTO estoqueParamDTO) {
        Estoque response = modelMapper.map(estoqueParamDTO, Estoque.class);

        return response;
    }

    public List<Produto> getProdutosBaixoEstoque(Cliente cliente) {        
        List<Estoque> estoque = new ArrayList<>();

        //caso buscar estoque total pelo admin
        if(cliente == null) {
            estoque = repository.findAll();
        }else {
            estoque = repository.findByCliente(cliente);
        }        

        List<Produto> produtosBaixoEstoque = new ArrayList<>();

        // Verifica cada item do estoque
        if (estoque.size() > 0) {
            for (Estoque item : estoque) {
                Produto produto = item.getProduto();
                Double quantidadeEmEstoque = item.getQuantidade();

                // Verifica o tipo do produto e calcula a metade da capacidade total
                boolean baixoEstoque = false;
                if (produto.getTipoLubrificante() == TipoLubrificanteEnum.LIQUIDO) {
                    if (quantidadeEmEstoque <= produto.getQtMls() / 2) {
                        baixoEstoque = true;
                    }
                } else if (produto.getTipoLubrificante() == TipoLubrificanteEnum.GRAXA) {
                    if (quantidadeEmEstoque <= produto.getQtGramas() / 2) {
                        baixoEstoque = true;
                    }
                }

                // Adiciona o produto à lista se estiver em baixo estoque
                if (baixoEstoque) {
                    produtosBaixoEstoque.add(produto);
                }
            }
        }

        return produtosBaixoEstoque;
    }

    public List<ProdutoClienteBaixoEstoqueDTO> getProdutosBaixoEstoqueTodosClientes(HttpHeaders headers) {
        List<Cliente> clientes = accessService.getClientes();
        List<ProdutoClienteBaixoEstoqueDTO> produtosBaixoEstoque = new ArrayList<>();
        for (Cliente cliente : clientes) {
            List<Produto> produtosBaixoEstoqueCliente = getProdutosBaixoEstoque(cliente);
            ProdutoClienteBaixoEstoqueDTO produtoClienteBaixoEstoqueDTO = new ProdutoClienteBaixoEstoqueDTO();
            if(produtosBaixoEstoqueCliente.size() > 0) {
                produtoClienteBaixoEstoqueDTO.setClienteNome(cliente.getNome());
                produtoClienteBaixoEstoqueDTO.setClientePublicId(cliente.getPublicId());
                produtoClienteBaixoEstoqueDTO.setProdutosPublicId(produtosBaixoEstoqueCliente.stream().map(Produto::getPublicId).collect(Collectors.toList()));
                produtosBaixoEstoque.add(produtoClienteBaixoEstoqueDTO);
            }
        }
        return produtosBaixoEstoque;
    }

    public List<EstoqueResponseDTO> saveList(List<EstoqueParamDTO> estoqueParamDTO, HttpHeaders headers) {
        List<EstoqueResponseDTO> estoqueResponseDTO = new ArrayList<>();
        for (EstoqueParamDTO estoque : estoqueParamDTO) {
            estoqueResponseDTO.add(save(estoque, headers));
        }
        return estoqueResponseDTO;
    }

    public List<EstoqueResponseDTO> getBaixoEstoque(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Produto> produtosBaixoEstoque = getProdutosBaixoEstoque(cliente);
        return produtosBaixoEstoque.stream().map(produto -> {
            EstoqueResponseDTO estoqueResponseDTO = new EstoqueResponseDTO();
            estoqueResponseDTO.setProdutoNome(produto.getNome());
            estoqueResponseDTO.setQtd(recuperaQuantidadeEstoque(cliente, produto));
            estoqueResponseDTO.setPublicId(produto.getPublicId());
            estoqueResponseDTO.setTpLub(produto.getTipoLubrificante().toString());
            return estoqueResponseDTO;
        }).collect(Collectors.toList());
    }

    private Double recuperaQuantidadeEstoque(Cliente cliente, Produto produto) {
        List<Estoque> estoque = repository.findByCliente(cliente);
        return estoque.stream().filter(e -> e.getProduto().equals(produto)).mapToDouble(Estoque::getQuantidade).sum();
    }

    public void atualizarEstoque(Estoque estoqueProduto, Double quantidade) {
        Double qtd = estoqueProduto.getQuantidade();        

        estoqueProduto.setQuantidade(qtd - quantidade);
        repository.save(estoqueProduto);
    }

    public List<ProdutoEstoqueResponseDTO> findAllCliente(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Estoque> estoque = repository.findByCliente(cliente);
        Set<Produto> produtos = estoque.stream().map(Estoque::getProduto).collect(Collectors.toSet());
        return produtos.stream().map(produto -> {
            ProdutoEstoqueResponseDTO produtoEstoqueResponseDTO = new ProdutoEstoqueResponseDTO();
            produtoEstoqueResponseDTO.setNome(produto.getNome());
            produtoEstoqueResponseDTO.setProdutoBase(produto.getProdutoBase().toDTOBase());
            produtoEstoqueResponseDTO.setPublicId(produto.getPublicId());
            produtoEstoqueResponseDTO.setTipoLubrificante(produto.getTipoLubrificante().toString());
            produtoEstoqueResponseDTO.setQtMls(produto.getQtMls());
            produtoEstoqueResponseDTO.setQtGramas(produto.getQtGramas());
            produtoEstoqueResponseDTO.setQtEstoque(estoque.stream().filter(e -> e.getProduto().getPublicId().equals(produto.getPublicId()))
                    .mapToDouble(Estoque::getQuantidade).sum());
            return produtoEstoqueResponseDTO;
        }).collect(Collectors.toList());
    }

    public Collection<ConsultaEstoqueResponseDTO> conferirEstoque(HttpHeaders headers, List<ConsultaEstoqueParamDTO> consultaEstoqueParamDTO) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Estoque> estoque = repository.findByCliente(cliente);
    
        // Agrupar a quantidade necessária por produto base
        Map<String, Double> quantidadeNecessariaMap = consultaEstoqueParamDTO.stream()
            .collect(Collectors.groupingBy(
                ConsultaEstoqueParamDTO::getCodigo,
                Collectors.summingDouble(ConsultaEstoqueParamDTO::getQuantidade)
            ));
    
        // Agrupar a quantidade disponível no estoque por produto base
        Map<String, Double> estoqueTotalPorProdutoBase = estoque.stream()
            .collect(Collectors.groupingBy(
                e -> e.getProduto().getProdutoBase().getPublicId(),
                Collectors.summingDouble(Estoque::getQuantidade)
            ));
    
        List<ConsultaEstoqueResponseDTO> consultaEstoqueResponseDTO = new ArrayList<>();
        
        // Itera sobre cada produto base para verificar a quantidade necessária e disponível
        for (Map.Entry<String, Double> entry : quantidadeNecessariaMap.entrySet()) {
            String publicId = entry.getKey();
            Double quantidadeNecessariaTotal = entry.getValue();
            Double quantidadeDisponivelTotal = estoqueTotalPorProdutoBase.getOrDefault(publicId, 0.0);
    
            ConsultaEstoqueResponseDTO consultaEstoque = new ConsultaEstoqueResponseDTO();
            consultaEstoque.setCodigo(publicId);
    
            // Verifica se a quantidade disponível é suficiente
            if (quantidadeDisponivelTotal >= quantidadeNecessariaTotal) {
                consultaEstoque.setQtdSuficiente(true);
            } else {
                consultaEstoque.setQtdSuficiente(false);
                consultaEstoque.setQtdNecessaria(quantidadeNecessariaTotal);
                consultaEstoque.setQtdDisponivel(quantidadeDisponivelTotal);                
            }
    
            consultaEstoqueResponseDTO.add(consultaEstoque);
        }
    
        return consultaEstoqueResponseDTO;
    }
    
    
    
    
    

}
