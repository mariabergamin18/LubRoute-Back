package com.br.lubvel.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.dto.MarcosResponseDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Marco;
import com.br.lubvel.repository.MarcosRepository;

@Service
public class MarcosService {

   @Autowired
   private MarcosRepository repository;

   public void criarNovoMarco(MarcosDTO dto) {
      // Validação básica do DTO (exemplo)
      if (dto == null || dto.getMarco() == null || dto.getEntidade() == null || dto.getIdReferencia() == null) {
         throw new IllegalArgumentException("Dados inválidos para criação de um novo marco.");
      }

      // Construindo o objeto da entidade Marcos a partir do DTO
      Marco novoMarco = new Marco(dto);      

      // Salvando o registro no banco de dados
      repository.save(novoMarco);
   }

   public List<Marco> findByEntidadeAndIdReferenciaIn(EntidadeEnum operacaoExecutada, List<Long> idsOperacaoExecutada) {
      return repository.findByEntidadeAndIdReferenciaIn(operacaoExecutada, idsOperacaoExecutada);
   }
   
   public List<MarcosResponseDTO> getAllMarcos(Cliente cliente, LocalDate dataInicio, LocalDate dataFim) {
      List<Marco> marcos;
      
      if (dataInicio != null && dataFim != null) {
         // Converter LocalDate para LocalDateTime usando o início e fim do dia
         LocalDateTime dataInicioDateTime = dataInicio.atStartOfDay();
         LocalDateTime dataFimDateTime = dataFim.atTime(LocalTime.MAX);
         
         marcos = repository.findByClienteAndDataHoraBetween(cliente, dataInicioDateTime, dataFimDateTime);
      } else {
         // Se as datas não forem fornecidas, throw uma exceção
         throw new IllegalArgumentException("As datas de início e fim devem ser fornecidas.");
      }
      
      return marcos.stream()
            .map(marco -> new MarcosResponseDTO(
                  marco.getMarco().getDescricao(),
                  marco.getEntidade().getDescricao(),
                  marco.getDataHora(),
                  marco.getUsuario(),
                  marco.getObservacao()))
            .toList();
   }
}
