package com.br.lubvel.services;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.MetricasResponseDTO;
import com.br.lubvel.enums.AtividadeEnum;
import com.br.lubvel.enums.DescricaoMetricaEnum;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.repository.MetricasRepository;

@Service
public class MetricasService {
        
    private MetricasRepository metricasRepository;
    private AccessService accessService;
    
    public MetricasService(MetricasRepository metricasRepository, AccessService accessService) {
        this.metricasRepository = metricasRepository;
        this.accessService = accessService;
    }

    public List<MetricasResponseDTO> getMetricas(HttpHeaders headers, LocalDate dataInicio, LocalDate dataFim) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<MetricasResponseDTO> metricas = new ArrayList<>();
        metricas.add(metricasRepository.getQuantidadeEquipamentos(cliente));
        metricas.add(metricasRepository.getQuantidadePontosLubrificacao(cliente));
        metricas.add(metricasRepository.getQuantidadeOperacoes(cliente));
        metricas.add(metricasRepository.getQuantidadeAtividadesExecutadasPorTipo(dataInicio, dataFim, cliente, AtividadeEnum.MANUTENCAO));
        metricas.add(metricasRepository.getQuantidadeAtividadesExecutadasPorTipo(dataInicio, dataFim, cliente, AtividadeEnum.LUBRIFICACAO));
        metricas.add(metricasRepository.getQuantidadeAtividadesExecutadasPorTipo(dataInicio, dataFim, cliente, AtividadeEnum.LIMPEZA));
        metricas.add(metricasRepository.getValorGastoLubrificacao(dataInicio, dataFim, cliente));

        // Metrica de valor médio de lubrificação
        // recupera a metrica de valor total de lubrificação 'Gasto com lubrificação' e divide pela quantidade de atividades de lubrificação 'LUBRIFICACAO executadas'

        MetricasResponseDTO valorGastoLubrificacao = metricas.stream()
                .filter(m -> m.getDescricao().equals("Gasto lubrificante"))
                .findFirst()
                .orElse(new MetricasResponseDTO("Gasto lubrificante", "0", DescricaoMetricaEnum.VALOR_MEDIO_LUBRIFICACAO.getDescricao()));
        
        MetricasResponseDTO quantidadeAtividadesLubrificacao = metricas.stream()
                .filter(m -> m.getDescricao().equals("LUBRIFICACAO executadas"))
                .findFirst()
                .orElse(new MetricasResponseDTO("Quantidade de atividades de lubrificação", "0" , DescricaoMetricaEnum.VALOR_MEDIO_LUBRIFICACAO.getDescricao()));

        try {
            String valorGasto = valorGastoLubrificacao.getQuantidade().replace("R$", "").trim();
            double valorMedioLubrificacao = Double.parseDouble(valorGasto) / Double.parseDouble(quantidadeAtividadesLubrificacao.getQuantidade());
            String valorMedioLubrificacaoString = String.format("%.2f", valorMedioLubrificacao);
            valorMedioLubrificacaoString = "R$ " + valorMedioLubrificacaoString;
            metricas.add(new MetricasResponseDTO("Valor médio de lubrificação", valorMedioLubrificacaoString , DescricaoMetricaEnum.VALOR_MEDIO_LUBRIFICACAO.getDescricao()));
        } catch (Exception e) {
            metricas.add(new MetricasResponseDTO("Valor médio de lubrificação", "0", DescricaoMetricaEnum.VALOR_MEDIO_LUBRIFICACAO.getDescricao()));
        }
        
        return metricas;
    }
    
}
