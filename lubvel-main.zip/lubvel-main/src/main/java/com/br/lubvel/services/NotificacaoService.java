package com.br.lubvel.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.NotificacaoDTO;
import com.br.lubvel.enums.TituloEnum;
import com.br.lubvel.exception.NotificacaoException;
import com.br.lubvel.models.AtividadePendente;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Notificacao;
import com.br.lubvel.repository.NotificacaoRepository;
import com.br.lubvel.utils.Utils;

@Service
public class NotificacaoService {

    @Autowired
    private NotificacaoRepository repository;

    public List<NotificacaoDTO> listarNotificacoesCliente(Cliente cliente) {
        List<Notificacao> notificacoes = repository.buscarNotificacoesPorCliente(cliente);
        List<NotificacaoDTO> notificacoesDTO = new ArrayList<>();
        for (Notificacao notificacao : notificacoes) {
            notificacoesDTO.add(entityToDTO(notificacao));
        }
        return notificacoesDTO;
    }

    public void desativaNotificacaoAtividade(AtividadePendente atividadePendente) {
        Notificacao notificacao = recuperaNotificacaoAtividade(atividadePendente.getId());
        notificacao.setLida(true);
        repository.save(notificacao);
    }

    public void addNotificacaoAtividade(AtividadePendente atividadePendente) {
        Notificacao notificacao = atividadeToNotificacao(atividadePendente);
        repository.save(notificacao);
    }

    public void reativaNotificacao(Notificacao notificacao) {
        notificacao.setLida(false);
        repository.save(notificacao);
    }

    public NotificacaoDTO marcarNotificacaoComoLida(Cliente cliente, String publicId) {
        Notificacao notificacao = repository.findByClienteAndPublicId(cliente, publicId)
                .orElseThrow(() -> new NotificacaoException("Notificação não encontrada"));

        // verifica se a notificao tem relação com atividade pendente, se tiver, não
        // permite marcar como lida
        if (notificacao.getAtividadePendenteId() != null) {
            throw new NotificacaoException(
                    "Notificação não pode ser marcada como lida até que a atividade pendente seja concluída");
        }
        // verifica se a notificacao ja foi marcada como lida
        if (notificacao.isLida()) {
            throw new NotificacaoException("Notificação já marcada como lida");
        }
        // marca a notificacao como lida
        notificacao.setLida(true);
        notificacao.setDataHoraLeitura(Utils.getDataHoraAtual());
        repository.save(notificacao);
        return entityToDTO(notificacao);
    }

    public void adicionarNotificacao(NotificacaoDTO notificacaoDTO, Cliente cliente) {
        Notificacao notificacao = new Notificacao();
        notificacao.setPublicId(Utils.gerarPublicId());
        notificacao.setMensagem(notificacaoDTO.getMensagem());
        notificacao.setTitulo(notificacaoDTO.getTitulo());
        notificacao.setDataHoraNotificacao(new Date());
        notificacao.setLida(false);
        notificacao.setDataHoraLeitura(null);
        notificacao.setCliente(cliente);
        repository.save(notificacao);
    }

    private Notificacao recuperaNotificacaoAtividade(Long id) {
        return repository.findByAtividadePendenteId(id);
    }

    private Notificacao atividadeToNotificacao(AtividadePendente atividadePendente) {
        Notificacao notificacao = new Notificacao();
        notificacao.setAtividadePendenteId(atividadePendente.getId());
        notificacao.setCliente(atividadePendente.getCliente());
        notificacao.setDataHoraNotificacao(Utils.getDataHoraAtual());
        notificacao.setLida(Boolean.FALSE);
        notificacao.setMensagem(montarMensagem(atividadePendente.getData()));
        notificacao.setPublicId(Utils.gerarPublicId());
        notificacao.setTitulo(TituloEnum.ATIVIDADE_PENDENTE.getDescricao());

        return notificacao;
    }

    private NotificacaoDTO entityToDTO(Notificacao notificacao) {
        NotificacaoDTO notificacaoDTO = new NotificacaoDTO();
        notificacaoDTO.setDataHoraLeitura(Utils.dateToStringDdMmYyyy(notificacao.getDataHoraLeitura()));
        notificacaoDTO.setDataHoraNotificacao(Utils.dateToStringDdMmYyyy(notificacao.getDataHoraNotificacao()));
        notificacaoDTO.setLida(notificacao.isLida());
        notificacaoDTO.setMensagem(notificacao.getMensagem());
        notificacaoDTO.setPublicId(notificacao.getPublicId());
        notificacaoDTO.setTitulo(notificacao.getTitulo());
        // se nao tiver relacao com atividade pendente, permite marcar como lida
        notificacaoDTO.setAllowMarkAsRead(notificacao.getAtividadePendenteId() == null);

        return notificacaoDTO;
    }

    private String montarMensagem(Date data) {
        String dataDDMMYYY = Utils.dateToStringDdMmYyyy(data);
        StringBuilder mensagem = new StringBuilder();

        // formata a data para dd/MM/yyyy
        dataDDMMYYY = dataDDMMYYY.substring(0, 10);
        dataDDMMYYY = dataDDMMYYY.replace("-", "/");
        
        mensagem.append("Você possui atividades pendentes para o dia ")
                .append(dataDDMMYYY);
        return mensagem.toString();
    }

    // Serviço para admin criar notificação
    public NotificacaoDTO criarNotificacao(Cliente cliente, String clientePublicId, NotificacaoDTO notificacaoDTO) {
        Notificacao notificacao = new Notificacao();
        notificacao.setPublicId(Utils.gerarPublicId());
        notificacao.setMensagem(notificacaoDTO.getMensagem());
        notificacao.setTitulo(notificacaoDTO.getTitulo());
        notificacao.setDataHoraNotificacao(new Date());
        notificacao.setLida(false);
        notificacao.setDataHoraLeitura(null);
        notificacao.setCliente(cliente);
        repository.save(notificacao);
        return entityToDTO(notificacao);
    }

}
