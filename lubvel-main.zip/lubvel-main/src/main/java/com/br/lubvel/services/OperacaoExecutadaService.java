package com.br.lubvel.services;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.dto.OperacaoExecutadaParamDTO;
import com.br.lubvel.dto.OperacaoExecutadaRelatorioResponseDTO;
import com.br.lubvel.dto.OperacaoExecutadaResponseDTO;
import com.br.lubvel.dto.RelatorioOperacoesDTO;
import com.br.lubvel.enums.AtividadeEnum;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;
import com.br.lubvel.models.AtividadePendente;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Estoque;
import com.br.lubvel.models.Marco;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.Produto;
import com.br.lubvel.models.ProdutoBase;
import com.br.lubvel.repository.OperacaoExecutadaRepository;
import com.br.lubvel.utils.Utils;

@Service
public class OperacaoExecutadaService {

    private static final Logger logger = LoggerFactory.getLogger(OperacaoExecutadaService.class);

    @Autowired
    private OperacaoExecutadaRepository repository;

    @Autowired
    private AccessService accessService;

    @Autowired
    private EstoqueService estoqueService;

    @Autowired
    private ProdutoService produtoService;

    @Autowired
    private AtividadePendenteService atividadePendenteService;

    @Autowired
    private MarcosService marcosService;

    public OperacaoExecutadaResponseDTO save(OperacaoExecutadaParamDTO operacaoExecutadaParamDTO, HttpHeaders headers,
            Operacao operacao) {
        logger.info("Iniciando execução da operação: {}", operacao.getPublicId());
        try {
            
            // TODO - VERIFICAR SE OPERAÇÃO PARA A DATA DE EXECUÇÃO NÃO ESTÁ PAUSADA 
            // NO FRONT DESABILITA O BOTÃO SE ESTIVER PAUSADA, MAS NO BACKEND TAMBÉM TEM QUE VERIFICAR POR SEGURANÇA

            if (operacao.getAtividade().equals(AtividadeEnum.LUBRIFICACAO)) {
                if(operacaoExecutadaParamDTO.getQuantidadeLubrificante() == null) {
                    logger.warn("Quantidade de lubrificante não informada para operação de lubrificação. Operação: {}", operacao.getPublicId());
                    OperacaoExecutadaResponseDTO operacaoExecutadaResponseDTO = new OperacaoExecutadaResponseDTO();
                    operacaoExecutadaResponseDTO.setOperacaoPublicId(operacao.getPublicId());
                    operacaoExecutadaResponseDTO.setSuccess(false);
                    operacaoExecutadaResponseDTO.setMessage("Quantidade de lubrificante é obrigatória para a operação de lubrificação");
                    return operacaoExecutadaResponseDTO;
                }
                if (operacaoExecutadaParamDTO.getQuantidadeLubrificante() < 0) {
                    logger.warn("Quantidade de lubrificante negativa informada. Operação: {}", operacao.getPublicId());
                    OperacaoExecutadaResponseDTO operacaoExecutadaResponseDTO = new OperacaoExecutadaResponseDTO();
                    operacaoExecutadaResponseDTO.setOperacaoPublicId(operacao.getPublicId());
                    operacaoExecutadaResponseDTO.setSuccess(false);
                    operacaoExecutadaResponseDTO.setMessage("Quantidade de lubrificante deve ser um valor positivo");
                    return operacaoExecutadaResponseDTO;
                }

                // se a quantidade de lubrificante for 0, não precisa verificar o estoque
                if(operacaoExecutadaParamDTO.getQuantidadeLubrificante() == 0){
                    logger.info("Lubrificante não utilizado na operação: {}", operacao.getPublicId());
                    String currentObservacao = operacaoExecutadaParamDTO.getObservacao();
                    String newObservacao = currentObservacao != null ? currentObservacao + " - Lubrificante não utilizado" : "Lubrificante não utilizado";
                    operacaoExecutadaParamDTO.setObservacao(newObservacao);
                }else{
                    
                    // verificar se o cliente tem estoque do produto se quantidade for maior que 0
                    List<Estoque> estoqueProduto = verificarEstoque(operacao, headers, operacaoExecutadaParamDTO);
                    // verificar qual produto tem quantidade suficiente para a operação
                    estoqueProduto = estoqueProduto.stream().filter(e -> e.getQuantidade() >= operacaoExecutadaParamDTO.getQuantidadeLubrificante())
                            .collect(Collectors.toList());
                    if (estoqueProduto.isEmpty()) {
                        logger.warn("Estoque insuficiente para operação: {}", operacao.getPublicId());
                        OperacaoExecutadaResponseDTO operacaoExecutadaResponseDTO = new OperacaoExecutadaResponseDTO();
                        operacaoExecutadaResponseDTO.setOperacaoPublicId(operacao.getPublicId());
                        operacaoExecutadaResponseDTO.setSuccess(false);
                        operacaoExecutadaResponseDTO.setMessage("Não há quantidade do produto suficiente para a operação");
                        return operacaoExecutadaResponseDTO;
                    }
                    // ordenar a lista pelos que tem menor quantidade
                    estoqueProduto.sort((e1, e2) -> e1.getQuantidade().compareTo(e2.getQuantidade()));
                    // atualizar o estoque do produto
                    estoqueService.atualizarEstoque(estoqueProduto.get(0), operacaoExecutadaParamDTO.getQuantidadeLubrificante());
                    logger.info("Estoque atualizado para operação: {}", operacao.getPublicId());
                }
            }

            OperacaoExecutada operacaoExecutada = dtoToEntity(operacaoExecutadaParamDTO);
            operacaoExecutada.setOperacao(operacao);
            operacaoExecutada.setPublicId(Utils.gerarPublicId());
            operacaoExecutada.setDataHoraExecucaoReal(Utils.getDataHoraAtual());
            repository.save(operacaoExecutada);

            logger.info("Operação executada salva com sucesso. OperacaoExecutadaId: {}", operacaoExecutada.getId());

            OperacaoExecutadaResponseDTO operacaoExecutadaResponseDTO = new OperacaoExecutadaResponseDTO();
            operacaoExecutadaResponseDTO.setOperacaoPublicId(operacao.getPublicId());
            operacaoExecutadaResponseDTO.setSuccess(true);
            
            verificarSeUltimaAtividade(operacaoExecutada, headers);
            criarMarcoOperacaoExecutadaDTO(operacaoExecutada, headers, operacao.getPontoDeLubrificacao().getEquipamento().getCliente());
            logger.info("Finalizada execução da operação: {}", operacao.getPublicId());
            return operacaoExecutadaResponseDTO;
        } catch (Exception e) {
            logger.error("Erro ao executar operação {}: {}", operacao.getPublicId(), e.getMessage(), e);
            OperacaoExecutadaResponseDTO operacaoExecutadaResponseDTO = new OperacaoExecutadaResponseDTO();
            operacaoExecutadaResponseDTO.setOperacaoPublicId(operacao.getPublicId());
            operacaoExecutadaResponseDTO.setSuccess(false);
            operacaoExecutadaResponseDTO.setMessage("Erro ao executar operação: ");
            return operacaoExecutadaResponseDTO;
        }
    }

    private void criarMarcoOperacaoExecutadaDTO(OperacaoExecutada operacaoExecutada, HttpHeaders headers, Cliente cliente) {                
        String nomeOperador = accessService.getNomeOperador(headers);
        MarcosDTO marcosDTO = new MarcosDTO(MarcoEnum.EXECUCAO, nomeOperador,
                "Operação executada com sucesso", EntidadeEnum.OPERACAO_EXECUTADA, operacaoExecutada.getId(), cliente, Boolean.FALSE);
        logger.info("Criando marco para operação executada. OperacaoExecutadaId: {}", operacaoExecutada.getId());
        criarMarco(marcosDTO);
    }

    private void criarMarco(MarcosDTO marcosDTO) {
        logger.info("Persistindo novo marco para entidade: {} idReferencia: {}", marcosDTO.getEntidade(), marcosDTO.getIdReferencia());
        marcosService.criarNovoMarco(marcosDTO);
    }

    // verifica se é ultima atividade pendente do dia para remover a notificação
    private void verificarSeUltimaAtividade(OperacaoExecutada operacaoExecutada, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        Date dataConsulta = operacaoExecutada.getDataHoraExecucao();
        // transforma a data em LocalDate para considerar apenas o dia sem a hora
        LocalDate localDate = dataConsulta.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        AtividadePendente atividadePendente = atividadePendenteService.findByClienteAndData(cliente, localDate);
        if (atividadePendente != null) {
            logger.info("Executando última atividade pendente do dia para cliente: {}", cliente.getNome());
            atividadePendenteService.executaAtividade(atividadePendente);
        } else {
            logger.info("Nenhuma atividade pendente encontrada para cliente: {} na data: {}", cliente.getNome(), localDate);
        }   
    }

    private List<Estoque> verificarEstoque(Operacao operacao, HttpHeaders headers,
            OperacaoExecutadaParamDTO operacaoExecutadaParamDTO) {

        Cliente cliente = accessService.getClienteLogado(headers);

        ProdutoBase produtoBase = operacao.getPontoDeLubrificacao().getProduto();

        List<Produto> produtos = produtoService.findByProdutoBase(produtoBase);

        List<Estoque> estoqueCliente = estoqueService.findByCliente(cliente);

        // filtrar os estoque para que o produto seja algum dos produtos do ponto de
        // lubrificação
        estoqueCliente = estoqueCliente.stream()
                .filter(e -> produtos.contains(e.getProduto())).collect(Collectors.toList());

        // se a lista estiver vazia, não temos produtos em estoque
        if (estoqueCliente.isEmpty()) {
            logger.warn("Não há produtos em estoque para a operação: {}", operacao.getPublicId());
            throw new IllegalArgumentException("Não há produtos em estoque para a operação");
        }

        return estoqueCliente;
    }

    public List<OperacaoExecutada> findAllCliente(Cliente cliente) {
        logger.info("Buscando todas as operações executadas para cliente: {}", cliente.getNome());
        return repository.findByOperacaoPontoDeLubrificacaoEquipamentoCliente(cliente);
    }

    public List<RelatorioOperacoesDTO> getRelatorio(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        logger.info("Gerando relatório de operações para cliente: {}", cliente.getNome());
        List<OperacaoExecutada> operacoes = repository.findByOperacaoPontoDeLubrificacaoEquipamentoCliente(cliente);
        operacoes.sort((o1, o2) -> o1.getDataHoraExecucao().compareTo(o2.getDataHoraExecucao()));
        return operacoes.stream().map(this::entityToReportDTO).collect(Collectors.toList());
    }

    private RelatorioOperacoesDTO entityToReportDTO(OperacaoExecutada operacaoExecutada) {
        RelatorioOperacoesDTO relatorioOperacoesDTO = new RelatorioOperacoesDTO();
        AtividadeEnum atividade = operacaoExecutada.getOperacao().getAtividade();
        String quantidade = "";
        String tpLub = "";
        String produto = "Não utilizado na operação " + formatarOperacao(atividade.toString());
        if (atividade.equals(AtividadeEnum.LUBRIFICACAO)) {
            quantidade = formatarQuantidade(operacaoExecutada.getOperacao().getQuantidade());
            tpLub = operacaoExecutada.getOperacao().getPontoDeLubrificacao().getProduto().getTipoLubrificante()
                    .toString();
            produto = operacaoExecutada.getOperacao().getPontoDeLubrificacao().getProduto().getNome();
        }
        relatorioOperacoesDTO.setTpLub(tpLub);
        relatorioOperacoesDTO.setQuantidade(quantidade);
        relatorioOperacoesDTO.setProduto(produto);
        relatorioOperacoesDTO.setData(Utils.dateToStringDdMmYyyy(operacaoExecutada.getDataHoraExecucao()));
        relatorioOperacoesDTO
                .setDataHoraExecucao(Utils.dateToStringDdMmYyyy(operacaoExecutada.getDataHoraExecucaoReal()));
        relatorioOperacoesDTO.setObservacao(operacaoExecutada.getObservacao());
        relatorioOperacoesDTO.setAtividade(formatarOperacao(atividade.toString()));
        return relatorioOperacoesDTO;
    }

    private String formatarOperacao(String string) {
        return string.substring(0, 1).toUpperCase() + string.substring(1).toLowerCase();
    }

    private String formatarQuantidade(Double quantidade) {
        if (quantidade == null) {
            return "";
        } else {
            return quantidade.toString();
        }
    }

    private OperacaoExecutada dtoToEntity(OperacaoExecutadaParamDTO operacaoExecutadaParamDTO) {
        OperacaoExecutada operacaoExecutada = new OperacaoExecutada();
        operacaoExecutada
                .setDataHoraExecucao(Utils.stringToDateDdMmYyyy(operacaoExecutadaParamDTO.getDataHoraExecucao()));
        operacaoExecutada.setObservacao(operacaoExecutadaParamDTO.getObservacao());
        return operacaoExecutada;
    }

    public List<OperacaoExecutadaRelatorioResponseDTO> getRelatosTecnicos(HttpHeaders headers, String dataInicio,
         String dataFim) {
        Cliente cliente = accessService.getClienteLogado(headers);
        logger.info("Gerando relatório técnico para cliente: {} entre {} e {}", cliente.getNome(), dataInicio, dataFim);
        
        // Converter strings para Date, mantendo apenas a data (sem a hora)
        Date dataInicioDate = Utils.stringToDateWithoutTime(dataInicio);
        Date dataFimDate = Utils.stringToDateWithoutTime(dataFim);
        
        // Usar o novo método do repositório
        List<OperacaoExecutada> operacoes = repository.findByClienteAndDataBetweenWithObservacao(
                cliente, dataInicioDate, dataFimDate);

        Map<Long, String> operadoresNome = new HashMap<>();

        List<Long> idsOperacaoExecutada = operacoes.stream()
                .map(OperacaoExecutada::getId)
                .collect(Collectors.toList());
        
                //findByEntidadeAndIdReferenciaIn        
        List<Marco> marcos = marcosService.findByEntidadeAndIdReferenciaIn(EntidadeEnum.OPERACAO_EXECUTADA, idsOperacaoExecutada);
        for (Marco marco : marcos) {
            operadoresNome.put(marco.getIdReferencia(), marco.getUsuario());
        }
        
        List<OperacaoExecutadaRelatorioResponseDTO> operacoesRelatorio = operacoes.stream()
                .map(op -> entityToRelatorioDTO(op, operadoresNome)).collect(Collectors.toList());
        logger.info("Relatório técnico gerado com {} registros para cliente: {}", operacoesRelatorio.size(), cliente.getNome());
        return operacoesRelatorio;
        
    }

    private OperacaoExecutadaRelatorioResponseDTO entityToRelatorioDTO(OperacaoExecutada operacaoExecutada,
        Map<Long, String> operadoresNome) {
        OperacaoExecutadaRelatorioResponseDTO relatorioOperacoesDTO = new OperacaoExecutadaRelatorioResponseDTO();
        relatorioOperacoesDTO.setDataHoraExecucao(Utils.dateToStringDdMmYyyy(operacaoExecutada.getDataHoraExecucao()));
        relatorioOperacoesDTO.setDataHoraExecucaoReal(Utils.dateToStringDdMmYyyy(operacaoExecutada.getDataHoraExecucaoReal()));
        relatorioOperacoesDTO.setObservacao(operacaoExecutada.getObservacao());
        relatorioOperacoesDTO.setOperador(recuperarNomeOperador(operacaoExecutada, operadoresNome));
        relatorioOperacoesDTO.setSetor(operacaoExecutada.getOperacao().getPontoDeLubrificacao().getEquipamento().getSetor().getNome());
        relatorioOperacoesDTO.setEquipamento(operacaoExecutada.getOperacao().getPontoDeLubrificacao()
                .getEquipamento().getDescricao());
        relatorioOperacoesDTO.setPontoDeLubrificacaoTag(operacaoExecutada.getOperacao().getPontoDeLubrificacao()
                .getTag());
        return relatorioOperacoesDTO;
    }

    private String recuperarNomeOperador(OperacaoExecutada operacaoExecutada, Map<Long, String> operadoresNome) {
        String nomeOperadorDoLog = operadoresNome.get(operacaoExecutada.getId());
        if (nomeOperadorDoLog != null && !nomeOperadorDoLog.isEmpty()) {
            return nomeOperadorDoLog;
        }
        return operacaoExecutada.getOperacao().getPontoDeLubrificacao().getEquipamento().getCliente().getNome();
    }

    public List<OperacaoExecutada> findByOperacao(Operacao operacao) {
        logger.info("Buscando operações executadas para operação: {}", operacao.getPublicId());
        return repository.findByOperacao(operacao);
        
    }

}
