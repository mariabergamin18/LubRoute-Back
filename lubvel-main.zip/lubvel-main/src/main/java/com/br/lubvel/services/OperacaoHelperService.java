package com.br.lubvel.services;

import com.br.lubvel.models.Operacao;

/**
 * Interface that provides a limited set of Operacao-related functionality
 * needed by other services to break circular dependencies.
 */
public interface OperacaoHelperService {
    
    /**
     * Find an Operacao by its publicId
     * 
     * @param publicId The publicId of the operation to find
     * @return The operation if found
     * @throws com.br.lubvel.exception.NotFoundException if the operation is not found
     */
    Operacao findOperacaoByPublicId(String publicId);
}
