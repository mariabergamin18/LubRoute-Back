package com.br.lubvel.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.br.lubvel.exception.NotFoundException;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.repository.OperacaoRepository;

@Service
@Primary
public class OperacaoHelperServiceImpl implements OperacaoHelperService {
    
    private final OperacaoRepository operacaoRepository;
    
    @Autowired
    public OperacaoHelperServiceImpl(OperacaoRepository operacaoRepository) {
        this.operacaoRepository = operacaoRepository;
    }
    
    @Override
    public Operacao findOperacaoByPublicId(String publicId) {
        return operacaoRepository.findByPublicId(publicId)
                .orElseThrow(() -> new NotFoundException("Elemento " + publicId + " não encontrado"));
    }
}
