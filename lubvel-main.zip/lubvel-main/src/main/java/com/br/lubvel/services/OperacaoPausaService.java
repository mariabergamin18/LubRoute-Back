package com.br.lubvel.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.OperacaoPausaParamDTO;
import com.br.lubvel.exception.OperacaoPausaException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.models.OperacaoPausa;
import com.br.lubvel.repository.OperacaoPausaRepository;

@Service
public class OperacaoPausaService {

   private final OperacaoPausaRepository operacaoPausaRepository;
   private final OperacaoHelperService operacaoHelperService;

   @Autowired
   public OperacaoPausaService(
         OperacaoPausaRepository operacaoPausaRepository,
         OperacaoHelperService operacaoHelperService) {
      this.operacaoPausaRepository = operacaoPausaRepository;
      this.operacaoHelperService = operacaoHelperService;
   }

   public Boolean isPaused(String operacaoPublicId, String data) {
      Operacao operacao = operacaoHelperService.findOperacaoByPublicId(operacaoPublicId);
      List<OperacaoPausa> operacaoPausa = operacaoPausaRepository.findByOperacao(operacao);

      Date hoje = getDateWithZeroTime(new Date(System.currentTimeMillis()));

      return operacaoPausa.stream()
            .anyMatch(pausa -> pausa.getDataFim() == null || !pausa.getDataFim().before(hoje));
   }

   public void save(OperacaoPausaParamDTO operacaoPausaRequest) {

      verificaSeOperacaoEstaPausada(operacaoPausaRequest);

      verificaSeJaExistePausaParaPeriodo(operacaoPausaRequest);

      Operacao operacao = operacaoHelperService.findOperacaoByPublicId(operacaoPausaRequest.getOperacaoPublicId());
      OperacaoPausa operacaoPausa = new OperacaoPausa();
      operacaoPausa.setOperacao(operacao);

      operacaoPausa.setDataInicio(getDateWithZeroTime(parseDate(operacaoPausaRequest.getDataInicio())));
      operacaoPausa.setDataFim(getDateWithZeroTime(parseDate(operacaoPausaRequest.getDataFim())));

      operacaoPausaRepository.save(operacaoPausa);
   }

   private void verificaSeJaExistePausaParaPeriodo(OperacaoPausaParamDTO operacaoPausaRequest) {
      Operacao operacao = operacaoHelperService.findOperacaoByPublicId(operacaoPausaRequest.getOperacaoPublicId());
      List<OperacaoPausa> operacaoPausa = operacaoPausaRepository.findByOperacao(operacao);

      Date dataInicioNova = getDateWithZeroTime(parseDate(operacaoPausaRequest.getDataInicio()));
      Date dataFimNova = getDateWithZeroTime(parseDate(operacaoPausaRequest.getDataFim()));

      boolean existeConflito = operacaoPausa.stream()
            .anyMatch(pausa -> (pausa.getDataFim() == null || !pausa.getDataFim().before(dataInicioNova)) && 
                  !pausa.getDataInicio().after(dataFimNova) 
            );

      if (existeConflito) {
         throw new OperacaoPausaException("Já existe uma pausa cadastrada para esse período.");
      }
   }

   private void verificaSeOperacaoEstaPausada(OperacaoPausaParamDTO operacaoPausaRequest) {
      if (isPaused(operacaoPausaRequest.getOperacaoPublicId(), new Date(System.currentTimeMillis()).toString())) {
         throw new RuntimeException("Operação já está pausada");
      }
   }

   private Date parseDate(String dateString) {
      try {
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
         return sdf.parse(dateString);
      } catch (ParseException e) {
         throw new RuntimeException("Formato de data inválido: " + dateString);
      }
   }

   public void removePausa(String operacaoPublicId) {
      Operacao operacao = operacaoHelperService.findOperacaoByPublicId(operacaoPublicId);
      List<OperacaoPausa> operacaoPausa = operacaoPausaRepository.findByOperacao(operacao);

      Date ontem = getDateWithZeroTime(
            Date.from(LocalDate.now().minusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant()));

      operacaoPausa.stream()
            .filter(pausa -> pausa.getDataFim() == null
                  || !pausa.getDataFim().before(getDateWithZeroTime(new Date(System.currentTimeMillis()))))
            .forEach(pausa -> pausa.setDataFim(ontem));

      operacaoPausaRepository.saveAll(operacaoPausa);
   }

   public Date getDateWithZeroTime(Date date) {
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      calendar.set(Calendar.HOUR_OF_DAY, 0);
      calendar.set(Calendar.MINUTE, 0);
      calendar.set(Calendar.SECOND, 0);
      calendar.set(Calendar.MILLISECOND, 0);
      return calendar.getTime();
   }

   public List<OperacaoPausa> getOperacoesPausadas(Cliente cliente) {
      return operacaoPausaRepository.findByOperacaoPontoDeLubrificacaoEquipamentoCliente(cliente);
   }
}
