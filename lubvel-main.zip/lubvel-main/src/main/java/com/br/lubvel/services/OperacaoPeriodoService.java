package com.br.lubvel.services;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.OperacaoPausa;

public interface OperacaoPeriodoService {
    
    /**
     * Retorna as atividades do período informado para o cliente
     */
    List<OperacaoPeriodoDTO> getAtividadesPeriodoInformado(Cliente cliente, LocalDate dataInicio,
            LocalDate dataFim, List<OperacaoExecutada> operacaoExecutadas, List<OperacaoPausa> operacoesPausadas);

    /**
     * Retorna as atividades do período (DIARIA ou SEMANAL) para o cliente
     */
    List<OperacaoPeriodoDTO> getAtividadesPeriodoCliente(Cliente cliente, String periodoString,
            List<OperacaoExecutada> operacoesExecutadas, List<OperacaoPausa> operacoesPausadas);
    
    /**
     * Retorna as atividades da semana para o cliente
     */
    List<OperacaoPeriodoDTO> getAtividadesSemanaCliente(Cliente cliente);
    
    /**
     * Retorna as atividades do dia para o cliente
     */
    List<OperacaoPeriodoDTO> getAtividadesPeriodoCliente(Cliente cliente, Date day);
    
    /**
     * Avalia quais operações já foram executadas
     */
    void avaliarOperacoesExecutadas(List<OperacaoPeriodoDTO> operacoesDoDia,
            List<OperacaoExecutada> operacaoExecutadas);
    
    /**
     * Avalia quais operações estão pausadas
     */
    void avaliarOperacoesPausadas(List<OperacaoPeriodoDTO> operacoesPeriodo, 
            List<OperacaoPausa> operacoesPausadas);
    
    /**
     * Avalia quais operações são futuras
     */
    void avaliarOperacoesFuturas(List<OperacaoPeriodoDTO> operacoesPeriodo);
}
