package com.br.lubvel.services;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.OperacaoResponseDTO;
import com.br.lubvel.enums.FrequenciaEnum;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.OperacaoPausa;
import com.br.lubvel.repository.OperacaoRepository;
import com.br.lubvel.utils.Utils;

@Service
public class OperacaoPeriodoServiceImpl implements OperacaoPeriodoService {

    private final OperacaoRepository operacaoRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public OperacaoPeriodoServiceImpl(
            OperacaoRepository operacaoRepository,
            ModelMapper modelMapper) {
        this.operacaoRepository = operacaoRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<OperacaoPeriodoDTO> getAtividadesPeriodoInformado(Cliente cliente, LocalDate dataInicio,
            LocalDate dataFim, List<OperacaoExecutada> operacaoExecutadas, List<OperacaoPausa> operacoesPausadas) {

        List<OperacaoPeriodoDTO> operacoesPeriodo = new ArrayList<>();

        // Criar uma lista de datas entre dataInicio e dataFim
        List<LocalDate> datasPeriodo = dataInicio.datesUntil(dataFim.plusDays(1)).collect(Collectors.toList());

        // Para cada data no intervalo, chama o método getAtividadesPeriodoCliente
        for (LocalDate data : datasPeriodo) {
            Date day = Utils.localDateToDate(data); // Converter LocalDate para Date
            List<OperacaoPeriodoDTO> operacoesDoDia = getAtividadesPeriodoCliente(cliente, day);

            // Avaliar operações executadas
            avaliarOperacoesExecutadas(operacoesDoDia, operacaoExecutadas);
            avaliarOperacoesFuturas(operacoesDoDia);
            avaliarOperacoesPausadas(operacoesDoDia, operacoesPausadas);

            // Adiciona as operações do dia ao período
            operacoesPeriodo.addAll(operacoesDoDia);
        }

        // Ordenar por data
        operacoesPeriodo.sort((o1, o2) -> Utils.stringToDateDdMmYyyy(o1.getDataHoraParaExecucao())
                .compareTo(Utils.stringToDateDdMmYyyy(o2.getDataHoraParaExecucao())));

        return operacoesPeriodo;
    }

    @Override
    public List<OperacaoPeriodoDTO> getAtividadesPeriodoCliente(Cliente cliente, String periodoString,
            List<OperacaoExecutada> operacoesExecutadas, List<OperacaoPausa> operacoesPausadas) {
        FrequenciaEnum periodo = FrequenciaEnum.valueOf(periodoString);
        List<OperacaoPeriodoDTO> operacoesPeriodo = new ArrayList<>();

        if (periodo == FrequenciaEnum.DIARIA) {
            operacoesPeriodo.addAll(getAtividadesPeriodoCliente(cliente, Utils.getStartOfDay(new Date())));
        } else if (periodo == FrequenciaEnum.SEMANAL) {
            operacoesPeriodo.addAll(getAtividadesSemanaCliente(cliente));
        }

        avaliarOperacoesExecutadas(operacoesPeriodo, operacoesExecutadas);
        avaliarOperacoesFuturas(operacoesPeriodo);
        avaliarOperacoesPausadas(operacoesPeriodo, operacoesPausadas);
        // Ordenar por data
        operacoesPeriodo.sort((o1, o2) -> Utils.stringToDateDdMmYyyy(o1.getDataHoraParaExecucao())
                .compareTo(Utils.stringToDateDdMmYyyy(o2.getDataHoraParaExecucao())));
        return operacoesPeriodo;
    }

    @Override
    public List<OperacaoPeriodoDTO> getAtividadesSemanaCliente(Cliente cliente) {
        List<OperacaoPeriodoDTO> operacoesSemana = new ArrayList<>();
        List<Date> diasSemana = Utils.getDatesOfWeekAfterDate(new Date());
        diasSemana.forEach(day -> operacoesSemana.addAll(getAtividadesPeriodoCliente(cliente, day)));
        return operacoesSemana;
    }

    @Override
    public List<OperacaoPeriodoDTO> getAtividadesPeriodoCliente(Cliente cliente, Date day) {
        List<Operacao> operacoes = operacaoRepository.findByPontoDeLubrificacaoEquipamentoCliente(cliente);

        List<Operacao> operacoesHoraria = new ArrayList<>();
        List<Operacao> operacoesDiaria = new ArrayList<>();
        List<Operacao> operacoesSemanal = new ArrayList<>();
        List<Operacao> operacoesMensal = new ArrayList<>();
        List<Operacao> operacoesAnual = new ArrayList<>();
        List<Operacao> operacoesUnica = new ArrayList<>();

        // Classificar operações por frequência
        for (Operacao operacao : operacoes) {
            switch (operacao.getFrequencia()) {
                case HORARIA:
                    operacoesHoraria.add(operacao);
                    break;
                case DIARIA:
                    operacoesDiaria.add(operacao);
                    break;
                case MENSAL:
                    operacoesMensal.add(operacao);
                    break;
                case ANUAL:
                    operacoesAnual.add(operacao);
                    break;
                case SEMANAL:
                    operacoesSemanal.add(operacao);
                    break;
                case UNICA:
                    operacoesUnica.add(operacao);
                    break;
                default:
                    throw new IllegalArgumentException("Frequência não suportada: " + operacao.getFrequencia());
            }
        }

        List<OperacaoPeriodoDTO> operacoesPeriodo = new ArrayList<>();

        // Verificar operações horárias
        for (Operacao operacao : operacoesHoraria) {
            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(operacao.getDataHoraInicio());

            Calendar calData = Calendar.getInstance();
            calData.setTime(day);
            calData.set(Calendar.HOUR_OF_DAY, 0);
            calData.set(Calendar.MINUTE, 0);
            calData.set(Calendar.SECOND, 0);
            calData.set(Calendar.MILLISECOND, 0);

            Calendar calExecucao = (Calendar) calInicio.clone();
            while (calExecucao.getTime().before(calData.getTime())) {
                calExecucao.add(Calendar.HOUR_OF_DAY, Math.toIntExact(operacao.getQtdHoras()));
            }

            while (calExecucao.get(Calendar.DAY_OF_YEAR) == calData.get(Calendar.DAY_OF_YEAR)) {
                adicionarOperacaoSeValida(operacoesPeriodo, operacao, calExecucao.getTime());
                calExecucao.add(Calendar.HOUR_OF_DAY, Math.toIntExact(operacao.getQtdHoras()));
            }
        }

        // Verificar operações diárias
        for (Operacao operacao : operacoesDiaria) {
            Calendar calData = Calendar.getInstance();
            calData.setTime(day);
            calData.set(Calendar.HOUR_OF_DAY, 0);
            calData.set(Calendar.MINUTE, 0);
            calData.set(Calendar.SECOND, 0);
            calData.set(Calendar.MILLISECOND, 0);

            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(operacao.getDataHoraInicio());
            calInicio.set(Calendar.HOUR_OF_DAY, 0);
            calInicio.set(Calendar.MINUTE, 0);
            calInicio.set(Calendar.SECOND, 0);
            calInicio.set(Calendar.MILLISECOND, 0);

            // adicionar operação se calData for depois ou igual a calInicio
            if (calData.compareTo(calInicio) >= 0) {
                adicionarOperacaoSeValidaComHoraBase(operacoesPeriodo, operacao, day);
            }
        }

        // Verificar operações semanais
        for (Operacao operacao : operacoesSemanal) {
            if (Utils.isSameDayOfWeek(operacao.getDataHoraInicio(), day)) {
                adicionarOperacaoSeValidaComHoraBase(operacoesPeriodo, operacao, day);
            }
        }

        // Verificar operações mensais
        for (Operacao operacao : operacoesMensal) {
            if (Utils.isSameDayOfMonth(operacao.getDataHoraInicio(), day)) {
                adicionarOperacaoSeValidaComHoraBase(operacoesPeriodo, operacao, day);
            }
        }

        // Verificar operações anuais
        for (Operacao operacao : operacoesAnual) {
            if (Utils.isSameDayOfYear(operacao.getDataHoraInicio(), day)) {
                adicionarOperacaoSeValidaComHoraBase(operacoesPeriodo, operacao, day);
            }
        }

        // Verificar operações únicas
        for (Operacao operacao : operacoesUnica) {
            Calendar calData = Calendar.getInstance();
            calData.setTime(day);
            calData.set(Calendar.HOUR_OF_DAY, 0);
            calData.set(Calendar.MINUTE, 0);
            calData.set(Calendar.SECOND, 0);
            calData.set(Calendar.MILLISECOND, 0);

            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(operacao.getDataHoraInicio());
            calInicio.set(Calendar.HOUR_OF_DAY, 0);
            calInicio.set(Calendar.MINUTE, 0);
            calInicio.set(Calendar.SECOND, 0);
            calInicio.set(Calendar.MILLISECOND, 0);

            // adicionar operação se calData for exatamente igual a calInicio (mesmo dia)
            if (calData.compareTo(calInicio) == 0) {
                adicionarOperacaoSeValidaComHoraBase(operacoesPeriodo, operacao, day);
            }
        }

        return operacoesPeriodo;
    }

    @Override
    public void avaliarOperacoesExecutadas(List<OperacaoPeriodoDTO> operacoesDoDia,
            List<OperacaoExecutada> operacaoExecutadas) {
        for (OperacaoPeriodoDTO operacaoPeriodoDTO : operacoesDoDia) {

            OperacaoExecutada operacaoExecutada = operacaoExecutadas.stream()
                    .filter(oe -> oe.getOperacao().getPublicId()
                            .equals(operacaoPeriodoDTO.getOperacao().getPublicId())
                            && FrequenciaEnum.valueOf(operacaoPeriodoDTO.getOperacao().getFrequencia())
                                    .equals(oe.getOperacao().getFrequencia())
                            && Utils.isSameDate(oe.getDataHoraExecucao(),
                                    Utils.stringToDateDdMmYyyy(operacaoPeriodoDTO.getDataHoraParaExecucao()))
                            && Utils.isSameTime(oe.getDataHoraExecucao(),
                                    Utils.stringToHour(operacaoPeriodoDTO.getDataHoraParaExecucao())))
                    .findFirst()
                    .orElse(null);

            boolean exec = operacaoExecutada != null;
            operacaoPeriodoDTO.setExecutado(exec);
            operacaoPeriodoDTO.setTempoParaExecutar(exec ? "Operação executada"
                    : Utils.getTempoParaExecutar(operacaoPeriodoDTO.getDataHoraParaExecucao()));
        }
    }

    @Override
    public void avaliarOperacoesPausadas(List<OperacaoPeriodoDTO> operacoesPeriodo,
            List<OperacaoPausa> operacoesPausadas) {
        // Verificar se a data operacoesPeriodo.dataHoraParaExecucao está entre a data de início e fim da pausa
        for (OperacaoPeriodoDTO operacaoPeriodoDTO : operacoesPeriodo) {            
            Date dataHoraParaExecucao = Utils.getStartOfDay(Utils.stringToDateDdMmYyyy(operacaoPeriodoDTO.getDataHoraParaExecucao()));            

            boolean pausado = operacoesPausadas.stream()
                    .anyMatch(pausa -> !dataHoraParaExecucao.before(pausa.getDataInicio())
                            && !dataHoraParaExecucao.after(pausa.getDataFim()));            
            operacaoPeriodoDTO.setPaused(pausado);
        }
    }

    @Override
    public void avaliarOperacoesFuturas(List<OperacaoPeriodoDTO> operacoesPeriodo) {
        for (OperacaoPeriodoDTO operacaoPeriodoDTO : operacoesPeriodo) {
            operacaoPeriodoDTO.setFuture(Utils.isFuture(operacaoPeriodoDTO.getDataHoraParaExecucao()));
        }
    }

    // Método utilitário para adicionar operação válida à lista de OperacaoPeriodo com a hora da base
    private void adicionarOperacaoSeValidaComHoraBase(List<OperacaoPeriodoDTO> operacoesPeriodo, Operacao operacao,
            Date day) {
        Calendar calDataHoraBase = Calendar.getInstance();
        calDataHoraBase.setTime(operacao.getDataHoraInicio());

        Calendar calDataExecucao = Calendar.getInstance();
        calDataExecucao.setTime(day);
        calDataExecucao.set(Calendar.HOUR_OF_DAY, calDataHoraBase.get(Calendar.HOUR_OF_DAY));
        calDataExecucao.set(Calendar.MINUTE, calDataHoraBase.get(Calendar.MINUTE));

        adicionarOperacaoSeValida(operacoesPeriodo, operacao, calDataExecucao.getTime());
    }

    // Método utilitário para adicionar operação válida à lista de OperacaoPeriodo
    private void adicionarOperacaoSeValida(List<OperacaoPeriodoDTO> operacoesPeriodo, Operacao operacao,
            Date dataHoraExecucao) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        OperacaoPeriodoDTO operacaoPeriodo = new OperacaoPeriodoDTO();
        operacaoPeriodo.setOperacao(entityToDTO(operacao));
        operacaoPeriodo.setEquipamento(operacao.getPontoDeLubrificacao().getEquipamento().toDTO());
        operacaoPeriodo.setDataHoraParaExecucao(sdf.format(dataHoraExecucao));
        operacoesPeriodo.add(operacaoPeriodo);
    }

    // Método para converter entidade para DTO
    private OperacaoResponseDTO entityToDTO(Operacao operacao) {
        OperacaoResponseDTO operacaoResponseDTO = modelMapper.map(operacao, OperacaoResponseDTO.class);
        operacaoResponseDTO.setPontoDeLubrificacaoId(operacao.getPontoDeLubrificacao().getPublicId());
        operacaoResponseDTO.setEquipamentoId(operacao.getPontoDeLubrificacao().getEquipamento().getPublicId());
        operacaoResponseDTO.setEquipamentoNome(operacao.getPontoDeLubrificacao().getEquipamento().getDescricao());
        operacaoResponseDTO.setPontoDeLubrificacaoTag(operacao.getPontoDeLubrificacao().getTag());
        operacaoResponseDTO.setPontoDeLubrificacaoDescricaoComponente(operacao.getPontoDeLubrificacao().getDescricaoComponente());
        operacaoResponseDTO.setQtdHoras(operacao.getQtdHoras());
        operacaoResponseDTO.setProduto(operacao.getPontoDeLubrificacao().getProduto().toDTO());
        operacaoResponseDTO
                .setSetorPublicId(operacao.getPontoDeLubrificacao().getEquipamento().getSetor().getPublicId());
        operacaoResponseDTO.setUnidadeMedida(operacao.getUnidadeMedida());
        return operacaoResponseDTO;
    }
}
