package com.br.lubvel.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.ClienteDTO;
import com.br.lubvel.dto.JwtResponseDTO;
import com.br.lubvel.dto.OperacaoDashBoardAdminDTO;
import com.br.lubvel.dto.OperacaoDashBoardDTO;
import com.br.lubvel.dto.OperacaoParamDTO;
import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.OperacaoResponseDTO;
import com.br.lubvel.dto.ProdutoClienteBaixoEstoqueDTO;
import com.br.lubvel.enums.AtividadeEnum;
import com.br.lubvel.enums.FrequenciaEnum;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.exception.NotFoundException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Operacao;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.OperacaoPausa;
import com.br.lubvel.models.PontoDeLubrificacao;
import com.br.lubvel.models.Produto;
import com.br.lubvel.repository.OperacaoRepository;
import com.br.lubvel.utils.Utils;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OperacaoService {

    private final OperacaoRepository repository;
    private final ModelMapper modelMapper;
    private final PontoDeLubrificacaoService pontoDeLubrificacaoService;
    private final EstoqueService estoqueService;
    private final AccessService accessService;
    private final ClienteService clienteService;
    private final SincronizadorAtividadePendente sincronizadorAtividadePendente;
    private final OperacaoPeriodoService operacaoPeriodoService;
    private final OperacaoExecutadaService operacaoExecutadaService;

    @Autowired
    public OperacaoService(
            OperacaoRepository repository,
            ModelMapper modelMapper,
            PontoDeLubrificacaoService pontoDeLubrificacaoService,
            EstoqueService estoqueService,
            AccessService accessService,
            ClienteService clienteService,
            SincronizadorAtividadePendente sincronizadorAtividadePendente,
            OperacaoPeriodoService operacaoPeriodoService,
            OperacaoExecutadaService operacaoExecutadaService) {
        this.repository = repository;
        this.modelMapper = modelMapper;
        this.pontoDeLubrificacaoService = pontoDeLubrificacaoService;
        this.estoqueService = estoqueService;
        this.accessService = accessService;
        this.clienteService = clienteService;
        this.sincronizadorAtividadePendente = sincronizadorAtividadePendente;
        this.operacaoPeriodoService = operacaoPeriodoService;
        this.operacaoExecutadaService = operacaoExecutadaService;
    }

    public OperacaoResponseDTO save(OperacaoParamDTO operacaoParamDTO) {
        validarDataCriacao(operacaoParamDTO.getDataHoraInicio());
        PontoDeLubrificacao pontoDeLubrificacao = pontoDeLubrificacaoService
                .findByPublicId(operacaoParamDTO.getPontoDeLubrificacaoId());
        Operacao operacao = dtoToEntity(operacaoParamDTO, pontoDeLubrificacao);
        operacao.setPublicId(Utils.gerarPublicId());
        operacao = repository.save(operacao);
        
        afterOperacaoModificada(operacao, new Date());
        
        return entityToDTO(operacao);
    }

    private void validarDataCriacao(String dataHoraInicio) {
        // se for um dia anterior a hoje, lançar exceção. Não considera horário
        LocalDate dataInicio = new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate dataInicioOperacao = Utils.stringToDate(dataHoraInicio).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        if (dataInicioOperacao.isBefore(dataInicio)) {
            throw new IllegalArgumentException("Data de início da operação não pode ser anterior a hoje");
        }
    }

    public OperacaoResponseDTO update(OperacaoParamDTO operacaoParamDTO, String publicId, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Operacao> operacoes = repository.findByPontoDeLubrificacaoEquipamentoCliente(cliente);
        Operacao operacao = operacoes.stream()
                .filter(o -> o.getPublicId().equals(publicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Operação " + publicId + " não encontrada"));
        
        // Alterações não permitidas
        boolean alterouDataInicio = operacaoParamDTO.getDataHoraInicio() != null 
                && operacao.getDataHoraInicio() != null 
                && !Utils.isSameDate(operacao.getDataHoraInicio(), Utils.stringToDate(operacaoParamDTO.getDataHoraInicio()));

        boolean alterouFrequencia = operacaoParamDTO.getFrequencia() != null 
                && operacao.getFrequencia() != null 
                && !operacao.getFrequencia().toString().equals(operacaoParamDTO.getFrequencia());

        // Alterações permitidas apenas se não tiverem sido executadas atividades
               // Alterações permitidas apenas se não tiverem sido executadas atividades
               boolean alterouQtdHoras = (operacaoParamDTO.getQtdHoras() != null && operacao.getQtdHoras() == null) ||
               (operacaoParamDTO.getQtdHoras() == null && operacao.getQtdHoras() != null) ||
               (operacaoParamDTO.getQtdHoras() != null && operacao.getQtdHoras() != null 
               && !operacao.getQtdHoras().equals(operacaoParamDTO.getQtdHoras()));             

        if (alterouDataInicio || alterouFrequencia || alterouQtdHoras) {
            String camposAlterados = "";
            if (alterouDataInicio) {
                camposAlterados += "Data de início, ";
            }
            if (alterouFrequencia) {
                camposAlterados += "Frequência, ";
            }
            throw new IllegalArgumentException(
                "Não é possível alterar os campos: " + camposAlterados + "pois a operação já foi iniciada."
            );
        }

        // TODO FUTURO - Permitir alteração de frequência apenas se não houver atividades executadas
        // Tem aquele problema de query em lopp 
        /*
        if (alterouQtdHoras) {
            if (possuiAtividadesExecutadas(operacao)) {
                throw new IllegalArgumentException(
                    "Não é possível alterar a frequência para rotinas que já tiveram atividades executadas. " // TODO FUTURO - "Se necessário alterar a frequência, pause a rotina atual e crie uma nova."                    
                );
            }
        }
             */
        
        operacao = dtoToEntityUpdate(operacaoParamDTO, operacao);
        operacao = repository.save(operacao);

        // TODO - FUTURO - Passar como null para revisitar todas atividades pendentes
        afterOperacaoModificada(operacao, new Date());

        return entityToDTO(operacao);
    }

    public void delete(String publicId, HttpHeaders headers) {
        try {
            List<Operacao> operacoes = repository
                    .findByPontoDeLubrificacaoEquipamentoCliente(accessService.getClienteLogado(headers));
            Operacao operacao = operacoes.stream()
                    .filter(o -> o.getPublicId().equals(publicId))
                    .findFirst()
                    .orElseThrow(() -> new NotFoundException("Operação " + publicId + " não encontrada"));
            repository.delete(operacao);
        } catch (Exception e) {
            if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
                throw new ConstraintViolationException("Operação não pode ser deletada pois está em uso");
            }
            throw new RuntimeException("Erro ao deletar operação");
        }
    }

    public List<OperacaoResponseDTO> findAll(HttpHeaders header) {
        Cliente cliente = accessService.getClienteLogado(header);
        List<Operacao> operacaos = repository.findByPontoDeLubrificacaoEquipamentoCliente(cliente);
        operacaos.sort((o1, o2) -> o1.getDataHoraInicio().compareTo(o2.getDataHoraInicio()));

        return operacaos.stream()
                .map(operacao -> entityToDTO(operacao))
                .collect(Collectors.toList());
    }

    public Operacao findByPublicId(String publicId) {
        return repository.findByPublicId(publicId)
                .orElseThrow(() -> new NotFoundException("Elemento " + publicId + " não encontrado"));
    }

    public OperacaoResponseDTO findOperacaoDTOByPublicId(String publicId, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Operacao> operacaos = repository.findByPontoDeLubrificacaoEquipamentoCliente(cliente);
        Operacao operacao = operacaos.stream()
                .filter(o -> o.getPublicId().equals(publicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Operação " + publicId + " não encontrada"));
        return entityToDTO(operacao);
    }

    public OperacaoResponseDTO entityToDTO(Operacao operacao) {
        OperacaoResponseDTO operacaoResponseDTO = modelMapper.map(operacao, OperacaoResponseDTO.class);
        operacaoResponseDTO.setPontoDeLubrificacaoId(operacao.getPontoDeLubrificacao().getPublicId());
        operacaoResponseDTO.setEquipamentoId(operacao.getPontoDeLubrificacao().getEquipamento().getPublicId());
        operacaoResponseDTO.setEquipamentoNome(operacao.getPontoDeLubrificacao().getEquipamento().getDescricao());
        operacaoResponseDTO.setPontoDeLubrificacaoTag(operacao.getPontoDeLubrificacao().getTag());
        operacaoResponseDTO.setPontoDeLubrificacaoDescricaoComponente(operacao.getPontoDeLubrificacao().getDescricaoComponente());
        operacaoResponseDTO.setQtdHoras(operacao.getQtdHoras());
        operacaoResponseDTO.setProduto(operacao.getPontoDeLubrificacao().getProduto().toDTO());
        operacaoResponseDTO
                .setSetorPublicId(operacao.getPontoDeLubrificacao().getEquipamento().getSetor().getPublicId());
        operacaoResponseDTO.setUnidadeMedida(operacao.getUnidadeMedida());
        return operacaoResponseDTO;
    }

    private boolean possuiAtividadesExecutadas(Operacao operacao) {
        // Consulta se existem registros para esta operação na tabela operacao_executada
        return !operacaoExecutadaService.findByOperacao(operacao).isEmpty();
    }
    
    private Operacao dtoToEntity(OperacaoParamDTO operacaoParamDTO, PontoDeLubrificacao pontoDeLubrificacao) {
        Operacao operacao = modelMapper.map(operacaoParamDTO, Operacao.class);
        operacao.setPontoDeLubrificacao(pontoDeLubrificacao);
        operacao.setDataHoraInicio(Utils.stringToDate(operacaoParamDTO.getDataHoraInicio()));
        operacao.setFrequencia(FrequenciaEnum.valueOf(operacaoParamDTO.getFrequencia()));
        operacao.setAtividade(AtividadeEnum.valueOf(operacaoParamDTO.getAtividade()));
        operacao.setUnidadeMedida(operacaoParamDTO.getUnidadeMedida());
        return operacao;
    }

    private Operacao dtoToEntityUpdate(OperacaoParamDTO opParamDTO, Operacao operacao) {
        operacao.setAtividade(AtividadeEnum.valueOf(opParamDTO.getAtividade()));
        operacao.setFrequencia(FrequenciaEnum.valueOf(opParamDTO.getFrequencia()));
        operacao.setDataHoraInicio(Utils.stringToDate(opParamDTO.getDataHoraInicio()));
        operacao.setModoAplicacao(opParamDTO.getModoAplicacao());
        operacao.setQuantidade(opParamDTO.getQuantidade());
        operacao.setQtdHoras(opParamDTO.getQtdHoras());
        operacao.setUnidadeMedida(opParamDTO.getUnidadeMedida());
        operacao.setAtividadeRequerMaquinaDesligada(opParamDTO.getAtividadeRequerMaquinaDesligada());
        return operacao;
    }

    public OperacaoDashBoardDTO getDashBoard(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<OperacaoPeriodoDTO> operacoesDias = operacaoPeriodoService.getAtividadesPeriodoCliente(cliente, Utils.getStartOfDay(new Date()));
        List<OperacaoPeriodoDTO> operacoesSemana = operacaoPeriodoService.getAtividadesSemanaCliente(cliente);
        List<Produto> produtosBaixoEstoque = estoqueService.getProdutosBaixoEstoque(cliente);

        OperacaoDashBoardDTO operacaoDashBoard = new OperacaoDashBoardDTO();
        operacaoDashBoard.setAtividadesDia(operacoesDias.size());
        operacaoDashBoard.setAtividadesSemana(operacoesSemana.size());
        operacaoDashBoard.setProdutosBaixoEstoque(produtosBaixoEstoque.size());
        operacaoDashBoard.setEmpresaCnpj(cliente.getCnpj());
        operacaoDashBoard.setEmpresaNome(cliente.getNome());
        return operacaoDashBoard;
    }

    public OperacaoDashBoardAdminDTO getDashBoardAdmin(HttpHeaders headers) {
        accessService.isAdmin(headers);
        JwtResponseDTO jwtResponseDTO = accessService.validateAccessAndReturnJwt(headers);

        OperacaoDashBoardAdminDTO operacaoDashBoard = new OperacaoDashBoardAdminDTO();
        List<ProdutoClienteBaixoEstoqueDTO> produtosClienteBaixoEstoqueDTO = estoqueService
                .getProdutosBaixoEstoqueTodosClientes(headers);
        List<ClienteDTO> clientes = clienteService.showAll();
        operacaoDashBoard.setProdutosBaixoEstoque(produtosClienteBaixoEstoqueDTO.size());
        operacaoDashBoard.setClientesCadastros(clientes.size());
        operacaoDashBoard.setProdutosClienteBaixoEstoque(produtosClienteBaixoEstoqueDTO);
        operacaoDashBoard.setEmpresaNome(jwtResponseDTO.getUsername());
        return operacaoDashBoard;
    }

    public Operacao findByPublicIdAuth(String operacaoPublicId, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Operacao> operacoes = repository.findByPontoDeLubrificacaoEquipamentoCliente(cliente);
        return operacoes.stream()
                .filter(o -> o.getPublicId().equals(operacaoPublicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Operação " + operacaoPublicId + " não encontrada"));
    }

    private void afterOperacaoModificada(Operacao operacao, Date dataModificacao) {
        Cliente cliente = operacao.getPontoDeLubrificacao().getEquipamento().getCliente();
        sincronizadorAtividadePendente.sincronizarAtividadesPendentesOnOperacaoChange(cliente, dataModificacao);
    }

    // Delegate methods for backward compatibility
    
    public List<OperacaoPeriodoDTO> getAtividadesPeriodoInformado(Cliente cliente, LocalDate dataInicio,
            LocalDate dataFim, List<OperacaoExecutada> operacaoExecutadas, List<OperacaoPausa> operacoesPausadas) {
        return operacaoPeriodoService.getAtividadesPeriodoInformado(cliente, dataInicio, dataFim, operacaoExecutadas, operacoesPausadas);
    }

    public List<OperacaoPeriodoDTO> getAtividadesPeriodoCliente(Cliente cliente, String periodoString,
            List<OperacaoExecutada> operacoesExecutadas, List<OperacaoPausa> operacoesPausadas) {
        return operacaoPeriodoService.getAtividadesPeriodoCliente(cliente, periodoString, operacoesExecutadas, operacoesPausadas);
    }
}
