package com.br.lubvel.services;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Equipamento;
import com.br.lubvel.models.PontoDeLubrificacao;
import com.br.lubvel.models.ProdutoBase;
import com.br.lubvel.models.Setor;
import com.br.lubvel.repository.PontoDeLubrificacaoRepository;
import com.br.lubvel.utils.Utils;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.exception.NotFoundException;
import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.dto.PontoDeLubrificacaoResponseDTO;
import com.br.lubvel.dto.PtLubParamDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;

@Service
public class PontoDeLubrificacaoService {

    @Autowired
    private PontoDeLubrificacaoRepository repository;

    @Autowired
    private EquipamentoService equipamentoService;

    @Autowired
    private ProdutoBaseService produtoBaseService;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private SetorService setorService;

    @Autowired
    private AccessService accessService;
    
    @Autowired
    private MarcosService marcosService;

    public List<PontoDeLubrificacaoResponseDTO> findAll(String setorPublicId, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Setor> setores = setorService.findByCliente(cliente);
        
        Setor setor = setores.stream()
                .filter(s -> s.getPublicId().equals(setorPublicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Setor não encontrado"));       
        List<PontoDeLubrificacao> pontosDeLubrificacao = repository.findByEquipamentoSetor(setor);
        return pontosDeLubrificacao.stream()
                .map(pontoDeLubrificacao -> entityToDto(pontoDeLubrificacao))
                .collect(Collectors.toList());
    }

    public PontoDeLubrificacao findByPublicId(String publicId) {
        return repository.findByPublicId(publicId).orElseThrow(() -> new NotFoundException("Elemento " + publicId + " não encontrado"));
    }

    public PontoDeLubrificacaoResponseDTO findByPublicIdResponseDTO(String publicId, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<PontoDeLubrificacao> pontosDeLubrificacao = repository.findByEquipamentoCliente(cliente);        
        PontoDeLubrificacao ptLub = pontosDeLubrificacao.stream()
                .filter(p -> p.getPublicId().equals(publicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Ponto de lubrificação não encontrado"));
        return entityToDto(ptLub);
    }
   
    public void delete(String publicId, HttpHeaders headers) {
        try {
            Cliente cliente = accessService.getClienteLogado(headers);
            List<PontoDeLubrificacao> pontosDeLubrificacao = repository.findByEquipamentoCliente(cliente);
            PontoDeLubrificacao ptLub = pontosDeLubrificacao.stream()
                    .filter(p -> p.getPublicId().equals(publicId))
                    .findFirst()
                    .orElseThrow(() -> new NotFoundException("Ponto de lubrificação não encontrado"));
                    
            // Create deletion marco before actually deleting
            criarMarcoPontoDeLubrificacao(ptLub, headers, MarcoEnum.EXCLUSAO, "Ponto de lubrificação excluído com sucesso");
                    
            repository.delete(ptLub);
        } catch (Exception e) {
            if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
                throw new ConstraintViolationException("Ponto de lubrificação não pode ser deletado pois está associado a uma rotina");
            }
            throw new RuntimeException("Erro ao deletar ponto de lubrificação");
        }
    }

    public PontoDeLubrificacaoResponseDTO save(PtLubParamDTO ptLubParamDTO, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);

        // Valida a tag fornecida
        validarTag(ptLubParamDTO.getTag());
        List<Equipamento> equipamentos = equipamentoService.findByCliente(cliente);
        Equipamento equipamento = equipamentos.stream()
                .filter(e -> e.getPublicId().equals(ptLubParamDTO.getEquipamentoId()))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Equipamento não encontrado"));
        ProdutoBase produto = produtoBaseService.findByPublicId(ptLubParamDTO.getProdutoId());
        PontoDeLubrificacao ptLub = dtoToEntity(ptLubParamDTO, equipamento, produto);
        ptLub.setPublicId(Utils.gerarPublicId());        
        ptLub = repository.save(ptLub);
        
        // Create creation marco after saving
        criarMarcoPontoDeLubrificacao(ptLub, headers, MarcoEnum.CRIACAO, "Ponto de lubrificação criado com sucesso");

        return entityToDto(ptLub);
    }

    public PontoDeLubrificacaoResponseDTO update(String publicId, PtLubParamDTO ptLubParamDTO, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);

        List<PontoDeLubrificacao> pontosDeLubrificacao = repository.findByEquipamentoCliente(cliente);
        PontoDeLubrificacao ptLub = pontosDeLubrificacao.stream()
                .filter(p -> p.getPublicId().equals(publicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Ponto de lubrificação não encontrado"));

        // Valida a tag apenas se foi alterada
        if (!ptLub.getTag().equals(ptLubParamDTO.getTag())) {
            validarTag(ptLubParamDTO.getTag());
        }

        ProdutoBase produto = produtoBaseService.findByPublicId(ptLubParamDTO.getProdutoId());
        List<Equipamento> equipamentos = equipamentoService.findByCliente(cliente);
        Equipamento equipamento = equipamentos.stream()
                .filter(e -> e.getPublicId().equals(ptLubParamDTO.getEquipamentoId()))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Equipamento não encontrado"));
                
        ptLub.setTag(ptLubParamDTO.getTag());
        ptLub.setEquipamento(equipamento);
        ptLub.setProduto(produto);
        ptLub.setDescricaoComponente(ptLubParamDTO.getDescricaoComponente());

        ptLub = repository.save(ptLub);
        
        // Create update marco after updating
        criarMarcoPontoDeLubrificacao(ptLub, headers, MarcoEnum.ALTERACAO, "Ponto de lubrificação alterado com sucesso");
    
        return entityToDto(ptLub);
    }

    
    private void validarTag(String tag) {
        if (tag == null || tag.isEmpty()) {
            throw new ConstraintViolationException("Tag não pode ser vazia");
        }
        if (repository.findByTag(tag).isPresent()) {
            throw new ConstraintViolationException("Tag já cadastrada, favor informar outra");
        }
    }

    private PontoDeLubrificacao dtoToEntity(PtLubParamDTO ptLubParamDTO, Equipamento equipamento, ProdutoBase produto){
        PontoDeLubrificacao pontoLubrificacao = new PontoDeLubrificacao();
        pontoLubrificacao.setEquipamento(equipamento);
        pontoLubrificacao.setProduto(produto);
        pontoLubrificacao.setTag(ptLubParamDTO.getTag());
        pontoLubrificacao.setDescricaoComponente(ptLubParamDTO.getDescricaoComponente());
        return pontoLubrificacao;
    }

    private PontoDeLubrificacaoResponseDTO entityToDto(PontoDeLubrificacao ptLub){
        PontoDeLubrificacaoResponseDTO ptLubResponseDTO = new PontoDeLubrificacaoResponseDTO();
        ptLubResponseDTO = modelMapper.map(ptLub, PontoDeLubrificacaoResponseDTO.class);
        ptLubResponseDTO.setLubrificante(ptLub.getProduto().getNome());
        ptLubResponseDTO.setTipoLubrificante(ptLub.getProduto().getTipoLubrificante().toString());
        ptLubResponseDTO.setEquipamentoPublicId(ptLub.getEquipamento().getPublicId());
        ptLubResponseDTO.setProdutoPublicId(ptLub.getProduto().getPublicId());
        ptLubResponseDTO.setEquipamento(ptLub.getEquipamento().getDescricao());
        return ptLubResponseDTO;
    }

    public List<PontoDeLubrificacaoResponseDTO> findAllByEquipamento(String equipamentoPublicId, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Equipamento> equipamentos = equipamentoService.findByCliente(cliente);
        Equipamento equipamento = equipamentos.stream()
                .filter(e -> e.getPublicId().equals(equipamentoPublicId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Equipamento não encontrado"));
        List<PontoDeLubrificacao> pontosDeLubrificacao = repository.findByEquipamento(equipamento);
        return pontosDeLubrificacao.stream()
                .map(pontoDeLubrificacao -> entityToDto(pontoDeLubrificacao))
                .collect(Collectors.toList());
    }
    
    /**
     * Creates a marco for point of lubrication actions
     * 
     * @param pontoDeLubrificacao The point of lubrication entity
     * @param headers HTTP headers for user identification
     * @param tipoMarco Type of marco (CRIACAO, ALTERACAO, EXCLUSAO)
     * @param observacao Observation text for the marco
     */
    private void criarMarcoPontoDeLubrificacao(PontoDeLubrificacao pontoDeLubrificacao, HttpHeaders headers, 
            MarcoEnum tipoMarco, String observacao) {
        String nomeOperador = accessService.getNomeOperador(headers);
        Cliente cliente = accessService.getClienteLogado(headers);
        
        MarcosDTO marcosDTO = new MarcosDTO(
            tipoMarco, 
            nomeOperador,
            observacao, 
            EntidadeEnum.PONTO_DE_LUBRIFICACAO, 
            pontoDeLubrificacao.getId(), 
            cliente, 
            Boolean.FALSE
        );
        
        marcosService.criarNovoMarco(marcosDTO);
    }
}