package com.br.lubvel.services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.ProdutoBaseDTO;
import com.br.lubvel.dto.ProdutoBaseResponseDTO;
import com.br.lubvel.enums.TipoLubrificanteEnum;
import com.br.lubvel.exception.NotFoundException;
import com.br.lubvel.models.ProdutoBase;
import com.br.lubvel.repository.ProdutoBaseRepository;
import com.br.lubvel.utils.Utils;

import java.util.stream.Collectors;

@Service
public class ProdutoBaseService {

   @Autowired
   private ProdutoBaseRepository repository;

   @Autowired
   private ModelMapper modelMapper;

   @Autowired
   private AccessService accessService;

   public ProdutoBase findByPublicId(String publicId) {
       return repository.findByPublicId(publicId)
               .orElseThrow(() -> new NotFoundException("Produto não encontrado com o ID: " + publicId));
   }

   public List<ProdutoBaseResponseDTO> findAll(HttpHeaders headers) {
         //verifica se usuario esta logado
         accessService.getClienteLogado(headers);
         return repository.findAll().stream()
                  .map(produtoBase -> modelMapper.map(produtoBase, ProdutoBaseResponseDTO.class))
                  .collect(Collectors.toList());
   }

   public ProdutoBase save(ProdutoBaseDTO produtoBaseDTO) {
      TipoLubrificanteEnum tipoLubrificante = TipoLubrificanteEnum.valueOf(produtoBaseDTO.getTipoLubrificante());
      ProdutoBase produtoBase = new ProdutoBase();
      String publicId = Utils.gerarPublicId();
      produtoBase.setPublicId(publicId);
      produtoBase.setNome(produtoBaseDTO.getNome());
      produtoBase.setTipoLubrificante(tipoLubrificante);
      return repository.save(produtoBase);
   }
   
}
