package com.br.lubvel.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.models.Produto;
import com.br.lubvel.models.ProdutoBase;
import com.br.lubvel.repository.ProdutoRepository;
import com.br.lubvel.utils.Utils;
import com.br.lubvel.dto.ProdutoBaseDTO;
import com.br.lubvel.dto.ProdutoErroResponseDTO;
import com.br.lubvel.dto.ProdutoLoteDTO;
import com.br.lubvel.dto.ProdutoParamDTO;
import com.br.lubvel.dto.ProdutoResponseDTO;
import com.br.lubvel.enums.TipoLubrificanteEnum;
import com.br.lubvel.exception.NotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AccessService accessService;

    @Autowired
    private ProdutoBaseService produtoBaseService;

    public Produto findByPublicId(String publicId) {
        Produto produto = repository.findByPublicId(publicId)
                .orElseThrow(() -> new NotFoundException("Produto não encontrado com o ID: " + publicId));

        return produto;
    }

    public List<ProdutoResponseDTO> findAll(HttpHeaders headers) {
        // verifica se usuario esta logado
        accessService.getClienteLogado(headers);
        return repository.findAll().stream()
                .map(produto -> modelMapper.map(produto, ProdutoResponseDTO.class))
                .collect(Collectors.toList());
    }

    public ProdutoResponseDTO save(ProdutoParamDTO produtoParamDTO, HttpHeaders headers) {
        // validar se é admin
        accessService.isAdmin(headers);

        validarTipoProduto(produtoParamDTO);
        Produto produto = modelMapper.map(produtoParamDTO, Produto.class);
        ProdutoBase produtoBase = produtoBaseService.findByPublicId(produtoParamDTO.getProdutoBasePublicId());
        produto.setPublicId(produtoParamDTO.getCodigo());
        produto.setProdutoBase(produtoBase);
        Produto savedProduto = repository.save(produto);
        return modelMapper.map(savedProduto, ProdutoResponseDTO.class);
    }

    private void validarTipoProduto(ProdutoParamDTO produtoParamDTO) {
        if (produtoParamDTO.getTipoLubrificante().equals("GRAXA")
                && (produtoParamDTO.getQtGramas() == null || produtoParamDTO.getQtGramas() == 0)) {
            throw new IllegalArgumentException("O campo qtGramas é obrigatório para o tipo de produto GRAXA");
        } else if (produtoParamDTO.getTipoLubrificante().equals("LIQUIDO")
                && (produtoParamDTO.getQtMls() == null || produtoParamDTO.getQtMls() == 0)) {
            throw new IllegalArgumentException("O campo qtMls é obrigatório para o tipo de produto LIQUIDO");
        } else {
            return;
        }
    }

    public void delete(String publicId, HttpHeaders headers) {
        // validar se é admin
        accessService.isAdmin(headers);
        Produto produto = repository.findByPublicId(publicId)
                .orElseThrow(() -> new NotFoundException("Produto não encontrado com o ID: " + publicId));
        repository.delete(produto);
    }

    public ProdutoResponseDTO update(String publicId, ProdutoParamDTO produtoParamDTO, HttpHeaders headers) {
        // validar se é admin
        accessService.isAdmin(headers);
        validarTipoProduto(produtoParamDTO);

        Produto produto = repository.findByPublicId(publicId)
                .orElseThrow(() -> new NotFoundException("Produto não encontrado com o ID: " + publicId));
        modelMapper.map(produtoParamDTO, produto);
        ProdutoBase produtoBase = produtoBaseService.findByPublicId(produtoParamDTO.getProdutoBasePublicId());
        produto.setProdutoBase(produtoBase);
        Produto updatedProduto = repository.save(produto);
        return modelMapper.map(updatedProduto, ProdutoResponseDTO.class);
    }

    public List<Produto> findByProdutoBase(ProdutoBase produtoBase) {
        return repository.findByProdutoBase(produtoBase);
    }

    public List<Produto> findByProdutosBase(List<String> codigos) {
        return repository.findByProdutosBase(codigos);
    }

    public List<ProdutoErroResponseDTO> saveLote(ProdutoLoteDTO produtoParamDTO, HttpHeaders headers) {
        // validar se é admin
        accessService.isAdmin(headers);

        List<ProdutoErroResponseDTO> produtosErroSalvar = new ArrayList<>();

        ProdutoBaseDTO produtoBaseDTO = new ProdutoBaseDTO(produtoParamDTO.getNome(),
                produtoParamDTO.getTipoLubrificante());
        ProdutoBase produtoBase = null;
        try {
            produtoBase = produtoBaseService.save(produtoBaseDTO);
        } catch (Exception e) {
            ProdutoErroResponseDTO produtoErro = new ProdutoErroResponseDTO();
            produtoErro.setNome(produtoBaseDTO.getNome());
            String publicId = Utils.gerarPublicId();
            // Para mensagem como publicId é muito grande, cortar
            produtoErro.setCodigo(publicId.substring(0, 8) + "...");
            // se erro for de produto base ja existente, erro sql
            produtoErro.setMotivo("Erro ao salvar ProdutoBase");
            if (e.getMessage().contains("duplicate key")) {
                produtoErro.setMotivo("ProdutoBase já existente com o código gerado" + publicId.substring(0, 8) + "... tente novamente");
            }
            if(e.getMessage().contains("violates unique constraint \"uc_nome_produto_base\"")) {
                produtoErro.setMotivo("Já existe um ProdutoBase com esse nome");
            }
            produtosErroSalvar.add(produtoErro);
        }

        ProdutoBase finalProdutoBase = produtoBase;
        if (produtosErroSalvar.size() > 0) {
            return produtosErroSalvar;
        }

        produtoParamDTO.getProdutos().forEach(produtoParam -> {
            Produto produto = new Produto();

            String publicId = produtoParam.getCodigo() == null ? Utils.gerarProdutoPublicId()
                    : produtoParam.getCodigo();

            produto.setPublicId(publicId);
            produto.setNome(produtoParam.getNome());
            produto.setTipoLubrificante(TipoLubrificanteEnum.valueOf(produtoParamDTO.getTipoLubrificante()));
            produto.setProdutoBase(finalProdutoBase);
            if (TipoLubrificanteEnum.GRAXA
                    .equals(TipoLubrificanteEnum.valueOf(produtoParamDTO.getTipoLubrificante()))) {
                produto.setQtGramas(produtoParam.getQtd());
            } else {
                produto.setQtMls(produtoParam.getQtd());
            }
            try {
                repository.save(produto);
            } catch (Exception e) {
                ProdutoErroResponseDTO produtoErro = new ProdutoErroResponseDTO();
                produtoErro.setNome(produtoParam.getNome());
                produtoErro.setCodigo(publicId);
                // se erro for de produto ja existente, erro sql
                produtoErro.setMotivo("Erro ao salvar Produto");
                if (e.getMessage().contains("duplicate key")) {
                    produtoErro.setMotivo("Produto já existente");
                }
                if(e.getMessage().contains("violates unique constraint \"uc_nome_produto\"")) {
                    produtoErro.setMotivo("Produto já existente com o nome " + produtoParam.getNome());
                }
                produtosErroSalvar.add(produtoErro);
            }
        });
        
        return produtosErroSalvar;

    }

}
