package com.br.lubvel.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.RelatorioDTO;
import com.br.lubvel.enums.TipoRelatorioEnum;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.OperacaoExecutada;
import com.br.lubvel.models.OperacaoPausa;

@Service
public class RelatorioService {

    @Autowired
    private EquipamentoService equipamentoService;

    @Autowired
    private EstoqueService estoqueService;

    @Autowired OperacaoExecutadaService operacaoExecutadaService;

    @Autowired 
    OperacaoService operacaoService;

    @Autowired
    private AccessService accessService;

    @Autowired
    private OperacaoPausaService operacaoPausaService;

public RelatorioDTO getRelatorio(String tipoRelatorio, HttpHeaders headers) {
    TipoRelatorioEnum tipo = TipoRelatorioEnum.valueOf(tipoRelatorio.toUpperCase());
    List<String> cabecalho = null;
    List<Object> dados = null;
    Cliente cliente = accessService.getClienteLogado(headers);


    if (tipo.equals(TipoRelatorioEnum.EQUIPAMENTOS)) {
        cabecalho = obterCabecalho(tipo);
        dados = new ArrayList<>(equipamentoService.getAllEquipamentos(headers)); // Retorna a lista de objetos DTO diretamente

    } else if (tipo.equals(TipoRelatorioEnum.ESTOQUE)) {
        cabecalho = obterCabecalho(tipo);
        dados = new ArrayList<>(estoqueService.getEstoque(headers)); // Retorna a lista de objetos DTO diretamente

    } else if (tipo.equals(TipoRelatorioEnum.OPERACOES)) {
        cabecalho = obterCabecalho(tipo);
        dados = new ArrayList<>(operacaoExecutadaService.getRelatorio(headers)); // Retorna a lista de objetos DTO diretamente
    } else if(tipo.equals(TipoRelatorioEnum.ATIVIDADESDIA)){
        cabecalho = obterCabecalho(tipo);
        List<OperacaoExecutada> operacaoExecutadas = operacaoExecutadaService.findAllCliente(cliente);
        List<OperacaoPausa> operacaoPausas = operacaoPausaService.getOperacoesPausadas(cliente);
        List<OperacaoPeriodoDTO> operacoesParaExecutar = operacaoService.getAtividadesPeriodoCliente(cliente, "DIARIA", operacaoExecutadas, operacaoPausas);       
        dados = new ArrayList<>(operacoesParaExecutar.stream().filter(op -> !op.isExecutado()).collect(Collectors.toList()));
    }

    RelatorioDTO relatorio = new RelatorioDTO();
    relatorio.setCabecalho(cabecalho);
    relatorio.setDados(dados);
    return relatorio;
}


    private List<String> obterCabecalho(TipoRelatorioEnum tipo) {        
        List<String> cabecalho = null;
        if(tipo.equals(TipoRelatorioEnum.EQUIPAMENTOS)) {
           cabecalho = List.of("Descricao", "Setor", "Tag");
        } else if(tipo.equals(TipoRelatorioEnum.ESTOQUE)) {
            cabecalho = List.of("Nome", "Unidades", "Qtd por unidade", "Qtd Total");
        } else if(tipo.equals(TipoRelatorioEnum.OPERACOES)) {
            cabecalho = List.of("Atividade", "Data para execução", "Data Execução", "Produto", "Quantidade", "Observacao");
        } else if(tipo.equals(TipoRelatorioEnum.ATIVIDADESDIA)){            
            cabecalho = List.of("Setor", "Equipamento", "Tag ponto", "Data e Hora", "Atividade", "Quantidade","Modo Aplicação");
        }
        return cabecalho;
    }

}
