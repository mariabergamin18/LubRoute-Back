package com.br.lubvel.services;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.MarcosDTO;
import com.br.lubvel.dto.SetorParamDTO;
import com.br.lubvel.dto.SetorResponseDTO;
import com.br.lubvel.enums.EntidadeEnum;
import com.br.lubvel.enums.MarcoEnum;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.Setor;
import com.br.lubvel.repository.SetorRepository;
import com.br.lubvel.utils.Utils;

@Service
public class SetorService {

    @Autowired
    private SetorRepository setorRepository;

    @Autowired
    private AccessService accessService;
    
    @Autowired
    private MarcosService marcosService;

    public SetorResponseDTO createSetor(SetorParamDTO setorParamDTO, HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);

        Setor setor = new Setor();
        setor.setNome(setorParamDTO.getNome());
        setor.setCliente(cliente);
        setor.setPublicId(Utils.gerarPublicId());

        setorRepository.save(setor);
        
        // Create sector creation marco
        criarMarcoSetor(setor, headers, MarcoEnum.CRIACAO, "Setor criado com sucesso");

        SetorResponseDTO setorResponseDTO = fromEntityToDto(setor);

        return setorResponseDTO;
    }

    private SetorResponseDTO fromEntityToDto(Setor setor) {
        ModelMapper mapper = new ModelMapper();
        SetorResponseDTO dto = mapper.map(setor, SetorResponseDTO.class);
        return dto;
    }

    public SetorResponseDTO updateSetor(String publicId, SetorParamDTO setorParamDTO, HttpHeaders headers) {

        Cliente cliente = accessService.getClienteLogado(headers);

        List<Setor> setores = setorRepository.findByCliente(cliente);

        Setor setor = setores.stream().filter(s -> s.getPublicId().equals(publicId))
                .findFirst().orElseThrow(() -> new RuntimeException("Setor não encontrado com o ID: " + publicId));

        setor.setNome(setorParamDTO.getNome());

        setorRepository.save(setor);
        
        // Create sector update marco
        criarMarcoSetor(setor, headers, MarcoEnum.ALTERACAO, "Setor alterado com sucesso");

        SetorResponseDTO setorResponseDTO = fromEntityToDto(setor);

        return setorResponseDTO;
    }

    public void delete(String publicId, HttpHeaders headers) {

        try {
            Cliente cliente = accessService.getClienteLogado(headers);
            List<Setor> setores = setorRepository.findByCliente(cliente);

            Setor setor = setores.stream().filter(s -> s.getPublicId().equals(publicId))
                    .findFirst().orElseThrow(() -> new RuntimeException("Setor não encontrado com o ID: " + publicId));
            
            // Create sector deletion marco before actually deleting the sector
            criarMarcoSetor(setor, headers, MarcoEnum.EXCLUSAO, "Setor excluído com sucesso");

            setorRepository.delete(setor);
        } catch (Exception e) {
            if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
                throw new ConstraintViolationException(
                        "Setor não pode ser deletado pois está associado a um equipamento");
            }
            throw new RuntimeException("Erro ao deletar setor");
        }

    }

    /**
     * Creates a marco for sector actions
     * 
     * @param setor The sector entity
     * @param headers HTTP headers for user identification
     * @param tipoMarco Type of marco (CRIACAO, ALTERACAO, EXCLUSAO)
     * @param observacao Observation text for the marco
     */
    private void criarMarcoSetor(Setor setor, HttpHeaders headers, MarcoEnum tipoMarco, String observacao) {
        String nomeOperador = accessService.getNomeOperador(headers);
        Cliente cliente = accessService.getClienteLogado(headers);
        
        MarcosDTO marcosDTO = new MarcosDTO(
            tipoMarco, 
            nomeOperador,
            observacao, 
            EntidadeEnum.SETOR, 
            setor.getId(), 
            cliente, 
            Boolean.FALSE
        );
        
        marcosService.criarNovoMarco(marcosDTO);
    }

    public List<SetorResponseDTO> findAllByClienteId(HttpHeaders headers) {
        Cliente cliente = accessService.getClienteLogado(headers);
        List<Setor> setores = setorRepository.findByCliente(cliente);

        return setores.stream()
                .map(this::fromEntityToDto)
                .collect(Collectors.toList());
    }

    public Setor findByPublicId(String publicId) {
        Setor setor = setorRepository.findByPublicId(publicId)
                .orElseThrow(() -> new RuntimeException("Setor não encontrado com o ID: " + publicId));

        return setor;
    }

    public List<Setor> findByCliente(Cliente cliente) {
        return setorRepository.findByCliente(cliente);
    }
}
