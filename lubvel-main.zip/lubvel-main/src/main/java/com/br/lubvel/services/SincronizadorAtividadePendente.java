package com.br.lubvel.services;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.br.lubvel.dto.AtividadePendenteDTO;
import com.br.lubvel.dto.OperacaoPeriodoDTO;
import com.br.lubvel.dto.OperacaoPeriodoSchedulerDTO;
import com.br.lubvel.models.AtividadePendente;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.schedulers.services.AtividadesDiaService;

// Essa classe é responsável por sincronizar as atividades pendentes e as notificações quando ocorre algum ajuste na operação do cliente.
@Service
public class SincronizadorAtividadePendente {

    private final AtividadesDiaService atividadesDiaService;
    private final AtividadePendenteService atividadePendenteService;
    private final NotificacaoService notificacaoService;

    @Autowired
    public SincronizadorAtividadePendente(
            AtividadesDiaService atividadesDiaService,
            AtividadePendenteService atividadePendenteService,
            NotificacaoService notificacaoService) {
        this.atividadesDiaService = atividadesDiaService;
        this.atividadePendenteService = atividadePendenteService;
        this.notificacaoService = notificacaoService;
    }

    @Transactional
    public void sincronizarAtividadesPendentesOnOperacaoChange(Cliente cliente, Date data) {

        /*
         * Se não passa data significa que é atualização de operação, logo todas as
         * datas de atividades pendentes devem ser atualizadas
         * 
         * Se passa data significa que é uma nova operação cadastrada, logo deve-se
         * criar uma nova atividade pendente e notificação
         */

        // Cria uma lista de datas que serão processadas e popula de acordo com a regra
        // descrita acima
        List<LocalDate> datas = new ArrayList<>();
        if (data != null) {
            datas.add(data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        } else {
            datas = atividadePendenteService.recuperarDatasAtividadesPendentes(cliente);
        }

        if (datas.isEmpty()) {
            return;
        }

        // Busca todas as atividades pendentes existentes em batch
        Map<LocalDate, AtividadePendente> atividadesPendentesMap = atividadePendenteService.findByClienteAndDatas(cliente, datas);

        for (LocalDate dataReferencia : datas) {
            // Verifica se já ha salvo atividades pendentes para o dia
            AtividadePendente atividadePendenteSalva = atividadesPendentesMap.get(dataReferencia);

            Long quantidadeAtividadesPendentes = recuperarECalcularAtividadesPendentes(cliente, dataReferencia);

            if (atividadePendenteSalva != null) {
                // Atualiza a quantidade de atividades pendentes
                atualizarAtividadePendente(atividadePendenteSalva, quantidadeAtividadesPendentes);

                // Atualiza a notificação se qtdPendente for 0
                if (quantidadeAtividadesPendentes <= 0) {
                    notificacaoService.desativaNotificacaoAtividade(atividadePendenteSalva);
                }
            } else {
                // Cria uma nova atividade pendente e notificação
                AtividadePendenteDTO atividadePendenteDTO = new AtividadePendenteDTO();
                atividadePendenteDTO.setCliente(cliente);
                atividadePendenteDTO.setQuantidade(quantidadeAtividadesPendentes);
                atividadePendenteDTO.setPendentes(quantidadeAtividadesPendentes);
                AtividadePendente atividadePendenteNew = atividadePendenteService.save(atividadePendenteDTO);
                notificacaoService.addNotificacaoAtividade(atividadePendenteNew);
            }
        }
    }

    private void atualizarAtividadePendente(AtividadePendente atividadePendenteSalva,
            Long quantidadeAtividadesPendentes) {
        atividadePendenteSalva.setQuantidade(quantidadeAtividadesPendentes);
        atividadePendenteSalva.setPendentes(quantidadeAtividadesPendentes);
        atividadePendenteService.update(atividadePendenteSalva);
    }

    public Long recuperarECalcularAtividadesPendentes(Cliente cliente, LocalDate dataReferencia) {
        List<OperacaoPeriodoSchedulerDTO> operacoes = new ArrayList<>();
        atividadesDiaService.tratarOperacoes(cliente, operacoes, dataReferencia, dataReferencia);
        Long quantidadeAtividadesPendentes = 0L;
        for (OperacaoPeriodoSchedulerDTO operacaoPeriodoSchedulerDTO : operacoes) {
            List<OperacaoPeriodoDTO> operacoesDoDia = operacaoPeriodoSchedulerDTO.getOperacoesDoDia();
            for (OperacaoPeriodoDTO operacaoPeriodoDTO : operacoesDoDia) {
                if (!operacaoPeriodoDTO.isExecutado() && !operacaoPeriodoDTO.isPaused()) {
                    quantidadeAtividadesPendentes++;
                }
            }
        }
        return quantidadeAtividadesPendentes;
    }

}
