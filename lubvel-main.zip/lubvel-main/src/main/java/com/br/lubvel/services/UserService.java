package com.br.lubvel.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.JwtResponseDTO;
import com.br.lubvel.dto.UserParamDTO;
import com.br.lubvel.exception.AlreadyExistsException;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.models.User;
import com.br.lubvel.repository.UserRepository;
import com.br.lubvel.utils.EmailManager;
import com.br.lubvel.utils.SegurancaSenha;
import com.br.lubvel.utils.Utils;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;

    public Optional<User> findByEmail(String email) {
        return repository.findByEmail(email);
    }

    public void store(UserParamDTO userParamDTO) {
        validateUser(userParamDTO);
        String password = Utils.gerarSenhaPrimaria();
        User user = fromParamDtoToEntity(userParamDTO);
        user.setPasswordHash(SegurancaSenha.gerarHashSenha(password));
        user.setPublicId(Utils.gerarPublicId());
        user.setFirstAccess(true);

        EmailManager eManager = new EmailManager();
        eManager.enviarSenha(password, user.getEmail(), user.getNome());

        repository.save(user);
    }

    private void validateUser(UserParamDTO userParamDTO) {
        List<User> users = findByEmailOrCpf(userParamDTO.getEmail(), userParamDTO.getCpf());
    
        if (!users.isEmpty()) {
            throw new AlreadyExistsException("Erro ao cadastrar usuário: Email ou CPF já cadastrado.");
        }
    }
    

    private List<User> findByEmailOrCpf(String email, String cpf) {
        return repository.findByEmailOrCpf(email, cpf);
    }

    public void save(User user) {
        repository.save(user);
    }

    public Optional<User> findByTokenRecuperacaoSenha(String token) {
        return repository.findByTokenRecuperacaoSenha(token);
    }

    private User fromParamDtoToEntity(UserParamDTO userParamDTO) {
        User user = new User();
        user.setNome(userParamDTO.getNome());
        user.setEmail(userParamDTO.getEmail());
        user.setCpf(userParamDTO.getCpf());
        user.setEndereco(userParamDTO.getEndereco());
        return user;
    }

    public List<UserParamDTO> index(JwtResponseDTO usuarioAtual) {
        List<User> users = repository.findAll();
        List<UserParamDTO> usersDTO = new ArrayList<>();
        users.forEach(user -> usersDTO.add(fromEntityToParamDto(user, usuarioAtual)));
        return usersDTO;
    }

    private UserParamDTO fromEntityToParamDto(User user, JwtResponseDTO usuarioAtual) {
        UserParamDTO userParamDTO = new ModelMapper().map(user, UserParamDTO.class);        
        if (usuarioAtual != null){
            userParamDTO.setUsuarioAtual(user.getCpf().equals(usuarioAtual.getUserId()));
        }
        return userParamDTO;
    }

    public void update(UserParamDTO userDto) {
        Optional<User> user = repository.findByPublicId(userDto.getPublicId());
        if (user.isPresent()) {
            User userEntity = user.get();
            
            // Buscar todos os usuários com o mesmo email ou CPF
            List<User> existingUsers = repository.findByEmailOrCpf(userDto.getEmail(), userDto.getCpf());
    
            // Verificar se há algum outro usuário com os mesmos dados
            boolean alreadyExists = existingUsers.stream()
                .anyMatch(existingUser -> !existingUser.getId().equals(userEntity.getId()));
    
            if (alreadyExists) {
                throw new AlreadyExistsException("Email ou CPF já cadastrado");
            }
    
            // Atualizar os dados
            userEntity.setNome(userDto.getNome());
            userEntity.setEmail(userDto.getEmail());
            userEntity.setCpf(userDto.getCpf());
            userEntity.setEndereco(userDto.getEndereco());
            
            repository.save(userEntity);
        }
    }
    

    public void delete(String  publicId, JwtResponseDTO usuarioAtual) {
        if (usuarioAtual.getUserId().equals(publicId)) {
            throw new RuntimeException("Usuário não pode ser deletado pois está ativo");
        }
        Optional<User> user = repository.findByPublicId(publicId);
        if (user.isPresent()) {
            try {
                repository.delete(user.get());
            } catch (Exception e) {
                // verifica se o erro é por violação de chave estrangeira
                if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
                    throw new ConstraintViolationException("Usuário não pode ser deletado pois está ativo");
                }
                throw new RuntimeException("Erro ao deletar usuário");
            }
        } else {
            throw new RuntimeException("Erro ao deletar usuário");
        }
    }

    public UserParamDTO show(String publicId) {
        Optional<User> user = repository.findByPublicId(publicId);
        if (user.isPresent()) {
            return fromEntityToParamDto(user.get(), null);
        }
        throw new RuntimeException("Erro ao buscar usuário");
    }

    public User findByCpf(String cpf) {
        return repository.findByCpf(cpf)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado com o CPF: " + cpf));
    }

}