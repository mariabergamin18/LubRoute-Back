package com.br.lubvel.services;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.lubvel.dto.UsuarioClienteParamDTO;
import com.br.lubvel.dto.UsuarioClienteResponseDTO;
import com.br.lubvel.exception.AlreadyExistsException;
import com.br.lubvel.exception.ConstraintViolationException;
import com.br.lubvel.exception.NotFoundException;
import com.br.lubvel.models.Cliente;
import com.br.lubvel.models.UsuarioCliente;
import com.br.lubvel.repository.UsuarioClienteRepository;
import com.br.lubvel.utils.EmailManager;
import com.br.lubvel.utils.SegurancaSenha;
import com.br.lubvel.utils.Utils;

@Service
public class UsuarioClienteService {

   // Model Mapper
   private ModelMapper modelMapper = new ModelMapper();

   @Autowired
   private UsuarioClienteRepository repository;

   public void store(UsuarioClienteParamDTO usuarioClienteDto, Cliente clienteManager, List<String> emailsRestritos) {

      validateUser(usuarioClienteDto, emailsRestritos);
      String publicId = Utils.gerarPublicId();
      String password = Utils.gerarSenhaPrimaria();

      UsuarioCliente usuarioCliente = dtoToEntity(usuarioClienteDto);
      usuarioCliente.setCliente(clienteManager);
      usuarioCliente.setPublicId(publicId);
      usuarioCliente.setPasswordHash(SegurancaSenha.gerarHashSenha(password));
      usuarioCliente.setFirstAccess(true);

      EmailManager eManager = new EmailManager();
      eManager.enviarSenha(password, usuarioCliente.getEmail(), usuarioCliente.getNome());

      repository.save(usuarioCliente);
   }

   public void update(UsuarioClienteParamDTO usuarioClienteDto, Cliente clienteManager, List<String> emailsRestritos) {

      if(emailsRestritos.contains(usuarioClienteDto.getEmail())){
         throw new AlreadyExistsException("Erro ao cadastrar usuário: Email ou CPF já cadastrado.");
      }

      Optional<UsuarioCliente> user = repository.findByPublicId(usuarioClienteDto.getPublicId());
      if (user.isPresent()) {
         UsuarioCliente userEntity = user.get();

         // Buscar todos os usuários com o mesmo email ou CPF
         List<UsuarioCliente> existingUsers = repository.findByEmailOrCpf(usuarioClienteDto.getEmail(),
               usuarioClienteDto.getCpf());

         boolean alreadyExists = existingUsers.stream()
               .anyMatch(existingUser -> !existingUser.getId().equals(userEntity.getId()));

         if (alreadyExists) {
            throw new AlreadyExistsException("Email ou CPF já cadastrado");
         }

         // Atualiza os dados
         userEntity.setNome(usuarioClienteDto.getNome());
         userEntity.setEmail(usuarioClienteDto.getEmail());
         userEntity.setCpf(usuarioClienteDto.getCpf());
         userEntity.setEndereco(usuarioClienteDto.getEndereco());

         repository.save(userEntity);

      }
   }

   public List<UsuarioClienteResponseDTO> index(Cliente clienteManager) {
      return repository.findByCliente(clienteManager).stream()
            .map(this::entityToDto)
            .toList();
   }

   public UsuarioClienteResponseDTO show(String publicId, Cliente clienteManager) {
      Optional<UsuarioCliente> user = repository.findByPublicId(publicId);
      if(!user.isPresent()){
         throw new ConstraintViolationException("Usuário não encontrado");
      }
      
      return entityToDto(user.get());
   }

   public void delete(String publicId, Cliente clienteManager) {
      Optional<UsuarioCliente> user = repository.findByPublicId(publicId);
      try {
         repository.delete(user.get());
      } catch (Exception e) {
         if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
				throw new ConstraintViolationException("Usuário não pode ser deletado pois está ativo");
			}
			throw new RuntimeException("Erro ao deletar usuario");
      }
   }

   private UsuarioCliente dtoToEntity(UsuarioClienteParamDTO usuarioClienteDto) {
      return modelMapper.map(usuarioClienteDto, UsuarioCliente.class);
   }

   private UsuarioClienteResponseDTO entityToDto(UsuarioCliente usuario) {
      return modelMapper.map(usuario, UsuarioClienteResponseDTO.class);
   }

   private void validateUser(UsuarioClienteParamDTO param, List<String> emailsRestritos) {
      List<UsuarioCliente> users = repository.findByEmailOrCpf(param.getEmail(), param.getCpf());

      if (!users.isEmpty()) {
         throw new AlreadyExistsException("Erro ao cadastrar usuário: Email ou CPF já cadastrado.");
      }

      if(emailsRestritos.contains(param.getEmail())){
         throw new AlreadyExistsException("Erro ao cadastrar usuário: Email ou CPF já cadastrado.");
      }
   }

   public Optional<UsuarioCliente> findByEmail(String clienteEmail) {
      return repository.findByEmail(clienteEmail);
   }

   public UsuarioCliente findByPublicId(String publicId) {
      return repository.findByPublicId(publicId).orElseThrow(() -> new NotFoundException("UsuarioCliente " + publicId + " não encontrado"));
   }

   public void save(UsuarioCliente cliente) {
      repository.save(cliente);
   }

   public List<String> findAllEmails() {
      return repository.findAllEmails();
   }

   public Optional<UsuarioCliente> findByTokenRecuperacaoSenha(String token) {
      return repository.findByTokenRecuperacaoSenha(token);
   }

}
