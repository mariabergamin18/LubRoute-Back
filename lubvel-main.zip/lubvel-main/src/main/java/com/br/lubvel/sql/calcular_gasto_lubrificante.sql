CREATE OR REPLACE FUNCTION public.calcular_gasto_lubrificante(data_inicio date, data_fim date, p_cliente_id integer)
 RETURNS TABLE(descricao text, valor_total text)
 LANGUAGE plpgsql
AS $function$
BEGIN
    RETURN QUERY
    WITH lubrificacoes_periodo AS (
        -- Seleciona as operações de lubrificação executadas no período
        SELECT 
            oe.operacao_id,
            o.quantidade AS quantidade_utilizada,
            pb.id AS produto_base_id
        FROM 
            operacao_executada oe
        JOIN 
            operacao o ON oe.operacao_id = o.id
        JOIN 
            ponto_de_lubrificacao pl ON o.ponto_de_lubrificacao_id = pl.id
        JOIN 
            equipamento e ON pl.equipamento_id = e.id
        JOIN 
            produto_base pb ON pl.produto_id = pb.id
        WHERE 
            oe.data_hora_execucao BETWEEN data_inicio AND data_fim
            AND e.cliente_id = p_cliente_id
            AND o.atividade = 'LUBRIFICACAO'  -- Filtro para atividades de lubrificação
    ),

    quantidade_total_lubrificante AS (
        -- Calcula a quantidade total de lubrificante utilizada no período
        SELECT 
            produto_base_id,
            SUM(quantidade_utilizada) AS quantidade_total
        FROM 
            lubrificacoes_periodo
        GROUP BY 
            produto_base_id
    ),

    custo_medio_lubrificante AS (
        -- Calcula o custo médio do lubrificante com base no histórico de compras
        SELECT 
            p.produto_base_id,
            AVG(
                eh.preco / 
                CASE 
                    WHEN p.tipo_lubrificante = 'LIQUIDO' THEN eh.quantidade * p.qt_mls
                    WHEN p.tipo_lubrificante = 'GRAXA' THEN eh.quantidade * p.qt_gramas
                    ELSE 1  -- Evita divisão por zero ou valores inválidos
                END
            ) AS custo_medio_por_unidade
        FROM 
            estoque_historico eh
        JOIN 
            produto p ON eh.produto_id = p.id
        WHERE 
            eh.cliente_id = p_cliente_id
        GROUP BY 
            p.produto_base_id
    )

    -- Calcula o custo total de lubrificação no período e formata como moeda brasileira
    SELECT 
        'Gasto lubrificante' AS descricao,
        'R$ ' || ROUND(SUM(qtl.quantidade_total * cml.custo_medio_por_unidade)::numeric, 2) AS valor_total
    FROM 
        quantidade_total_lubrificante qtl
    JOIN 
        custo_medio_lubrificante cml ON qtl.produto_base_id = cml.produto_base_id;
END;
$function$
;
