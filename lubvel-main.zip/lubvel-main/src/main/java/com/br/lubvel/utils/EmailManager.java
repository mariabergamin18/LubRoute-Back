package com.br.lubvel.utils;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailManager {

    private final String username = "lubvel.mail@gmail.com";
    private final String password = "vhho mlpx lwlg dpbb";
    private final String emailFrom = "lubvel.mail@gmail.com";

    public void enviarSenha(String senha, String emailDestinatario, String nomeCliente) {

        Properties prop = new Properties();
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");

        // Criação de uma nova sessão com autenticação
        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            // Criando uma nova mensagem de email
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(emailFrom));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailDestinatario));
            message.setSubject("Cadastro no Sistema LubRoute");

            // Conteúdo do email em HTML
            String htmlMsg = "<html>" +
                    "<body style='font-family: Arial, sans-serif;'>" +
                    "<h3 style='color: #333333;'>Ol&aacute;, " + nomeCliente + "</h3>" +
                    "<p style='color: #666666; font-size: 16px;'>Seu cadastro no sistema LubRoute foi criado e a senha para primeiro acesso est&aacute; abaixo.</p>" +
                    "<p><strong style='color: #000000;'>Seu login:</strong><br>" +
                    "email: " + emailDestinatario + "<br>" +
                    "senha: " + senha + "</p>" +
                    "<p style='font-style: italic; font-size: 14px; color: #999999;'>Esta &eacute; uma senha provis&oacute;ria e no primeiro acesso voc&ecirc; dever&aacute; fornecer uma nova senha.</p>" +
                    "<p style='color: #666666; font-size: 16px;'>Acesse o site <a href='https://www.lubroute.com.br/app-login'>LubRoute</a> para mais informa&ccedil;&otilde;es.</p>" +
                    "<p style='color: #666666; font-size: 16px;'>Atenciosamente,<br>Equipe LubRoute</p>" +
                    "</body></html>";

            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(htmlMsg, "text/html");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(htmlPart);

            message.setContent(multipart);

            Transport.send(message);

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

	public void sendEmailRecuperacaoSenha(String emailDestinatario, String tokenRecuperacaoSenha, String nomeCliente) {

        Properties prop = new Properties();
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
    
        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });
    
        try {
            // Criando uma nova mensagem de email
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(emailFrom));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailDestinatario));
            message.setSubject("Recuperação de Senha - LubRoute");
    
            // Conteúdo do email em HTML
            String htmlMsg = "<html>" +
                    "<body style='font-family: Arial, sans-serif;'>" +
                    "<h3 style='color: #333333;'>Ol&aacute;, " + nomeCliente + "</h3>" +
                    "<p style='color: #666666; font-size: 16px;'>Recebemos uma solicita&ccedil;&atilde;o para redefinir sua senha.</p>" +
                    "<p style='color: #666666; font-size: 16px;'>Para redefinir sua senha, clique no link abaixo:</p>" +
                    "<p><a href='https://www.lubroute.com.br/recuperar-senha?token=" + tokenRecuperacaoSenha + "' style='color: #1a73e8;'>Redefinir Senha</a></p>" +
                    "<p style='color: #666666; font-size: 14px;'>Este link &eacute; v&aacute;lido por 4 horas. Se voc&ecirc; n&atilde;o solicitou essa altera&ccedil;&atilde;o, por favor ignore este e-mail.</p>" +
                    "<p style='color: #666666; font-size: 16px;'>Atenciosamente,<br>Equipe LubRoute</p>" +
                    "</body></html>";
    
            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(htmlMsg, "text/html");
    
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(htmlPart);
    
            message.setContent(multipart);
    
            Transport.send(message);
    
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
    
}

