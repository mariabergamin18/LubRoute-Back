package com.br.lubvel.utils;

import java.util.Base64;

import javax.crypto.SecretKey;

import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
@SuppressWarnings("deprecation")
public class KeyGenerator {

	private SecretKey generateHS256SecretKey() {
        return Keys.secretKeyFor(SignatureAlgorithm.HS256);
    }
	
    public String gerarKey() {
        SecretKey secretKey = generateHS256SecretKey();
        // Codifica a chave em base64 para um armazenamento e uso seguro
        String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
        System.out.println("Secret Key: " + encodedKey);
        return encodedKey;
    }
}
