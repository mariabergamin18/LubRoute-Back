package com.br.lubvel.utils;
import org.mindrot.jbcrypt.BCrypt;


public class SegurancaSenha {
    // Função para gerar o hash da senha
    public static String gerarHashSenha(String senha) {
      // Gera um salt e hash a senha
      String salt = BCrypt.gensalt();
      return BCrypt.hashpw(senha, salt);
  }

  // Função para validar a senha
  public static boolean validarSenha(String senhaFornecida, String hashArmazenado) {
      // Verifica se a senha fornecida gera o mesmo hash que o armazenado
      return BCrypt.checkpw(senhaFornecida, hashArmazenado);
  }
}
