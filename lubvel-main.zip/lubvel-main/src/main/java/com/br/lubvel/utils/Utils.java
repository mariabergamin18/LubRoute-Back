package com.br.lubvel.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Utils {

    public static String gerarPublicId() {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            String currentTime = String.valueOf(new Date().getTime());

            byte[] encodedhash = digest.digest(currentTime.getBytes(StandardCharsets.UTF_8));

            return bytesToHex(encodedhash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Não foi possível gerar o hash do Public ID", e);
        }
    }

    public static String gerarTag() {
        StringBuilder tag = new StringBuilder();
        SecureRandom random = new SecureRandom();
        for (int i = 0; i < 6; i++) {
            tag.append(random.nextInt(10));
        }
        return tag.toString();
    }

    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static synchronized String gerarSenhaPrimaria() {

        return gerarSenhaAleatoria();
    }

    private static String gerarSenhaAleatoria() {

        String numeros = "0123456789";
        String especiais = "@!$#";
        String letras = "abcdefghijklmnopqrstuvwxyz";

        SecureRandom random = new SecureRandom();
        StringBuilder senha = new StringBuilder();

        senha.append(especiais.charAt(random.nextInt(especiais.length())));

        for (int i = 0; i < 2; i++) {
            senha.append(numeros.charAt(random.nextInt(numeros.length())));
        }

        for (int i = 0; i < 3; i++) {
            senha.append(letras.charAt(random.nextInt(letras.length())));
        }

        for (int i = 0; i < 4; i++) {
            senha.append(Character.toUpperCase(letras.charAt(random.nextInt(letras.length()))));
        }

        String senhaEmbaralhada = shuffleString(senha.toString());

        return senhaEmbaralhada;
    }

    private static String shuffleString(String string) {
        char[] array = string.toCharArray();
        SecureRandom random = new SecureRandom();
        for (int i = array.length - 1; i > 0; i--) {
            int indice = random.nextInt(i + 1);
            char temp = array[indice];
            array[indice] = array[i];
            array[i] = temp;
        }
        return new String(array);
    }

    public static String dateToString(Date dataInclusao) {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(dataInclusao);
    }

    public static Date stringToDate(String dataHoraInicio) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        try {
            return sdf.parse(dataHoraInicio);
        } catch (ParseException e) {
            throw new RuntimeException("Erro ao formatar data");
        }
    }

    public static Date stringToDateWithoutTime(String dataHoraInicio) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dataHoraInicio);
        } catch (ParseException e) {
            throw new RuntimeException("Erro ao formatar data", e);
        }
    }

    public static Date stringToDateDdMmYyyy(String dataHoraInicio) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        try {
            return sdf.parse(dataHoraInicio);
        } catch (ParseException e) {
            throw new RuntimeException("Erro ao formatar data", e);
        }
    }

    public static Date stringToHour(String dataHora) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm");
        try {
            Date date = inputFormat.parse(dataHora);
            String formattedTime = outputFormat.format(date);
            return outputFormat.parse(formattedTime);
        } catch (ParseException e) {
            throw new RuntimeException("Erro ao formatar data", e);
        }
    }

    public static Date getStartOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static List<Date> getDatesOfWeekAfterDate(Date date) {
        List<Date> datesOfWeek = new ArrayList<>();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        // Set the calendar to the start of the week (Sunday)
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        // Add all 7 days of the week to the list, starting from the given date
        for (int i = 0; i < 7; i++) {
            if (!calendar.getTime().before(date)) {
                datesOfWeek.add(calendar.getTime());
            }
            calendar.add(Calendar.DAY_OF_WEEK, 1);
        }

        return datesOfWeek;
    }

    public static boolean isSameDayOfMonth(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        return cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH);
    }

    public static boolean isSameDayOfYear(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        return cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }

    public static boolean isSameDayOfWeek(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        return cal1.get(Calendar.DAY_OF_WEEK) == cal2.get(Calendar.DAY_OF_WEEK);
    }

    public static boolean isSameDate(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        return cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH)
                    && cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH)
                && cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
                    && cal1.get(Calendar.HOUR_OF_DAY) == cal2.get(Calendar.HOUR_OF_DAY);
    }

    public static String dateToStringDdMmYyyy(Date dataHoraExecucao) {
        if (dataHoraExecucao == null) {
            return "";
        }
        return new SimpleDateFormat("dd-MM-yyyy HH:mm").format(dataHoraExecucao);
    }

    public static boolean isSameTime(Date dataHoraExecucao, Date stringToDateDdMmYyyy) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(dataHoraExecucao);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(stringToDateDdMmYyyy);
        return ((cal1.get(Calendar.HOUR_OF_DAY) == cal2.get(Calendar.HOUR_OF_DAY))
                && (cal1.get(Calendar.MINUTE) == cal2.get(Calendar.MINUTE)));
    }

    public static String getTempoParaExecutar(String dataHoraParaExecucao) {
        Date dataHora = stringToDateDdMmYyyy(dataHoraParaExecucao);

        Date dataAtual = new Date();

        // Calcular a diferença em milissegundos
        long diferenca = dataHora.getTime() - dataAtual.getTime();

        // Se a data já passou, calcular o tempo de atraso
        if (diferenca < 0) {
            diferenca = Math.abs(diferenca); // Tornar o valor positivo para calcular o tempo de atraso
            long diferencaHoras = diferenca / (60 * 60 * 1000) % 24;
            long diferencaMinutos = diferenca / (60 * 1000) % 60;
            long diferencaDias = diferenca / (24 * 60 * 60 * 1000);

            if (diferencaDias == 0) {
                return "Atrasado há " + diferencaHoras + "h " + diferencaMinutos + "m ";
            } else {
                return "Atrasado há " + diferencaDias + "d " + diferencaHoras + "h " + diferencaMinutos + "m ";
            }
        }

        // Se ainda não passou, calcular o tempo restante
        long diferencaHorasRestante = diferenca / (60 * 60 * 1000) % 24;
        long diferencaMinutosRestante = diferenca / (60 * 1000) % 60;
        long diferencaDiasRestante = diferenca / (24 * 60 * 60 * 1000);

        if (diferencaDiasRestante == 0) {
            return diferencaHorasRestante + "h " + diferencaMinutosRestante + "m restantes";
        } else {
            return diferencaDiasRestante + "d " + diferencaHorasRestante + "h " + diferencaMinutosRestante
                    + "m restantes";
        }
    }

    public static Date localDateToDate(LocalDate localDate) {
        return java.sql.Date.valueOf(localDate);
    }

    public static Date getDataHoraAtual() {
        return new Date();
    }

    public static boolean isFuture(String dataHoraParaExecucao) {

        Date dataHora = stringToDateDdMmYyyy(dataHoraParaExecucao);

        Calendar dataAtual = Calendar.getInstance();
        dataAtual.set(Calendar.HOUR_OF_DAY, 0);
        dataAtual.set(Calendar.MINUTE, 0);
        dataAtual.set(Calendar.SECOND, 0);
        dataAtual.set(Calendar.MILLISECOND, 0);

        Calendar dataExecucao = Calendar.getInstance();
        dataExecucao.setTime(dataHora);
        dataExecucao.set(Calendar.HOUR_OF_DAY, 0);
        dataExecucao.set(Calendar.MINUTE, 0);
        dataExecucao.set(Calendar.SECOND, 0);
        dataExecucao.set(Calendar.MILLISECOND, 0);

        return dataExecucao.after(dataAtual);
    }

    public static String gerarProdutoPublicId() {
        //public ID é um número aleatório de 6 dígitos iniciados com 65
        SecureRandom random = new SecureRandom();
        return "U00" + random.nextInt(1000000);        
    }

    public static String removeHourFromData(String dataHora) {
        return dataHora.substring(0, 10);
    }

}
