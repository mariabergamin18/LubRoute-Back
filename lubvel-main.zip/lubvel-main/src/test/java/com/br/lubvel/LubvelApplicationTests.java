package com.br.lubvel;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LubvelApplicationTests {

	@Test
	@Disabled
	void contextLoads() {
	}

}
